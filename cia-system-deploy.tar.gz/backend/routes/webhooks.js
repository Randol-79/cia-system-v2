/**
 * Webhook Routes
 * Handle incoming webhooks from Zoom, Fireflies, Sales Tool, etc.
 */

const express = require('express');
const crypto = require('crypto');
const logger = require('../utils/logger');
const { getInstance: getOrchestrator } = require('../services/orchestrator');

const router = express.Router();

// ============================================================================
// ZOOM WEBHOOKS
// ============================================================================

/**
 * Verify Zoom webhook signature
 */
function verifyZoomWebhook(req, res, next) {
  const message = `v0:${req.headers['x-zm-request-timestamp']}:${JSON.stringify(req.body)}`;
  const hashForVerify = crypto
    .createHmac('sha256', process.env.ZOOM_WEBHOOK_SECRET || '')
    .update(message)
    .digest('hex');
  
  const signature = `v0=${hashForVerify}`;
  
  if (req.headers['x-zm-signature'] === signature) {
    next();
  } else {
    logger.warn('Invalid Zoom webhook signature');
    res.status(401).json({ error: 'Invalid signature' });
  }
}

/**
 * Handle Zoom webhook events
 */
router.post('/zoom/events', express.json(), verifyZoomWebhook, async (req, res) => {
  const { event, payload } = req.body;

  logger.info(`Received Zoom webhook: ${event}`);

  try {
    // Handle webhook verification
    if (event === 'endpoint.url_validation') {
      const { plainToken, encryptedToken } = payload;
      
      // Decrypt token
      const decipher = crypto.createDecipheriv(
        'aes-256-cbc',
        Buffer.from(process.env.ZOOM_WEBHOOK_SECRET || '', 'base64'),
        Buffer.alloc(16, 0)
      );
      
      let decrypted = decipher.update(encryptedToken, 'base64', 'utf8');
      decrypted += decipher.final('utf8');
      
      return res.json({
        plainToken,
        encryptedToken: decrypted
      });
    }

    // Handle meeting started event (incoming call)
    if (event === 'meeting.started' || event === 'meeting.participant_joined') {
      const orchestrator = getOrchestrator();
      
      const callData = {
        event_type: 'incoming',
        caller_id: payload.participant?.email || payload.object?.participant?.email,
        meeting_id: payload.object?.id,
        meeting_topic: payload.object?.topic,
        timestamp: new Date()
      };

      // Process asynchronously
      orchestrator.processIncomingCall(callData)
        .catch(error => {
          logger.error('Error processing incoming call:', error);
        });

      res.status(200).json({ received: true });
    } else {
      // Acknowledge other events
      res.status(200).json({ received: true });
    }

  } catch (error) {
    logger.error('Error handling Zoom webhook:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ============================================================================
// FIREFLIES.AI WEBHOOKS
// ============================================================================

/**
 * Verify Fireflies webhook signature
 */
function verifyFirefliesWebhook(req, res, next) {
  const signature = req.headers['x-fireflies-signature'];
  const secret = process.env.FIREFLIES_WEBHOOK_SECRET;

  if (!secret) {
    return next(); // Skip verification if no secret configured
  }

  const hash = crypto
    .createHmac('sha256', secret)
    .update(JSON.stringify(req.body))
    .digest('hex');

  if (signature === hash) {
    next();
  } else {
    logger.warn('Invalid Fireflies webhook signature');
    res.status(401).json({ error: 'Invalid signature' });
  }
}

/**
 * Handle Fireflies transcript webhooks
 */
router.post('/fireflies/transcript', express.json(), verifyFirefliesWebhook, async (req, res) => {
  logger.info('Received Fireflies transcript webhook');

  try {
    const { transcript_id, title, date, participants, gdrive_url } = req.body;

    const orchestrator = getOrchestrator();

    // Process transcript asynchronously
    orchestrator.processTranscript({
      fireflies_id: transcript_id,
      title,
      date: new Date(date),
      participants,
      gdrive_url
    }).catch(error => {
      logger.error('Error processing transcript:', error);
    });

    res.status(200).json({ received: true });

  } catch (error) {
    logger.error('Error handling Fireflies webhook:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ============================================================================
// SALES TOOL WEBHOOKS
// ============================================================================

/**
 * Verify Sales Tool webhook signature
 */
function verifySalesToolWebhook(req, res, next) {
  const signature = req.headers['x-sales-tool-signature'];
  const secret = process.env.SALES_TOOL_WEBHOOK_SECRET;

  if (!secret) {
    return next(); // Skip verification if no secret
  }

  const hash = crypto
    .createHmac('sha256', secret)
    .update(JSON.stringify(req.body))
    .digest('hex');

  if (signature === hash) {
    next();
  } else {
    logger.warn('Invalid Sales Tool webhook signature');
    res.status(401).json({ error: 'Invalid signature' });
  }
}

/**
 * Handle proposal viewed events
 */
router.post('/sales-tool/proposal-viewed', express.json(), verifySalesToolWebhook, async (req, res) => {
  logger.info('Received Sales Tool webhook: proposal-viewed');

  try {
    const { proposal_id, client_name, viewer_email, timestamp } = req.body;

    // Log event to database
    const { sequelize } = require('../config/database');
    await sequelize.query(`
      INSERT INTO workflow_events (
        event_type, event_source, payload, status
      ) VALUES (?, ?, ?, ?)
    `, {
      replacements: [
        'proposal_viewed',
        'sales_tool_webhook',
        JSON.stringify(req.body),
        'completed'
      ]
    });

    // TODO: Send notification to sales team
    logger.info(`Proposal ${proposal_id} viewed by ${viewer_email}`);

    res.status(200).json({ received: true });

  } catch (error) {
    logger.error('Error handling Sales Tool webhook:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

/**
 * Handle proposal signed events
 */
router.post('/sales-tool/proposal-signed', express.json(), verifySalesToolWebhook, async (req, res) => {
  logger.info('Received Sales Tool webhook: proposal-signed');

  try {
    const { proposal_id, client_name, amount, signed_by } = req.body;

    // Log event
    const { sequelize } = require('../config/database');
    await sequelize.query(`
      INSERT INTO workflow_events (
        event_type, event_source, payload, status
      ) VALUES (?, ?, ?, ?)
    `, {
      replacements: [
        'proposal_signed',
        'sales_tool_webhook',
        JSON.stringify(req.body),
        'completed'
      ]
    });

    // Send celebration message to Slack
    const SlackService = require('../services/integrations/slack');
    const slack = new SlackService();
    
    await slack.sendMessage({
      channel: process.env.SLACK_CHANNEL_SALES,
      text: `🎉 Proposal signed by ${client_name} for $${amount.toLocaleString()}!`,
      blocks: [
        {
          type: 'section',
          text: {
            type: 'mrkdwn',
            text: `🎉 *Proposal Signed!*\n\n*Client:* ${client_name}\n*Amount:* $${amount.toLocaleString()}\n*Signed by:* ${signed_by}`
          }
        }
      ]
    });

    res.status(200).json({ received: true });

  } catch (error) {
    logger.error('Error handling Sales Tool webhook:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ============================================================================
// GOOGLE DRIVE WEBHOOKS (Optional - for real-time transcript detection)
// ============================================================================

router.post('/gdrive/notification', express.json(), async (req, res) => {
  logger.info('Received Google Drive notification');

  try {
    // Google Drive sends notifications when files change
    // This can be used as an alternative to Fireflies webhooks
    const { channelId, resourceId, resourceState } = req.headers;

    if (resourceState === 'update') {
      // File was updated - could be a new transcript
      logger.info(`File updated: ${resourceId}`);
    }

    res.status(200).json({ received: true });

  } catch (error) {
    logger.error('Error handling Google Drive webhook:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ============================================================================
// HEALTH CHECK
// ============================================================================

router.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    webhooks: {
      zoom: !!process.env.ZOOM_WEBHOOK_SECRET,
      fireflies: !!process.env.FIREFLIES_WEBHOOK_SECRET,
      sales_tool: !!process.env.SALES_TOOL_WEBHOOK_SECRET
    }
  });
});

module.exports = router;
