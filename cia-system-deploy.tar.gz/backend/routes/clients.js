const express = require('express');
const router = express.Router();

// In-memory clients store (mock)
const clients = [
  {
    id: 1,
    name: 'Acme Corporation',
    industry: 'Technology',
    status: 'active',
    health_score: 85,
    communication_style: 'Direct and analytical',
    emotional_trigger: 'Innovation and efficiency',
    created_at: '2024-01-15T10:00:00Z'
  },
  {
    id: 2,
    name: 'Global Dynamics',
    industry: 'Manufacturing',
    status: 'active',
    health_score: 72,
    communication_style: 'Formal and detailed',
    emotional_trigger: 'Cost savings and reliability',
    created_at: '2024-02-20T14:30:00Z'
  },
  {
    id: 3,
    name: 'Innovatech Solutions',
    industry: 'Software Development',
    status: 'active',
    health_score: 93,
    communication_style: 'Collaborative and creative',
    emotional_trigger: 'Cutting-edge technology',
    created_at: '2024-03-10T09:15:00Z'
  },
  {
    id: 4,
    name: 'Healthcare Plus',
    industry: 'Healthcare',
    status: 'active',
    health_score: 67,
    communication_style: 'Empathetic and thorough',
    emotional_trigger: 'Patient care quality',
    created_at: '2024-01-25T11:45:00Z'
  },
  {
    id: 5,
    name: 'Finance First',
    industry: 'Financial Services',
    status: 'inactive',
    health_score: 45,
    communication_style: 'Conservative and risk-averse',
    emotional_trigger: 'Security and compliance',
    created_at: '2023-11-05T16:20:00Z'
  }
];

router.get('/', (req, res) => {
  res.json(clients);
});

// Get single client
router.get('/:id', (req, res) => {
  const id = parseInt(req.params.id, 10);
  const client = clients.find(c => c.id === id);
  if (!client) return res.status(404).json({ error: 'Client not found' });
  res.json(client);
});

// Simple analysis endpoint - returns mock analysis based on client data
router.post('/:id/analyze', (req, res) => {
  const id = parseInt(req.params.id, 10);
  const client = clients.find(c => c.id === id);
  if (!client) return res.status(404).json({ error: 'Client not found' });

  // Basic heuristic analysis
  const risk = client.health_score >= 85 ? 'low' : client.health_score >= 70 ? 'medium' : 'high';
  const recommendedActions = [];
  if (risk === 'high') {
    recommendedActions.push('Schedule urgent follow-up', 'Offer renewal incentives', 'Assign senior CSM');
  } else if (risk === 'medium') {
    recommendedActions.push('Offer QBR', 'Share relevant case studies');
  } else {
    recommendedActions.push('Invite to beta program', 'Discuss expansion opportunities');
  }

  const analysis = {
    client_id: client.id,
    client_name: client.name,
    health_score: client.health_score,
    risk_level: risk,
    recommendation_confidence: Math.round((client.health_score / 100) * 100),
    recommended_actions: recommendedActions,
    generated_at: new Date().toISOString()
  };

  // In a real implementation, this would call AI services or aggregate real data.
  res.json(analysis);
});

// Endpoint to accept integration credentials (simple in-memory store)
// Note: integration credential endpoints moved to /api/integrations

module.exports = router;