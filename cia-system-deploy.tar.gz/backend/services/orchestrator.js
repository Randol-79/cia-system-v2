/**
 * Data Orchestrator Service
 * Central coordination hub for all integrations and workflows
 */

const cron = require('node-cron');
const logger = require('../utils/logger');
const { getInstance: getAIEngine } = require('./ai-engine');
const AcceloService = require('./integrations/accelo');
const FirefliesService = require('./integrations/fireflies');
const GoogleAnalyticsService = require('./integrations/google-analytics');
const SlackService = require('./integrations/slack');
const redis = require('../config/redis');
const { sequelize } = require('../config/database');

class OrchestratorService {
  constructor() {
    this.aiEngine = null;
    this.acceloService = null;
    this.firefliesService = null;
    this.gaService = null;
    this.slackService = null;
    
    this.cronJobs = [];
    this.isInitialized = false;
  }

  /**
   * Initialize all services and scheduled jobs
   */
  async initialize() {
    try {
      logger.info('Initializing Orchestrator Service...');

      // Initialize AI Engine
      this.aiEngine = getAIEngine();

      // Initialize integration services
      this.acceloService = new AcceloService();
      this.firefliesService = new FirefliesService();
      this.gaService = new GoogleAnalyticsService();
      this.slackService = new SlackService();

      // Set up scheduled jobs
      this._setupScheduledJobs();

      this.isInitialized = true;
      logger.info('Orchestrator Service initialized successfully');

    } catch (error) {
      logger.error('Failed to initialize Orchestrator Service:', error);
      throw error;
    }
  }

  /**
   * Process incoming Zoom call event (Output 1: Heads-Up Display)
   * @param {Object} callData - Zoom webhook data
   */
  async processIncomingCall(callData) {
    const startTime = Date.now();
    logger.info(`Processing incoming call from: ${callData.caller_id}`);

    try {
      // 1. Match caller to Accelo contact
      const contact = await this._matchCallerToContact(callData.caller_id);
      
      if (!contact) {
        logger.warn(`No contact found for caller: ${callData.caller_id}`);
        return { success: false, reason: 'contact_not_found' };
      }

      // 2. Get client data
      const client = await this._getClientData(contact.client_id);

      // 3. Get current project status
      const projects = await this.acceloService.getActiveProjects(client.accelo_id);

      // 4. Get performance metrics (from cache if available)
      const metrics = await this._getPerformanceMetrics(client.id);

      // 5. Get recent transcripts
      const transcripts = await this._getRecentTranscripts(client.id, 2);

      // 6. Get relevant services
      const services = await this._getRelevantServices(client);

      // 7. Generate AI insights
      const intelligence = await this.aiEngine.generateHeadsUpDisplay({
        client,
        contact,
        projectStatus: projects[0]?.status || 'No active projects',
        performanceMetrics: metrics,
        recentTranscripts: transcripts,
        services
      });

      // 8. Format and send Slack message
      await this._sendHeadsUpToSlack({
        client,
        contact,
        intelligence,
        metrics,
        callData
      });

      // 9. Log event
      await this._logWorkflowEvent({
        event_type: 'call_detected',
        event_source: 'zoom_webhook',
        client_id: client.id,
        payload: { callData, intelligence },
        status: 'completed'
      });

      const duration = Date.now() - startTime;
      logger.info(`Call processed successfully in ${duration}ms`);

      return {
        success: true,
        duration,
        client: client.name,
        intelligence
      };

    } catch (error) {
      logger.error('Error processing incoming call:', error);
      await this._logWorkflowEvent({
        event_type: 'call_detected',
        event_source: 'zoom_webhook',
        payload: callData,
        status: 'failed',
        error_message: error.message
      });
      throw error;
    }
  }

  /**
   * Process Fireflies transcript (Output 2: Automated Handoff)
   * @param {Object} transcriptData - Fireflies webhook data
   */
  async processTranscript(transcriptData) {
    logger.info(`Processing transcript: ${transcriptData.title}`);

    try {
      // 1. Download transcript from Google Drive
      const transcript = await this.firefliesService.fetchTranscript(transcriptData);

      // 2. Extract sales information using AI
      const salesData = await this.aiEngine.processSalesTranscript(transcript);

      // 3. Find or create client in Accelo
      let client = await this._findOrCreateClient(salesData);

      // 4. Get existing Accelo data for comparison
      const acceloData = await this.acceloService.getCompanyData(client.accelo_id);

      // 5. Generate project handoff document
      const handoff = await this.aiEngine.generateProjectHandoff(salesData, acceloData);

      // 6. Send draft to sales team via Slack
      await this._sendSalesAdminDraft({
        salesData,
        conflicts: handoff.conflicts,
        client
      });

      // 7. Create project brief in Accelo (if no conflicts)
      if (handoff.conflicts.length === 0) {
        await this.acceloService.createProjectBrief(client.accelo_id, {
          salesData,
          handoffDocument: handoff.content,
          transcript
        });
      }

      // 8. Store transcript in database
      await this._saveTranscript({
        client_id: client.id,
        transcript,
        salesData,
        handoff
      });

      logger.info(`Transcript processed successfully for: ${client.name}`);

      return {
        success: true,
        client: client.name,
        conflicts: handoff.conflicts.length,
        salesData
      };

    } catch (error) {
      logger.error('Error processing transcript:', error);
      throw error;
    }
  }

  /**
   * Check for tasks needing client nudges (Output 3: Proactive Communication)
   */
  async checkTasksNeedingNudges() {
    logger.info('Checking for tasks needing client nudges...');

    try {
      // Get all waiting tasks
      const [tasks] = await sequelize.query(`
        SELECT * FROM waiting_tasks_summary
        WHERE days_waiting >= 3
        AND (last_nudge_sent_at IS NULL OR last_nudge_sent_at < NOW() - INTERVAL '5 days')
        ORDER BY days_waiting DESC
        LIMIT 10
      `);

      for (const task of tasks) {
        await this._processTaskNudge(task);
      }

      logger.info(`Processed ${tasks.length} task nudges`);
      return { processed: tasks.length };

    } catch (error) {
      logger.error('Error checking task nudges:', error);
      throw error;
    }
  }

  /**
   * Detect upsell opportunities (Output 3: Proactive Communication)
   */
  async detectUpsellOpportunities() {
    logger.info('Detecting upsell opportunities...');

    try {
      const opportunities = [];

      // Get all active clients
      const [clients] = await sequelize.query(`
        SELECT * FROM active_clients_with_performance
        WHERE status = 'active'
      `);

      for (const client of clients) {
        const opportunity = await this._analyzeUpsellOpportunity(client);
        if (opportunity) {
          opportunities.push(opportunity);
        }
      }

      logger.info(`Found ${opportunities.length} upsell opportunities`);
      return opportunities;

    } catch (error) {
      logger.error('Error detecting upsell opportunities:', error);
      throw error;
    }
  }

  /**
   * Manual client lookup via Slack command
   * @param {String} clientName - Client name to lookup
   * @param {String} userId - Slack user ID requesting lookup
   */
  async handleManualLookup(clientName, userId) {
    logger.info(`Manual lookup requested for: ${clientName} by ${userId}`);

    try {
      // Find client
      const client = await this._findClientByName(clientName);
      
      if (!client) {
        return {
          success: false,
          message: `No client found matching "${clientName}"`
        };
      }

      // Get comprehensive client data
      const data = await this._getComprehensiveClientData(client.id);

      // Generate intelligence
      const intelligence = await this.aiEngine.generateHeadsUpDisplay(data);

      // Send detailed report to Slack
      await this.slackService.sendDetailedClientReport({
        client,
        data,
        intelligence,
        userId
      });

      return {
        success: true,
        client: client.name
      };

    } catch (error) {
      logger.error('Error handling manual lookup:', error);
      throw error;
    }
  }

  /**
   * Sync performance data for all clients
   */
  async syncPerformanceData() {
    logger.info('Starting performance data sync...');

    try {
      const [clients] = await sequelize.query(`
        SELECT c.*, gc.ga4_property_id, gc.gsc_site_url
        FROM clients c
        JOIN google_credentials gc ON c.id = gc.client_id
        WHERE c.status = 'active' AND gc.is_active = true
      `);

      let syncedCount = 0;
      let errorCount = 0;

      for (const client of clients) {
        try {
          // Fetch last 30 days of data
          const metrics = await this.gaService.fetchMetrics({
            propertyId: client.ga4_property_id,
            siteUrl: client.gsc_site_url,
            startDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
            endDate: new Date()
          });

          // Save to database
          await this._savePerformanceMetrics(client.id, metrics);

          // Cache for quick access
          await redis.setex(
            `perf:${client.id}`,
            3600, // 1 hour
            JSON.stringify(metrics)
          );

          syncedCount++;
          logger.debug(`Synced metrics for ${client.name}`);

        } catch (error) {
          errorCount++;
          logger.error(`Error syncing metrics for ${client.name}:`, error);
        }
      }

      logger.info(`Performance sync complete: ${syncedCount} synced, ${errorCount} errors`);
      return { synced: syncedCount, errors: errorCount };

    } catch (error) {
      logger.error('Error syncing performance data:', error);
      throw error;
    }
  }

  /**
   * Shutdown orchestrator and clean up resources
   */
  async shutdown() {
    logger.info('Shutting down Orchestrator Service...');

    // Stop all cron jobs
    this.cronJobs.forEach(job => job.stop());
    this.cronJobs = [];

    this.isInitialized = false;
    logger.info('Orchestrator Service shut down');
  }

  // ========================================================================
  // PRIVATE HELPER METHODS
  // ========================================================================

  _setupScheduledJobs() {
    // Sync performance data daily at 2 AM
    this.cronJobs.push(
      cron.schedule('0 2 * * *', async () => {
        logger.info('Running scheduled performance sync...');
        await this.syncPerformanceData();
      })
    );

    // Check for task nudges every hour
    this.cronJobs.push(
      cron.schedule('0 * * * *', async () => {
        logger.info('Running scheduled task nudge check...');
        await this.checkTasksNeedingNudges();
      })
    );

    // Detect upsell opportunities daily at 9 AM
    this.cronJobs.push(
      cron.schedule('0 9 * * *', async () => {
        logger.info('Running scheduled upsell detection...');
        await this.detectUpsellOpportunities();
      })
    );

    logger.info('Scheduled jobs configured');
  }

  async _matchCallerToContact(callerId) {
    // Try exact match first
    const [contacts] = await sequelize.query(`
      SELECT * FROM contacts
      WHERE phone = ? OR zoom_user_id = ? OR zoom_email = ?
      LIMIT 1
    `, {
      replacements: [callerId, callerId, callerId]
    });

    return contacts[0] || null;
  }

  async _getClientData(clientId) {
    const [clients] = await sequelize.query(`
      SELECT * FROM clients WHERE id = ?
    `, {
      replacements: [clientId]
    });

    return clients[0];
  }

  async _getPerformanceMetrics(clientId) {
    // Try cache first
    const cached = await redis.get(`perf:${clientId}`);
    if (cached) {
      return JSON.parse(cached);
    }

    // Fallback to database
    const [metrics] = await sequelize.query(`
      SELECT * FROM performance_metrics
      WHERE client_id = ? AND period = 'monthly'
      ORDER BY metric_date DESC
      LIMIT 1
    `, {
      replacements: [clientId]
    });

    return metrics[0] || null;
  }

  async _getRecentTranscripts(clientId, limit = 2) {
    const [transcripts] = await sequelize.query(`
      SELECT meeting_date as date, summary, sentiment
      FROM call_transcripts
      WHERE client_id = ?
      ORDER BY meeting_date DESC
      LIMIT ?
    `, {
      replacements: [clientId, limit]
    });

    return transcripts;
  }

  async _getRelevantServices(client) {
    const [services] = await sequelize.query(`
      SELECT * FROM services
      WHERE is_active = true
      AND (? = ANY(emotional_triggers) OR emotional_triggers IS NULL)
      LIMIT 5
    `, {
      replacements: [client.emotional_trigger]
    });

    return services;
  }

  async _sendHeadsUpToSlack({ client, contact, intelligence, metrics, callData }) {
    const message = this.slackService.formatHeadsUpDisplay({
      client,
      contact,
      intelligence,
      metrics,
      callType: callData.event_type
    });

    await this.slackService.sendMessage({
      channel: process.env.SLACK_CHANNEL_SALES,
      ...message
    });

    // Log to database
    await sequelize.query(`
      INSERT INTO slack_messages (
        message_type, slack_channel_id, message_text, blocks,
        client_id, triggered_by
      ) VALUES (?, ?, ?, ?, ?, ?)
    `, {
      replacements: [
        'heads-up-display',
        process.env.SLACK_CHANNEL_SALES,
        message.text,
        JSON.stringify(message.blocks),
        client.id,
        'zoom_call'
      ]
    });
  }

  async _processTaskNudge(task) {
    try {
      // Generate nudge email
      const nudge = await this.aiEngine.generateClientNudge({
        client: { name: task.client_name, communication_style: task.communication_style },
        task: { title: task.title, description: task.description },
        daysWaiting: task.days_waiting,
        communicationStyle: task.communication_style || 'professional'
      });

      // Send draft to PM via Slack
      await this.slackService.sendNudgeDraft({
        task,
        nudge,
        pmChannel: process.env.SLACK_CHANNEL_PM
      });

      // Update last nudge timestamp
      await sequelize.query(`
        UPDATE tasks SET last_nudge_sent_at = NOW()
        WHERE id = ?
      `, {
        replacements: [task.id]
      });

    } catch (error) {
      logger.error(`Error processing nudge for task ${task.id}:`, error);
    }
  }

  async _analyzeUpsellOpportunity(client) {
    // Get performance trends
    const metrics = await this._getPerformanceMetrics(client.id);
    
    if (!metrics) return null;

    // Get matching services based on performance triggers
    const [services] = await sequelize.query(`
      SELECT * FROM services
      WHERE is_active = true
      AND performance_triggers IS NOT NULL
      LIMIT 3
    `);

    for (const service of services) {
      const triggers = service.performance_triggers;
      const matched = this._checkPerformanceTriggers(metrics, triggers);

      if (matched) {
        // Generate upsell email
        const email = await this.aiEngine.generateUpsellEmail({
          client,
          service,
          trigger: matched,
          performanceData: metrics,
          emotionalTrigger: client.emotional_trigger
        });

        // Create recommendation
        await sequelize.query(`
          INSERT INTO recommendations (
            client_id, service_id, recommendation_type, trigger_type,
            trigger_data, confidence_score, email_draft, talking_points
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `, {
          replacements: [
            client.id,
            service.id,
            'upsell',
            matched.type,
            JSON.stringify(matched),
            0.8,
            email.body,
            JSON.stringify(email.talkingPoints)
          ]
        });

        return {
          client: client.name,
          service: service.name,
          trigger: matched.type
        };
      }
    }

    return null;
  }

  _checkPerformanceTriggers(metrics, triggers) {
    for (const [metric, condition] of Object.entries(triggers)) {
      const value = metrics[metric];
      
      if (condition.includes('>')) {
        const threshold = parseFloat(condition.replace('>', ''));
        if (value > threshold) {
          return {
            type: `${metric}_high`,
            description: `${metric} is ${value}, exceeds ${threshold}`
          };
        }
      } else if (condition.includes('<')) {
        const threshold = parseFloat(condition.replace('<', ''));
        if (value < threshold) {
          return {
            type: `${metric}_low`,
            description: `${metric} is ${value}, below ${threshold}`
          };
        }
      }
    }
    
    return null;
  }

  async _logWorkflowEvent(event) {
    await sequelize.query(`
      INSERT INTO workflow_events (
        event_type, event_source, client_id, project_id,
        payload, status, processed_at, error_message
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `, {
      replacements: [
        event.event_type,
        event.event_source,
        event.client_id || null,
        event.project_id || null,
        JSON.stringify(event.payload),
        event.status,
        event.status === 'completed' ? new Date() : null,
        event.error_message || null
      ]
    });
  }

  async _findClientByName(name) {
    const [clients] = await sequelize.query(`
      SELECT * FROM clients
      WHERE LOWER(name) LIKE LOWER(?)
      LIMIT 1
    `, {
      replacements: [`%${name}%`]
    });

    return clients[0] || null;
  }

  async _getComprehensiveClientData(clientId) {
    const client = await this._getClientData(clientId);
    const metrics = await this._getPerformanceMetrics(clientId);
    const projects = await this.acceloService.getActiveProjects(client.accelo_id);
    const transcripts = await this._getRecentTranscripts(clientId, 5);
    const services = await this._getRelevantServices(client);

    return {
      client,
      contact: null,
      projectStatus: projects[0]?.status || 'No active projects',
      performanceMetrics: metrics,
      recentTranscripts: transcripts,
      services
    };
  }

  async _savePerformanceMetrics(clientId, metrics) {
    await sequelize.query(`
      INSERT INTO performance_metrics (
        client_id, metric_date, period, sessions, users, pageviews,
        bounce_rate, avg_session_duration, conversions, conversion_rate,
        impressions, clicks, ctr, avg_position,
        sessions_change_pct, users_change_pct
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT (client_id, metric_date, period) DO UPDATE SET
        sessions = EXCLUDED.sessions,
        users = EXCLUDED.users,
        pageviews = EXCLUDED.pageviews,
        bounce_rate = EXCLUDED.bounce_rate,
        avg_session_duration = EXCLUDED.avg_session_duration,
        conversions = EXCLUDED.conversions,
        conversion_rate = EXCLUDED.conversion_rate,
        impressions = EXCLUDED.impressions,
        clicks = EXCLUDED.clicks,
        ctr = EXCLUDED.ctr,
        avg_position = EXCLUDED.avg_position,
        sessions_change_pct = EXCLUDED.sessions_change_pct,
        users_change_pct = EXCLUDED.users_change_pct
    `, {
      replacements: [
        clientId,
        metrics.date || new Date(),
        'monthly',
        metrics.sessions || 0,
        metrics.users || 0,
        metrics.pageviews || 0,
        metrics.bounce_rate || 0,
        metrics.avg_session_duration || 0,
        metrics.conversions || 0,
        metrics.conversion_rate || 0,
        metrics.impressions || 0,
        metrics.clicks || 0,
        metrics.ctr || 0,
        metrics.avg_position || 0,
        metrics.sessions_change_pct || 0,
        metrics.users_change_pct || 0
      ]
    });
  }
}

// Singleton instance
let instance = null;

module.exports = {
  getInstance: () => {
    if (!instance) {
      instance = new OrchestratorService();
    }
    return instance;
  },
  OrchestratorService
};
