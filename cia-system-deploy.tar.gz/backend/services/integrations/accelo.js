const logger = require('../../utils/logger');

class AcceloService {
  constructor() {
    logger.info('Accelo service initialized (stub)');
  }

  async getActiveProjects(acceloId) {
    return [];
  }

  async syncClients() {
    return { synced: 0 };
  }
}

module.exports = AcceloService;