const logger = require('../../utils/logger');

class FirefliesService {
  constructor() {
    logger.info('Fireflies service initialized (stub)');
  }

  async processTranscript(transcriptData) {
    return { processed: true };
  }
}

module.exports = FirefliesService;