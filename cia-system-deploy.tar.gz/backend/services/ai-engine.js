/**
 * AI Engine Service
 * Handles all Claude API interactions for intelligence generation
 */

const Anthropic = require('@anthropic-ai/sdk');
const logger = require('../utils/logger');

class AIEngine {
  constructor() {
    if (!process.env.ANTHROPIC_API_KEY || process.env.ANTHROPIC_API_KEY === 'your-api-key-here') {
      logger.warn('Anthropic API key not configured - AI features will be disabled');
      this.anthropic = null;
    } else {
      this.anthropic = new Anthropic({
        apiKey: process.env.ANTHROPIC_API_KEY
      });
    }
    
    this.model = process.env.AI_MODEL || 'claude-sonnet-4-20250514';
    this.maxTokens = 4000;
  }

  /**
   * Generate talking points for incoming call
   * @param {Object} context - Call context with client data
   * @returns {Promise<Object>} Generated talking points and recommendations
   */
  async generateHeadsUpDisplay(context) {
    const {
      client,
      contact,
      projectStatus,
      performanceMetrics,
      recentTranscripts,
      services
    } = context;

    const prompt = this._buildHeadsUpPrompt(context);

    try {
      const response = await this.anthropic.messages.create({
        model: this.model,
        max_tokens: this.maxTokens,
        messages: [{
          role: 'user',
          content: prompt
        }]
      });

      const result = this._parseHeadsUpResponse(response.content[0].text);
      
      logger.info(`Generated heads-up display for client: ${client.name}`);
      return result;

    } catch (error) {
      logger.error('Error generating heads-up display:', error);
      throw new Error('Failed to generate AI recommendations');
    }
  }

  /**
   * Process sales call transcript and extract key information
   * @param {Object} transcript - Call transcript data
   * @returns {Promise<Object>} Extracted sales information
   */
  async processSalesTranscript(transcript) {
    const prompt = `You are analyzing a sales call transcript to extract structured information for CRM entry.

TRANSCRIPT:
"""
${transcript.text}
"""

PARTICIPANTS:
${transcript.participants.map(p => `- ${p.name} (${p.role || 'Unknown'})`).join('\n')}

Extract the following information and return it as JSON:
{
  "clientName": "Official company name mentioned",
  "contactName": "Primary contact person",
  "contactEmail": "Email if mentioned",
  "contactPhone": "Phone if mentioned",
  "projectScope": "Brief description of what they want",
  "budget": "Budget mentioned (number only, or null)",
  "timeline": "Project timeline mentioned",
  "clientGoals": ["Array", "of", "stated", "goals"],
  "painPoints": ["Array", "of", "pain", "points"],
  "decisionMakers": ["People", "involved", "in", "decision"],
  "competitorsMentioned": ["Any", "competitors", "mentioned"],
  "nextSteps": ["Agreed", "action", "items"],
  "sentiment": "positive|neutral|negative",
  "urgency": "high|medium|low",
  "keyQuotes": ["Important", "direct", "quotes", "from", "client"]
}

Return ONLY valid JSON, no other text.`;

    try {
      const response = await this.anthropic.messages.create({
        model: this.model,
        max_tokens: 3000,
        messages: [{
          role: 'user',
          content: prompt
        }]
      });

      const extracted = JSON.parse(response.content[0].text);
      logger.info(`Processed sales transcript: ${extracted.clientName}`);
      return extracted;

    } catch (error) {
      logger.error('Error processing sales transcript:', error);
      throw new Error('Failed to process transcript');
    }
  }

  /**
   * Generate project handoff document
   * @param {Object} salesData - Extracted sales information
   * @param {Object} acceloData - Existing Accelo data
   * @returns {Promise<Object>} Formatted handoff document
   */
  async generateProjectHandoff(salesData, acceloData) {
    const prompt = `You are creating a comprehensive Project Handoff Document for a Project Manager.

SALES CALL DATA:
${JSON.stringify(salesData, null, 2)}

ACCELO CRM DATA:
${JSON.stringify(acceloData, null, 2)}

Create a structured handoff document with these sections:

1. EXECUTIVE SUMMARY (2-3 sentences)
2. CLIENT OVERVIEW
   - Company background
   - Industry and market position
   - Key contacts and decision makers
3. PROJECT GOALS & OBJECTIVES
   - Primary goals (use direct quotes where available)
   - Success metrics
   - Timeline expectations
4. SCOPE OF WORK
   - Deliverables checklist
   - Technical requirements
   - Resource needs
5. BUDGET & TIMELINE
   - Approved budget
   - Payment terms
   - Key milestones
6. RISKS & CONSIDERATIONS
   - Potential challenges
   - Dependencies
   - Mitigation strategies
7. NEXT STEPS
   - Immediate action items
   - Kickoff meeting agenda
   - Required client inputs

FLAG ANY CONFLICTS between sales data and Accelo data (e.g., budget mismatch).

Return as structured markdown with clear headers.`;

    try {
      const response = await this.anthropic.messages.create({
        model: this.model,
        max_tokens: 4000,
        messages: [{
          role: 'user',
          content: prompt
        }]
      });

      return {
        content: response.content[0].text,
        conflicts: this._detectConflicts(salesData, acceloData)
      };

    } catch (error) {
      logger.error('Error generating project handoff:', error);
      throw new Error('Failed to generate handoff document');
    }
  }

  /**
   * Generate client nudge email
   * @param {Object} context - Context for the nudge
   * @returns {Promise<Object>} Draft email
   */
  async generateClientNudge(context) {
    const {
      client,
      task,
      daysWaiting,
      communicationStyle
    } = context;

    const styleGuide = {
      nurturing: 'warm, empathetic, understanding tone. Focus on partnership.',
      direct: 'concise, professional, action-oriented. Get to the point quickly.',
      'data-driven': 'analytical, metrics-focused, logical reasoning.'
    };

    const prompt = `You are drafting a polite follow-up email to a client who has been holding up a project task.

CLIENT: ${client.name}
COMMUNICATION STYLE: ${communicationStyle} - ${styleGuide[communicationStyle] || 'professional and friendly'}
TASK: ${task.title}
DAYS WAITING: ${daysWaiting} days
TASK DETAILS: ${task.description || 'No additional details'}

Write a brief email (3-4 short paragraphs) that:
1. Warmly references the project
2. Gently reminds them what's needed
3. Offers to help or clarify
4. Includes a soft deadline

Return JSON:
{
  "subject": "Email subject line",
  "body": "Email body text (use \\n\\n for paragraph breaks)",
  "tone": "brief description of tone used"
}`;

    try {
      const response = await this.anthropic.messages.create({
        model: this.model,
        max_tokens: 1000,
        messages: [{
          role: 'user',
          content: prompt
        }]
      });

      return JSON.parse(response.content[0].text);

    } catch (error) {
      logger.error('Error generating client nudge:', error);
      throw new Error('Failed to generate nudge email');
    }
  }

  /**
   * Generate upsell recommendation email
   * @param {Object} context - Context for upsell
   * @returns {Promise<Object>} Draft upsell email
   */
  async generateUpsellEmail(context) {
    const {
      client,
      service,
      trigger,
      performanceData,
      emotionalTrigger
    } = context;

    const prompt = `You are crafting a personalized upsell email for a client.

CLIENT: ${client.name}
EMOTIONAL TRIGGER: ${emotionalTrigger} (tailor messaging to this)
SERVICE TO RECOMMEND: ${service.name}
SERVICE BENEFITS: ${service.key_benefits?.join(', ')}

PERFORMANCE TRIGGER:
${trigger.description}

CURRENT PERFORMANCE DATA:
${JSON.stringify(performanceData, null, 2)}

Write a compelling email (4-5 paragraphs) that:
1. Opens with a personalized observation about their performance
2. Identifies the opportunity (tied to their emotional trigger)
3. Introduces the service naturally as a solution
4. Includes a soft ROI projection or case study reference
5. Ends with a low-pressure call-to-action

Return JSON:
{
  "subject": "Compelling subject line",
  "body": "Email body (use \\n\\n for paragraphs)",
  "talkingPoints": ["Key", "points", "for", "follow-up", "call"],
  "roiProjection": "Brief ROI statement"
}`;

    try {
      const response = await this.anthropic.messages.create({
        model: this.model,
        max_tokens: 2000,
        messages: [{
          role: 'user',
          content: prompt
        }]
      });

      return JSON.parse(response.content[0].text);

    } catch (error) {
      logger.error('Error generating upsell email:', error);
      throw new Error('Failed to generate upsell email');
    }
  }

  /**
   * Analyze client sentiment from multiple touchpoints
   * @param {Object} data - Client interaction data
   * @returns {Promise<Object>} Sentiment analysis
   */
  async analyzeClientSentiment(data) {
    const prompt = `Analyze the overall client sentiment based on multiple data points.

RECENT CALL TRANSCRIPTS:
${data.transcripts?.map(t => `[${t.date}] Summary: ${t.summary}`).join('\n')}

EMAIL EXCHANGES: ${data.emailCount} emails in last 30 days
RESPONSE TIME: Average ${data.avgResponseTime} hours
PROJECT STATUS: ${data.projectStatus}
TASK COMPLETION RATE: ${data.taskCompletionRate}%

Provide sentiment analysis as JSON:
{
  "overallSentiment": "positive|neutral|negative|concerning",
  "sentimentScore": 0.0-1.0,
  "signals": {
    "positive": ["List of positive signals"],
    "concerning": ["List of concerning signals"]
  },
  "healthScore": 0-100,
  "recommendations": ["Recommended", "actions"],
  "riskLevel": "low|medium|high"
}`;

    try {
      const response = await this.anthropic.messages.create({
        model: this.model,
        max_tokens: 1500,
        messages: [{
          role: 'user',
          content: prompt
        }]
      });

      return JSON.parse(response.content[0].text);

    } catch (error) {
      logger.error('Error analyzing sentiment:', error);
      return {
        overallSentiment: 'neutral',
        sentimentScore: 0.5,
        healthScore: 50,
        signals: { positive: [], concerning: [] },
        recommendations: [],
        riskLevel: 'low'
      };
    }
  }

  // ========================================================================
  // PRIVATE HELPER METHODS
  // ========================================================================

  _buildHeadsUpPrompt(context) {
    const {
      client,
      contact,
      projectStatus,
      performanceMetrics,
      recentTranscripts,
      services
    } = context;

    return `You are generating a real-time intelligence brief for an employee receiving a call.

CLIENT: ${client.name}
CONTACT: ${contact.first_name} ${contact.last_name} (${contact.role || 'Unknown role'})
COMMUNICATION STYLE: ${client.communication_style}
EMOTIONAL TRIGGER: ${client.emotional_trigger}

CURRENT PROJECT STATUS: ${projectStatus || 'No active projects'}

LAST 30 DAYS PERFORMANCE:
- Sessions: ${performanceMetrics?.sessions || 'N/A'} (${performanceMetrics?.sessions_change_pct > 0 ? '+' : ''}${performanceMetrics?.sessions_change_pct || 0}%)
- Users: ${performanceMetrics?.users || 'N/A'}
- Bounce Rate: ${performanceMetrics?.bounce_rate || 'N/A'}%
- Conversions: ${performanceMetrics?.conversions || 'N/A'}

RECENT CONVERSATIONS:
${recentTranscripts?.slice(0, 2).map(t => `- [${t.date}] ${t.summary}`).join('\n') || 'No recent calls'}

AVAILABLE SERVICES TO RECOMMEND:
${services?.map(s => `- ${s.name}: ${s.description} (Ideal for: ${s.ideal_for?.join(', ')})`).join('\n')}

Generate a response in JSON format:
{
  "quickSummary": "2-sentence client overview for the employee",
  "topRecommendation": {
    "service": "Service name",
    "reason": "Why this makes sense now",
    "confidenceScore": 0.0-1.0
  },
  "talkingPoints": [
    "Point 1: Specific, actionable talking point",
    "Point 2: Reference to their performance or goal"
  ],
  "contextNotes": ["Important", "context", "items"],
  "sentiment": "Current relationship sentiment",
  "suggestedTone": "Recommended tone for this call"
}

Make it conversational, specific, and immediately actionable. Return ONLY valid JSON.`;
  }

  _parseHeadsUpResponse(text) {
    try {
      // Clean potential markdown code blocks
      const cleaned = text.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
      return JSON.parse(cleaned);
    } catch (error) {
      logger.error('Error parsing heads-up response:', error);
      throw new Error('Invalid AI response format');
    }
  }

  _detectConflicts(salesData, acceloData) {
    const conflicts = [];

    if (salesData.budget && acceloData.budget) {
      if (Math.abs(salesData.budget - acceloData.budget) > 100) {
        conflicts.push({
          field: 'budget',
          salesValue: salesData.budget,
          acceloValue: acceloData.budget,
          severity: 'high'
        });
      }
    }

    if (salesData.clientName && acceloData.name) {
      if (salesData.clientName.toLowerCase() !== acceloData.name.toLowerCase()) {
        conflicts.push({
          field: 'client_name',
          salesValue: salesData.clientName,
          acceloValue: acceloData.name,
          severity: 'medium'
        });
      }
    }

    return conflicts;
  }
}

// Singleton instance
let instance = null;

module.exports = {
  getInstance: () => {
    if (!instance) {
      instance = new AIEngine();
    }
    return instance;
  },
  AIEngine
};
