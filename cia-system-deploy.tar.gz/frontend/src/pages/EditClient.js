import React, { useEffect, useState } from 'react';
import { Box, IconButton, Typography, Card, CardContent, TextField, Button, CircularProgress } from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import { useNavigate, useParams } from 'react-router-dom';
import axios from 'axios';
import { isDevMode } from '../App';

export default function EditClient() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [client, setClient] = useState(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const load = async () => {
      try {
        const res = await axios.get(`/api/clients/${id}`);
        setClient(res.data);
      } catch (err) {
        if (isDevMode()) {
          const mock = (window.__MOCK_DATA__ && window.__MOCK_DATA__.clients) || [];
          const found = mock.find(c => String(c.id) === String(id));
          setClient(found || { id, name: `Client ${id}`, industry: '', communication_style: '' });
        } else {
          setClient({ id, name: `Client ${id}`, industry: '', communication_style: '' });
        }
      }
    };
    load();
  }, [id]);

  const handleSave = async () => {
    setSaving(true);
    try {
      await axios.put(`/api/clients/${id}`, client);
      window.alert('Client saved');
      navigate(-1);
    } catch (err) {
      if (isDevMode()) {
        console.warn('Dev mode: simulated save', client);
        window.alert('(Simulated) Client saved');
        navigate(-1);
      } else {
        console.error('Error saving client:', err);
        window.alert('Error saving client. See console.');
      }
    } finally {
      setSaving(false);
    }
  };

  if (!client) return <CircularProgress />;

  return (
    <Box>
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
        <IconButton onClick={() => navigate(-1)} sx={{ mr: 2 }}><ArrowBackIcon /></IconButton>
        <Typography variant="h5">Edit {client.name}</Typography>
      </Box>
      <Card>
        <CardContent>
          <TextField label="Name" fullWidth value={client.name} onChange={(e) => setClient({ ...client, name: e.target.value })} sx={{ mb: 2 }} />
          <TextField label="Industry" fullWidth value={client.industry} onChange={(e) => setClient({ ...client, industry: e.target.value })} sx={{ mb: 2 }} />
          <TextField label="Communication Style" fullWidth value={client.communication_style || client.communicationStyle || ''} onChange={(e) => setClient({ ...client, communication_style: e.target.value })} sx={{ mb: 2 }} />
          <Box sx={{ display: 'flex', gap: 1 }}>
            <Button variant="contained" onClick={handleSave} disabled={saving}>{saving ? 'Saving…' : 'Save'}</Button>
            <Button variant="outlined" onClick={() => navigate(-1)}>Cancel</Button>
          </Box>
        </CardContent>
      </Card>
    </Box>
  );
}
