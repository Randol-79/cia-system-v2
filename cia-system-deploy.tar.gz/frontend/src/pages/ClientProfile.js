import React, { useEffect, useState } from 'react';
import { Box, IconButton, Typography, Card, CardContent, Button, CircularProgress } from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import { useNavigate, useParams } from 'react-router-dom';
import axios from 'axios';
import { isDevMode } from '../App';

export default function ClientProfile() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [client, setClient] = useState(null);

  useEffect(() => {
    const load = async () => {
      try {
        const res = await axios.get(`/api/clients/${id}`);
        setClient(res.data);
      } catch (err) {
        if (isDevMode()) {
          // Try to fetch from global mock via window (fallback)
          const mock = (window.__MOCK_DATA__ && window.__MOCK_DATA__.clients) || [];
          const found = mock.find(c => String(c.id) === String(id));
          setClient(found || { id, name: `Client ${id}`, industry: 'Unknown', health_score: 0 });
        } else {
          setClient({ id, name: `Client ${id}`, industry: 'Unknown', health_score: 0 });
        }
      }
    };
    load();
  }, [id]);

  if (!client) return <CircularProgress />;

  return (
    <Box>
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
        <IconButton onClick={() => navigate(-1)} sx={{ mr: 2 }}><ArrowBackIcon /></IconButton>
        <Typography variant="h4">{client.name}</Typography>
      </Box>

      <Card sx={{ mb: 2 }}>
        <CardContent>
          <Typography variant="subtitle2">Industry</Typography>
          <Typography variant="body1">{client.industry}</Typography>
          <Typography variant="subtitle2" sx={{ mt: 1 }}>Health Score</Typography>
          <Typography variant="body1">{client.health_score}/100</Typography>
          <Box sx={{ mt: 2, display: 'flex', gap: 1 }}>
            <Button variant="contained" onClick={() => navigate(`/clients/${id}/contact`)}>Contact</Button>
            <Button variant="outlined" onClick={() => navigate(`/clients/${id}/edit`)}>Edit</Button>
          </Box>
        </CardContent>
      </Card>
    </Box>
  );
}
