# CIA System - Complete Setup & Deployment Guide

## 📋 Table of Contents
1. [Prerequisites](#prerequisites)
2. [Initial Setup](#initial-setup)
3. [Database Setup](#database-setup)
4. [Integration Configuration](#integration-configuration)
5. [Running the System](#running-the-system)
6. [Testing](#testing)
7. [Production Deployment](#production-deployment)
8. [Troubleshooting](#troubleshooting)

## 🔧 Prerequisites

### Required Software
- **Node.js** >= 18.x ([Download](https://nodejs.org/))
- **PostgreSQL** >= 14.x ([Download](https://www.postgresql.org/download/))
- **Redis** >= 6.x ([Download](https://redis.io/download))
- **Git** ([Download](https://git-scm.com/downloads))

### Required API Keys & Accounts
1. **Anthropic Claude API** - [Get API Key](https://console.anthropic.com/)
2. **Slack App** - [Create Slack App](https://api.slack.com/apps)
3. **Accelo Account** - Your existing CRM access
4. **Google Cloud Project** - For Analytics & Search Console API
5. **Fireflies.ai Account** - Your existing account
6. **Zoom Account** - With webhook capabilities

## 🚀 Initial Setup

### 1. Clone or Extract the Repository
```bash
cd CIA-System
```

### 2. Install Backend Dependencies
```bash
cd backend
npm install
cd ..
```

### 3. Install Frontend Dependencies
```bash
cd frontend
npm install
cd ..
```

### 4. Create Environment Configuration
```bash
cp .env.example .env
```

Now edit `.env` with your actual credentials. See [Integration Configuration](#integration-configuration) below.

## 🗄️ Database Setup

### Option 1: Docker (Recommended for Quick Start)
```bash
# Start PostgreSQL and Redis using Docker Compose
docker-compose up -d postgres redis

# Wait for databases to be ready (about 10 seconds)
sleep 10

# Verify they're running
docker-compose ps
```

### Option 2: Local Installation

#### PostgreSQL Setup
```bash
# macOS (using Homebrew)
brew install postgresql@14
brew services start postgresql@14

# Ubuntu/Debian
sudo apt update
sudo apt install postgresql-14
sudo systemctl start postgresql

# Windows
# Download and install from https://www.postgresql.org/download/windows/
```

Create the database:
```bash
# Connect to PostgreSQL
psql -U postgres

# In psql prompt:
CREATE DATABASE cia_db;
CREATE USER cia_user WITH PASSWORD 'your_secure_password';
GRANT ALL PRIVILEGES ON DATABASE cia_db TO cia_user;
\q
```

#### Redis Setup
```bash
# macOS
brew install redis
brew services start redis

# Ubuntu/Debian
sudo apt install redis-server
sudo systemctl start redis

# Windows
# Use WSL or download from https://redis.io/download
```

### 3. Initialize Database Schema
```bash
# Run migrations
psql -U cia_user -d cia_db -f database/schema.sql

# Or using npm script:
cd backend
npm run db:migrate
```

### 4. Verify Database Setup
```bash
psql -U cia_user -d cia_db

# In psql:
\dt  # List all tables
# You should see: clients, contacts, projects, tasks, etc.
```

## 🔌 Integration Configuration

### 1. Anthropic Claude API

1. Go to [console.anthropic.com](https://console.anthropic.com/)
2. Create an API key
3. Add to `.env`:
```env
ANTHROPIC_API_KEY=sk-ant-api03-your-key-here
```

### 2. Slack Integration

#### Create Slack App
1. Go to [api.slack.com/apps](https://api.slack.com/apps)
2. Click "Create New App" → "From scratch"
3. Name it "CIA System" and select your workspace

#### Configure Bot Permissions
Go to "OAuth & Permissions" and add these scopes:
- `chat:write`
- `chat:write.public`
- `users:read`
- `channels:read`
- `im:write`
- `commands`

#### Install App to Workspace
1. Click "Install to Workspace"
2. Copy the Bot Token that starts with `xoxb-`

#### Enable Socket Mode (for real-time events)
1. Go to "Socket Mode" and enable it
2. Generate an App-Level Token
3. Copy the token (starts with `xapp-`)

#### Create Slash Command
1. Go to "Slash Commands"
2. Create command: `/cia`
3. Request URL: `https://your-domain.com/slack/commands/cia`

#### Enable Event Subscriptions
1. Go to "Event Subscriptions"
2. Enable Events
3. Request URL: `https://your-domain.com/slack/events`

#### Add to `.env`:
```env
SLACK_BOT_TOKEN=xoxb-your-token
SLACK_SIGNING_SECRET=your-signing-secret
SLACK_APP_TOKEN=xapp-your-app-token
SLACK_CHANNEL_SALES=#sales
SLACK_CHANNEL_PM=#project-management
```

### 3. Accelo CRM

1. Log in to your Accelo account
2. Go to Settings → Integrations → API
3. Create a new API application
4. Copy your credentials

Add to `.env`:
```env
ACCELO_DEPLOYMENT=your-company
ACCELO_CLIENT_ID=your_client_id
ACCELO_CLIENT_SECRET=your_client_secret
ACCELO_BASE_URL=https://your-company.api.accelo.com
```

### 4. Google Analytics & Search Console

#### Create Service Account (Recommended)
1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select existing
3. Enable APIs:
   - Google Analytics Data API
   - Google Search Console API
4. Create Service Account:
   - IAM & Admin → Service Accounts → Create
   - Download JSON key file
5. Share GA & GSC properties with service account email

Add to `.env`:
```env
GOOGLE_SERVICE_ACCOUNT_EMAIL=your-sa@project.iam.gserviceaccount.com
GOOGLE_SERVICE_ACCOUNT_KEY=./config/google-service-account.json
```

#### Or Use OAuth (Alternative)
```env
GOOGLE_CLIENT_ID=your-id.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=your-secret
GOOGLE_REDIRECT_URI=http://localhost:5000/auth/google/callback
```

### 5. Fireflies.ai

1. Log in to Fireflies.ai
2. Go to Settings → Integrations → API
3. Generate API key

Add to `.env`:
```env
FIREFLIES_API_KEY=your_api_key
FIREFLIES_GDRIVE_FOLDER_ID=your_folder_id
```

### 6. Zoom Webhooks

1. Go to [Zoom App Marketplace](https://marketplace.zoom.us/)
2. Develop → Build App → Webhook Only
3. Add webhook endpoint: `https://your-domain.com/webhooks/zoom/events`
4. Subscribe to events:
   - Meeting Started
   - Participant Joined
5. Copy webhook secret token

Add to `.env`:
```env
ZOOM_WEBHOOK_SECRET=your_secret
```

## ▶️ Running the System

### Development Mode

#### Terminal 1: Start Databases (if using Docker)
```bash
docker-compose up postgres redis
```

#### Terminal 2: Start Backend
```bash
cd backend
npm run dev
```

The API will be available at `http://localhost:5000`

#### Terminal 3: Start Frontend
```bash
cd frontend
npm start
```

The dashboard will be available at `http://localhost:3000`

### Verify Everything is Running
```bash
# Check API health
curl http://localhost:5000/health

# Check integrations
curl http://localhost:5000/health/integrations

# Access frontend
open http://localhost:3000
```

## 🧪 Testing

### Manual Testing

#### Test Slack Command
In Slack, type:
```
/cia Acme Corp
```

You should receive a detailed intelligence report.

#### Test Webhook (Zoom Call Simulation)
```bash
curl -X POST http://localhost:5000/webhooks/zoom/events \
  -H "Content-Type: application/json" \
  -d '{
    "event": "meeting.started",
    "payload": {
      "participant": {
        "email": "john@acmecorp.com"
      },
      "object": {
        "id": "123456",
        "topic": "Sales Call with Acme Corp"
      }
    }
  }'
```

#### Test AI Generation
```bash
curl -X POST http://localhost:5000/api/clients/test-client-id/intelligence \
  -H "Content-Type: application/json"
```

### Run Automated Tests
```bash
cd backend
npm test
```

## 🚢 Production Deployment

### Option 1: Docker Compose (Simplest)

1. **Update Environment Variables**
```bash
# Edit .env for production values
NODE_ENV=production
```

2. **Start All Services**
```bash
docker-compose --profile production up -d
```

3. **Setup SSL/HTTPS**
- Use Let's Encrypt with Certbot
- Update nginx configuration with SSL certificates

4. **Setup Domain**
- Point your domain to server IP
- Update ALLOWED_ORIGINS in .env

### Option 2: Cloud Deployment (AWS/GCP/Azure)

#### AWS Example
1. **Database**: Use RDS for PostgreSQL and ElastiCache for Redis
2. **Backend**: Deploy to ECS/Fargate or EC2
3. **Frontend**: Host on S3 + CloudFront
4. **Load Balancer**: Use Application Load Balancer
5. **Secrets**: Use AWS Secrets Manager

#### Environment Setup
```bash
# Update .env with cloud service URLs
DATABASE_URL=postgresql://user:pass@your-rds-endpoint:5432/cia_db
REDIS_URL=redis://your-elasticache-endpoint:6379
```

### Option 3: Platform as a Service

#### Heroku
```bash
# Install Heroku CLI
heroku create cia-system

# Add addons
heroku addons:create heroku-postgresql:standard-0
heroku addons:create heroku-redis:premium-0

# Set config vars
heroku config:set ANTHROPIC_API_KEY=your-key
heroku config:set SLACK_BOT_TOKEN=your-token
# ... (all other env vars)

# Deploy
git push heroku main
```

#### Render.com
1. Connect GitHub repository
2. Create PostgreSQL database
3. Create Redis instance
4. Create Web Service
5. Set environment variables
6. Deploy

### Post-Deployment Checklist

- [ ] All environment variables set
- [ ] Database migrations run
- [ ] SSL certificates installed
- [ ] Webhooks configured with public URLs
- [ ] Slack app webhooks pointing to production
- [ ] Health checks passing
- [ ] Monitoring setup (Datadog, New Relic, etc.)
- [ ] Backup strategy implemented
- [ ] Team trained on system

## 🔍 Troubleshooting

### Database Connection Issues
```bash
# Test PostgreSQL connection
psql -U cia_user -d cia_db -c "SELECT 1;"

# Check if Redis is running
redis-cli ping
# Should return: PONG
```

### API Not Starting
```bash
# Check logs
tail -f backend/logs/app.log

# Common issues:
# 1. Port 5000 already in use
lsof -i :5000
# Kill process using the port

# 2. Missing dependencies
cd backend && npm install
```

### Slack Integration Not Working
1. Verify Slack tokens in `.env`
2. Check Request URL is publicly accessible
3. Test with:
```bash
curl -X POST http://localhost:5000/slack/commands/cia \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "command=/cia&text=Acme Corp&user_id=U123"
```

### Webhooks Not Firing
1. **Use ngrok for local testing:**
```bash
ngrok http 5000
# Copy the https URL and update webhook endpoints
```

2. **Check webhook logs:**
```bash
tail -f backend/logs/webhooks.log
```

### AI Recommendations Not Generating
1. Verify Anthropic API key
2. Check API usage limits
3. Test AI engine:
```bash
curl http://localhost:5000/api/test/ai-engine
```

## 📞 Support

### Documentation
- Full API docs: `http://localhost:5000/api/docs`
- Architecture diagram: See README.md

### Common Commands
```bash
# View all logs
docker-compose logs -f

# Restart a service
docker-compose restart backend

# Access database
docker-compose exec postgres psql -U cia_user -d cia_db

# Clear Redis cache
docker-compose exec redis redis-cli FLUSHALL

# Run database backup
pg_dump -U cia_user cia_db > backup_$(date +%Y%m%d).sql
```

---

**Congratulations!** 🎉 Your CIA System should now be up and running. Start with a few test clients and gradually roll out to your full team.
