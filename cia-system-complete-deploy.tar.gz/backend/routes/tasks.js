const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  // Sample tasks data
  const tasks = [
    {
      id: 1,
      title: 'Follow up on Cloud Migration proposal',
      client_name: 'Acme Corporation',
      type: 'follow_up',
      priority: 'high',
      status: 'pending',
      due_date: '2025-01-25T17:00:00Z',
      created_at: '2025-01-20T10:30:00Z',
      description: 'Discuss cloud migration strategy proposal sent last week. Client showed high interest.'
    },
    {
      id: 2,
      title: 'Schedule preventive maintenance review',
      client_name: 'Global Dynamics',
      type: 'meeting',
      priority: 'medium',
      status: 'pending',
      due_date: '2025-01-27T14:00:00Z',
      created_at: '2025-01-19T14:15:00Z',
      description: 'Review equipment maintenance logs and present preventive maintenance program benefits.'
    },
    {
      id: 3,
      title: 'Prepare AI/ML services presentation',
      client_name: 'Innovatech Solutions',
      type: 'preparation',
      priority: 'high',
      status: 'in_progress',
      due_date: '2025-01-24T10:00:00Z',
      created_at: '2025-01-18T09:45:00Z',
      description: 'Create detailed presentation showcasing AI/ML development capabilities and case studies.'
    },
    {
      id: 4,
      title: 'Compliance audit documentation',
      client_name: 'Healthcare Plus',
      type: 'documentation',
      priority: 'high',
      status: 'pending',
      due_date: '2025-01-26T16:00:00Z',
      created_at: '2025-01-17T16:20:00Z',
      description: 'Compile compliance audit support materials and regulatory change summary.'
    },
    {
      id: 5,
      title: 'Security assessment scope definition',
      client_name: 'Acme Corporation',
      type: 'scoping',
      priority: 'medium',
      status: 'pending',
      due_date: '2025-01-28T15:00:00Z',
      created_at: '2025-01-16T11:00:00Z',
      description: 'Define scope for security assessment and prepare initial assessment plan.'
    },
    {
      id: 6,
      title: 'Quarterly business review preparation',
      client_name: 'Innovatech Solutions',
      type: 'meeting',
      priority: 'medium',
      status: 'completed',
      due_date: '2025-01-22T13:00:00Z',
      created_at: '2025-01-10T09:00:00Z',
      completed_at: '2025-01-22T12:45:00Z',
      description: 'Prepare QBR presentation with metrics, achievements, and future roadmap.'
    },
    {
      id: 7,
      title: 'Re-engagement strategy for Finance First',
      client_name: 'Finance First',
      type: 'strategy',
      priority: 'low',
      status: 'pending',
      due_date: '2025-02-01T12:00:00Z',
      created_at: '2025-01-15T08:30:00Z',
      description: 'Develop strategy to re-engage inactive client with relevant compliance and security offerings.'
    },
    {
      id: 8,
      title: 'Update client success metrics dashboard',
      client_name: 'All Clients',
      type: 'internal',
      priority: 'low',
      status: 'pending',
      due_date: '2025-01-30T17:00:00Z',
      created_at: '2025-01-14T10:00:00Z',
      description: 'Update internal dashboard with latest client health scores and engagement metrics.'
    }
  ];

  // Filter by status if provided
  const status = req.query.status;
  const filtered = status ? tasks.filter(t => t.status === status) : tasks;
  
  res.json(filtered);
});

module.exports = router;
