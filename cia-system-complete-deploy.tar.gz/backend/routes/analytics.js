const express = require('express');
const router = express.Router();

// Dashboard stats endpoint
router.get('/dashboard-stats', async (req, res) => {
  try {
    res.json({
      activeClients: 12,
      pendingTasks: 8,
      completedThisMonth: 45,
      revenue: 125000
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Recent events endpoint
router.get('/recent-events', async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 10;
    const events = [
      { id: 1, type: 'call_completed', client: 'Acme Corp', timestamp: new Date().toISOString() },
      { id: 2, type: 'recommendation_sent', client: 'TechStart Inc', timestamp: new Date().toISOString() }
    ];
    res.json(events.slice(0, limit));
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/', (req, res) => {
  res.json({ analytics: [] });
});

module.exports = router;