/**
 * Slack Integration Service
 * Handles all Slack API interactions and message formatting
 */

const { WebClient } = require('@slack/web-api');
const { App } = require('@slack/bolt');
const logger = require('../../utils/logger');

class SlackService {
  constructor() {
    try {
      // Only initialize Slack if we have valid (non-placeholder) tokens
      const hasValidToken = process.env.SLACK_BOT_TOKEN && 
                           process.env.SLACK_BOT_TOKEN !== 'your-bot-token' &&
                           process.env.SLACK_BOT_TOKEN.startsWith('xoxb-');
      
      this.client = hasValidToken ? new WebClient(process.env.SLACK_BOT_TOKEN) : null;
      this.app = null;
      
      // Disable Slack App initialization for now - it tries to connect with socketMode
      // Can be re-enabled when proper credentials are provided
      /*
      if (hasValidToken && process.env.SLACK_APP_TOKEN && process.env.SLACK_SIGNING_SECRET) {
        this.app = new App({
          token: process.env.SLACK_BOT_TOKEN,
          signingSecret: process.env.SLACK_SIGNING_SECRET,
          appToken: process.env.SLACK_APP_TOKEN,
          socketMode: true
        });
      }
      */
      
      if (!hasValidToken) {
        logger.warn('Slack credentials not configured - Slack integration disabled');
      }
    } catch (error) {
      logger.error('Failed to initialize Slack service:', error);
      this.client = null;
      this.app = null;
    }
  }

  /**
   * Format Heads-Up Display message for Slack
   */
  formatHeadsUpDisplay({ client, contact, intelligence, metrics, callType }) {
    const blocks = [
      {
        type: 'header',
        text: {
          type: 'plain_text',
          text: `📞 ${callType === 'incoming' ? 'Incoming' : 'Scheduled'} Call Alert`,
          emoji: true
        }
      },
      {
        type: 'section',
        fields: [
          {
            type: 'mrkdwn',
            text: `*Client:*\n${client.name}`
          },
          {
            type: 'mrkdwn',
            text: `*Contact:*\n${contact.first_name} ${contact.last_name}${contact.role ? ` (${contact.role})` : ''}`
          }
        ]
      },
      {
        type: 'divider'
      },
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: `*Quick Summary*\n${intelligence.quickSummary}`
        }
      }
    ];

    // Add performance snapshot if available
    if (metrics) {
      blocks.push({
        type: 'section',
        fields: [
          {
            type: 'mrkdwn',
            text: `*Last 30 Days Traffic*\n${metrics.sessions || 'N/A'} sessions ${this._formatChange(metrics.sessions_change_pct)}`
          },
          {
            type: 'mrkdwn',
            text: `*Conversions*\n${metrics.conversions || 'N/A'} ${this._formatChange(metrics.conversions_change_pct)}`
          }
        ]
      });
    }

    // Add top recommendation
    if (intelligence.topRecommendation) {
      blocks.push(
        {
          type: 'divider'
        },
        {
          type: 'section',
          text: {
            type: 'mrkdwn',
            text: `*🎯 Top Recommendation*\n*${intelligence.topRecommendation.service}*\n${intelligence.topRecommendation.reason}`
          }
        }
      );
    }

    // Add talking points
    if (intelligence.talkingPoints && intelligence.talkingPoints.length > 0) {
      blocks.push(
        {
          type: 'section',
          text: {
            type: 'mrkdwn',
            text: `*💡 Talking Points*\n${intelligence.talkingPoints.map((p, i) => `${i + 1}. ${p}`).join('\n')}`
          }
        }
      );
    }

    // Add context notes
    if (intelligence.contextNotes && intelligence.contextNotes.length > 0) {
      blocks.push({
        type: 'context',
        elements: intelligence.contextNotes.map(note => ({
          type: 'mrkdwn',
          text: note
        }))
      });
    }

    return {
      text: `Incoming call from ${client.name} - ${contact.first_name} ${contact.last_name}`,
      blocks
    };
  }

  /**
   * Format sales admin draft message
   */
  formatSalesAdminDraft({ salesData, conflicts, client }) {
    const blocks = [
      {
        type: 'header',
        text: {
          type: 'plain_text',
          text: '📋 Sales Call - Action Required',
          emoji: true
        }
      },
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: `A sales call transcript has been processed. Please review and update Accelo.`
        }
      },
      {
        type: 'divider'
      },
      {
        type: 'section',
        fields: [
          {
            type: 'mrkdwn',
            text: `*Client Name:*\n${salesData.clientName}`
          },
          {
            type: 'mrkdwn',
            text: `*Budget:*\n${salesData.budget ? `$${salesData.budget.toLocaleString()}` : 'Not mentioned'}`
          },
          {
            type: 'mrkdwn',
            text: `*Timeline:*\n${salesData.timeline || 'Not specified'}`
          },
          {
            type: 'mrkdwn',
            text: `*Urgency:*\n${salesData.urgency || 'Medium'}`
          }
        ]
      }
    ];

    // Add conflicts warning if any
    if (conflicts && conflicts.length > 0) {
      blocks.push(
        {
          type: 'section',
          text: {
            type: 'mrkdwn',
            text: `:warning: *Data Conflicts Detected*\n${conflicts.map(c => 
              `• ${c.field}: Sales says "${c.salesValue}", Accelo has "${c.acceloValue}"`
            ).join('\n')}`
          }
        }
      );
    }

    // Add project scope
    blocks.push(
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: `*Project Scope:*\n${salesData.projectScope || 'Not specified'}`
        }
      }
    );

    // Add action buttons
    blocks.push(
      {
        type: 'actions',
        elements: [
          {
            type: 'button',
            text: {
              type: 'plain_text',
              text: 'View Full Transcript',
              emoji: true
            },
            value: 'view_transcript',
            action_id: 'view_transcript'
          },
          {
            type: 'button',
            text: {
              type: 'plain_text',
              text: 'Update Accelo',
              emoji: true
            },
            url: `${process.env.ACCELO_BASE_URL}/companies/${client.accelo_id}`,
            action_id: 'update_accelo'
          }
        ]
      }
    );

    return {
      text: `Sales call processed for ${salesData.clientName}`,
      blocks
    };
  }

  /**
   * Format task nudge draft message
   */
  formatNudgeDraft({ task, nudge }) {
    const blocks = [
      {
        type: 'header',
        text: {
          type: 'plain_text',
          text: '⏰ Client Nudge Needed',
          emoji: true
        }
      },
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: `Task *"${task.title}"* has been waiting ${task.days_waiting} days.`
        }
      },
      {
        type: 'section',
        fields: [
          {
            type: 'mrkdwn',
            text: `*Client:*\n${task.client_name}`
          },
          {
            type: 'mrkdwn',
            text: `*Project:*\n${task.project_name}`
          }
        ]
      },
      {
        type: 'divider'
      },
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: `*📧 Suggested Email*\n\n*Subject:* ${nudge.subject}\n\n${nudge.body.substring(0, 500)}${nudge.body.length > 500 ? '...' : ''}`
        }
      },
      {
        type: 'actions',
        elements: [
          {
            type: 'button',
            text: {
              type: 'plain_text',
              text: 'Copy Email',
              emoji: true
            },
            value: 'copy_email',
            action_id: 'copy_nudge_email'
          },
          {
            type: 'button',
            text: {
              type: 'plain_text',
              text: 'Mark as Sent',
              emoji: true
            },
            value: task.id,
            action_id: 'mark_nudge_sent',
            style: 'primary'
          }
        ]
      }
    ];

    return {
      text: `Nudge needed for ${task.client_name}`,
      blocks
    };
  }

  /**
   * Send detailed client report (for manual lookup)
   */
  async sendDetailedClientReport({ client, data, intelligence, userId }) {
    const blocks = [
      {
        type: 'header',
        text: {
          type: 'plain_text',
          text: `📊 Intelligence Report: ${client.name}`,
          emoji: true
        }
      },
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: intelligence.quickSummary
        }
      },
      {
        type: 'divider'
      },
      {
        type: 'section',
        fields: [
          {
            type: 'mrkdwn',
            text: `*Status:*\n${client.status}`
          },
          {
            type: 'mrkdwn',
            text: `*Health Score:*\n${client.health_score}/100`
          },
          {
            type: 'mrkdwn',
            text: `*Industry:*\n${client.industry || 'Not specified'}`
          },
          {
            type: 'mrkdwn',
            text: `*Communication Style:*\n${client.communication_style || 'Not specified'}`
          }
        ]
      }
    ];

    // Add performance metrics
    if (data.performanceMetrics) {
      const m = data.performanceMetrics;
      blocks.push({
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: `*📈 Performance (Last 30 Days)*\n• Sessions: ${m.sessions || 'N/A'} ${this._formatChange(m.sessions_change_pct)}\n• Users: ${m.users || 'N/A'} ${this._formatChange(m.users_change_pct)}\n• Bounce Rate: ${m.bounce_rate || 'N/A'}%\n• Conversions: ${m.conversions || 0}`
        }
      });
    }

    // Add recommendations
    if (intelligence.topRecommendation) {
      blocks.push(
        {
          type: 'divider'
        },
        {
          type: 'section',
          text: {
            type: 'mrkdwn',
            text: `*🎯 Top Recommendation*\n*${intelligence.topRecommendation.service}*\n${intelligence.topRecommendation.reason}\n\n_Confidence: ${Math.round(intelligence.topRecommendation.confidenceScore * 100)}%_`
          }
        }
      );
    }

    // Send as DM to requesting user
    await this.client.chat.postMessage({
      channel: userId,
      text: `Intelligence Report: ${client.name}`,
      blocks
    });
  }

  /**
   * Send a message to a Slack channel
   */
  async sendMessage({ channel, text, blocks, threadTs = null }) {
    try {
      const result = await this.client.chat.postMessage({
        channel,
        text,
        blocks,
        thread_ts: threadTs
      });

      logger.debug(`Message sent to ${channel}: ${result.ts}`);
      return result;

    } catch (error) {
      logger.error('Error sending Slack message:', error);
      throw error;
    }
  }

  /**
   * Send DM to a user
   */
  async sendDirectMessage(userId, message) {
    return this.sendMessage({
      channel: userId,
      ...message
    });
  }

  /**
   * Send nudge draft to PM
   */
  async sendNudgeDraft({ task, nudge, pmChannel }) {
    const message = this.formatNudgeDraft({ task, nudge });
    return this.sendMessage({
      channel: pmChannel,
      ...message
    });
  }

  /**
   * Send sales admin draft
   */
  async sendSalesAdminDraft(data) {
    const message = this.formatSalesAdminDraft(data);
    return this.sendMessage({
      channel: process.env.SLACK_CHANNEL_SALES,
      ...message
    });
  }

  // Private helper methods

  _formatChange(changePct) {
    if (!changePct) return '';
    const emoji = changePct > 0 ? '📈' : changePct < 0 ? '📉' : '➡️';
    const sign = changePct > 0 ? '+' : '';
    return `${emoji} ${sign}${changePct.toFixed(1)}%`;
  }
}

module.exports = SlackService;
