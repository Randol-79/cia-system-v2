const logger = require('../utils/logger');

class WebSocketService {
  constructor(io) {
    this.io = io;
    logger.info('WebSocket service initialized (stub)');
  }

  initialize() {
    logger.info('WebSocket service setup complete');
  }

  emit(event, data) {
    if (this.io) {
      this.io.emit(event, data);
    }
  }
}

module.exports = WebSocketService;