/**
 * Redis Configuration
 * Connection and helper functions for Redis cache
 */

const logger = require('../utils/logger');

// If SKIP_EXTERNAL=true, return a no-op Redis stub to avoid connection errors during local dev
if (process.env.SKIP_EXTERNAL === 'true') {
  logger.warn('SKIP_EXTERNAL=true: Using Redis stub (no-op)');
  const stub = {
    on: () => {},
    quit: async () => {},
    get: async () => null,
    setex: async () => true,
    del: async () => true,
    exists: async () => false,
    expire: async () => true,
    incr: async () => 0,
    mget: async () => [],
    flushall: async () => true
  };
  module.exports = stub;
  module.exports.cache = {
    async get(key) { return null; },
    async set(key, value, expirationSeconds = 3600) { return true; },
    async del(key) { return true; },
    async exists(key) { return false; },
    async expire(key, seconds) { return true; },
    async incr(key) { return 0; },
    async mget(keys) { return []; },
    async flush() { return true; }
  };
  return;
}

const Redis = require('ioredis');

// Initialize Redis client
const redis = new Redis(process.env.REDIS_URL || 'redis://localhost:6379', {
  retryStrategy: (times) => {
    const delay = Math.min(times * 50, 2000);
    return delay;
  },
  maxRetriesPerRequest: 3,
  enableReadyCheck: true,
  enableOfflineQueue: true
});

// Event handlers
redis.on('connect', () => {
  logger.info('Redis client connected');
});

redis.on('ready', () => {
  logger.info('Redis client ready');
});

redis.on('error', (error) => {
  logger.error('Redis client error:', error);
});

redis.on('close', () => {
  logger.info('Redis connection closed');
});

redis.on('reconnecting', () => {
  logger.info('Redis client reconnecting');
});

/**
 * Cache helper functions
 */
const cache = {
  /**
   * Get value from cache
   */
  async get(key) {
    try {
      const value = await redis.get(key);
      return value ? JSON.parse(value) : null;
    } catch (error) {
      logger.error(`Error getting cache key ${key}:`, error);
      return null;
    }
  },

  /**
   * Set value in cache with expiration
   */
  async set(key, value, expirationSeconds = 3600) {
    try {
      await redis.setex(key, expirationSeconds, JSON.stringify(value));
      return true;
    } catch (error) {
      logger.error(`Error setting cache key ${key}:`, error);
      return false;
    }
  },

  /**
   * Delete key from cache
   */
  async del(key) {
    try {
      await redis.del(key);
      return true;
    } catch (error) {
      logger.error(`Error deleting cache key ${key}:`, error);
      return false;
    }
  },

  /**
   * Check if key exists
   */
  async exists(key) {
    try {
      const result = await redis.exists(key);
      return result === 1;
    } catch (error) {
      logger.error(`Error checking cache key ${key}:`, error);
      return false;
    }
  },

  /**
   * Set expiration on existing key
   */
  async expire(key, seconds) {
    try {
      await redis.expire(key, seconds);
      return true;
    } catch (error) {
      logger.error(`Error setting expiration on ${key}:`, error);
      return false;
    }
  },

  /**
   * Increment counter
   */
  async incr(key) {
    try {
      return await redis.incr(key);
    } catch (error) {
      logger.error(`Error incrementing ${key}:`, error);
      return null;
    }
  },

  /**
   * Get multiple keys
   */
  async mget(keys) {
    try {
      const values = await redis.mget(keys);
      return values.map(v => v ? JSON.parse(v) : null);
    } catch (error) {
      logger.error(`Error getting multiple keys:`, error);
      return [];
    }
  },

  /**
   * Clear all cache (use with caution!)
   */
  async flush() {
    try {
      await redis.flushall();
      logger.info('Redis cache flushed');
      return true;
    } catch (error) {
      logger.error('Error flushing Redis cache:', error);
      return false;
    }
  }
};

module.exports = redis;
module.exports.cache = cache;
