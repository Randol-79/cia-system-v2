import React, { useState } from 'react';
import { Box, IconButton, Typography, Card, CardContent, FormControl, InputLabel, Select, MenuItem, TextField, Button } from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import { useNavigate, useParams } from 'react-router-dom';
import axios from 'axios';
import { isDevMode } from '../App';

export default function ContactClient() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [method, setMethod] = useState('email');
  const [note, setNote] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSend = async () => {
    setLoading(true);
    try {
      // Try real API endpoint
      await axios.post(`/api/clients/${id}/contact`, { method, message: note });
      window.alert('Message sent successfully');
      navigate(-1);
    } catch (err) {
      if (isDevMode()) {
        // Simulated send in dev mode
        console.warn('Dev mode: simulated send', { id, method, note });
        window.alert(`(Simulated) Sent to client ${id} via ${method}`);
        navigate(-1);
      } else {
        console.error('Error sending contact:', err);
        window.alert('Error sending message. See console for details.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
        <IconButton onClick={() => navigate(-1)} sx={{ mr: 2 }}><ArrowBackIcon /></IconButton>
        <Typography variant="h5">Contact Client #{id}</Typography>
      </Box>
      <Card>
        <CardContent>
          <FormControl fullWidth sx={{ mb: 2 }}>
            <InputLabel>Method</InputLabel>
            <Select value={method} label="Method" onChange={(e) => setMethod(e.target.value)}>
              <MenuItem value="email">Email</MenuItem>
              <MenuItem value="phone">Phone</MenuItem>
              <MenuItem value="message">In-app Message</MenuItem>
            </Select>
          </FormControl>
          <TextField fullWidth multiline rows={4} value={note} onChange={(e) => setNote(e.target.value)} placeholder="Message or notes" sx={{ mb: 2 }} />
          <Box sx={{ display: 'flex', gap: 1 }}>
            <Button variant="contained" onClick={handleSend} disabled={loading}>{loading ? 'Sending…' : 'Send'}</Button>
            <Button variant="outlined" onClick={() => navigate(-1)}>Cancel</Button>
          </Box>
        </CardContent>
      </Card>
    </Box>
  );
}
