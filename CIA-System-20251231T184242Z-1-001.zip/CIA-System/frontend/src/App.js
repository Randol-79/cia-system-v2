/**
 * CIA System - Admin Dashboard
 * Main React Application
 */

import React, { useState, useEffect } from 'react';
import {
  Box,
  CssBaseline,
  ThemeProvider,
  createTheme,
  AppBar,
  Toolbar,
  Typography,
  Drawer,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  ListItemButton,
  Container,
  Grid,
  Card,
  CardContent,
  CardHeader,
  Chip,
  Alert,
  CircularProgress,
  Button,
  Snackbar,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Breadcrumbs,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Divider
} from '@mui/material';
import {
  Dashboard as DashboardIcon,
  People as PeopleIcon,
  AssignmentTurnedIn as TaskIcon,
  TrendingUp as TrendingUpIcon,
  Settings as SettingsIcon,
  Notifications as NotificationsIcon,
  CheckCircle as CheckCircleIcon,
  Warning as WarningIcon,
  Error as ErrorIcon,
  ArrowBack as ArrowBackIcon,
  Home as HomeIcon,
  Add as AddIcon,
  Assessment as AssessmentIcon,
  Download as DownloadIcon,
  Print as PrintIcon,
  FilterList as FilterListIcon,
  Close as CloseIcon,
  Close,
  People,
  TrendingUp,
  Task
} from '@mui/icons-material';
import { BrowserRouter as Router, Routes, Route, Link, useLocation, useNavigate } from 'react-router-dom';
import ClientProfile from './pages/ClientProfile';
import ContactClient from './pages/ContactClient';
import EditClient from './pages/EditClient';
import io from 'socket.io-client';
import axios from 'axios';

// Configure axios defaults
axios.defaults.baseURL = process.env.REACT_APP_API_URL || 'http://localhost:5000';

// ============================================================================
// DEVELOPMENT MODE STATE - Global toggle for mock data
// ============================================================================
let USE_MOCK_DATA = localStorage.getItem('comit_dev_mode') === 'true';

export const setDevMode = (enabled) => {
  USE_MOCK_DATA = enabled;
  localStorage.setItem('comit_dev_mode', enabled.toString());
  console.log(`🔧 Development Mode: ${enabled ? 'ENABLED (Using Mock Data)' : 'DISABLED (Using Real API)'}`);
};

export const isDevMode = () => USE_MOCK_DATA;

// ============================================================================
// MOCK DATA CONTAINER - Isolated from real data
// ============================================================================
const MOCK_DATA = {
  stats: {
    activeClients: 12,
    pendingTasks: 8,
    completedThisMonth: 34,
    revenue: 125000
  },
  
  events: [
    { id: 1, type: 'call_completed', event_type: 'call_completed', client: 'Acme Corp', status: 'completed', timestamp: new Date().toISOString(), description: 'Sales call with decision maker' },
    { id: 2, type: 'recommendation_generated', event_type: 'recommendation_generated', client: 'TechStart Inc', status: 'pending', timestamp: new Date(Date.now() - 3600000).toISOString(), description: 'AI recommended follow-up strategy' },
    { id: 3, type: 'task_completed', event_type: 'task_completed', client: 'Global Solutions', status: 'completed', timestamp: new Date(Date.now() - 7200000).toISOString(), description: 'Contract review completed' },
    { id: 4, type: 'integration_sync', event_type: 'integration_sync', client: 'Fireflies', status: 'completed', timestamp: new Date(Date.now() - 10800000).toISOString(), description: 'Meeting transcripts synced' },
    { id: 5, type: 'call_completed', event_type: 'call_completed', client: 'Enterprise Co', status: 'completed', timestamp: new Date(Date.now() - 14400000).toISOString(), description: 'Product demo call' }
  ],
  
  allEvents: [
    { id: 1, type: 'call_completed', event_type: 'call_completed', client: 'Acme Corp', status: 'completed', timestamp: new Date().toISOString(), description: 'Sales call with decision maker', related_clients: ['Acme Corp', 'Acme Subsidiary'], related_tasks: ['Follow-up email', 'Send proposal'], actionable: true },
    { id: 2, type: 'recommendation_generated', event_type: 'recommendation_generated', client: 'TechStart Inc', status: 'pending', timestamp: new Date(Date.now() - 3600000).toISOString(), description: 'AI recommended follow-up strategy', related_clients: ['TechStart Inc'], related_tasks: ['Schedule demo'], actionable: true },
    { id: 3, type: 'task_completed', event_type: 'task_completed', client: 'Global Solutions', status: 'completed', timestamp: new Date(Date.now() - 7200000).toISOString(), description: 'Contract review completed', related_clients: ['Global Solutions'], related_tasks: [], actionable: false },
    { id: 4, type: 'integration_sync', event_type: 'integration_sync', client: 'Fireflies', status: 'completed', timestamp: new Date(Date.now() - 10800000).toISOString(), description: 'Meeting transcripts synced', related_clients: [], related_tasks: [], actionable: false },
    { id: 5, type: 'call_completed', event_type: 'call_completed', client: 'Enterprise Co', status: 'completed', timestamp: new Date(Date.now() - 14400000).toISOString(), description: 'Product demo call', related_clients: ['Enterprise Co'], related_tasks: ['Send follow-up', 'Schedule next meeting'], actionable: true },
    { id: 6, type: 'recommendation_approved', event_type: 'recommendation_approved', client: 'Beta Systems', status: 'completed', timestamp: new Date(Date.now() - 18000000).toISOString(), description: 'Recommendation approved and actioned', related_clients: ['Beta Systems'], related_tasks: ['Execute strategy'], actionable: false },
    { id: 7, type: 'task_created', event_type: 'task_created', client: 'Innovation Labs', status: 'pending', timestamp: new Date(Date.now() - 21600000).toISOString(), description: 'New task: Quarterly review', related_clients: ['Innovation Labs'], related_tasks: ['Q4 Review'], actionable: true },
    { id: 8, type: 'call_scheduled', event_type: 'call_scheduled', client: 'Dynamic Corp', status: 'pending', timestamp: new Date(Date.now() - 25200000).toISOString(), description: 'Call scheduled for next week', related_clients: ['Dynamic Corp'], related_tasks: ['Prepare agenda'], actionable: true }
  ],
  
  integrationHealth: {
    accelo: { is_healthy: true, last_check_at: new Date().toISOString(), status: 'healthy' },
    fireflies: { is_healthy: true, last_check_at: new Date().toISOString(), status: 'healthy' },
    google_analytics: { is_healthy: true, last_check_at: new Date().toISOString(), status: 'healthy' },
    slack: { is_healthy: false, last_check_at: new Date().toISOString(), status: 'error' }
  },
  
  clients: [
    { id: 1, name: 'Acme Corporation', industry: 'Technology', status: 'active', health_score: 85, communication_style: 'Direct and data-driven', emotional_trigger: 'Innovation and ROI' },
    { id: 2, name: 'TechStart Inc', industry: 'Software', status: 'active', health_score: 92, communication_style: 'Collaborative and agile', emotional_trigger: 'Speed to market' },
    { id: 3, name: 'Global Solutions Ltd', industry: 'Consulting', status: 'active', health_score: 78, communication_style: 'Formal and structured', emotional_trigger: 'Risk mitigation' },
    { id: 4, name: 'Enterprise Co', industry: 'Manufacturing', status: 'active', health_score: 88, communication_style: 'Results-oriented', emotional_trigger: 'Efficiency gains' },
    { id: 5, name: 'Innovation Labs', industry: 'Research', status: 'active', health_score: 95, communication_style: 'Exploratory and open', emotional_trigger: 'Cutting-edge technology' },
    { id: 6, name: 'Dynamic Corp', industry: 'Retail', status: 'active', health_score: 72, communication_style: 'Fast-paced', emotional_trigger: 'Customer satisfaction' },
    { id: 7, name: 'Beta Systems', industry: 'Finance', status: 'active', health_score: 81, communication_style: 'Analytical and cautious', emotional_trigger: 'Security and compliance' },
    { id: 8, name: 'Alpha Industries', industry: 'Healthcare', status: 'inactive', health_score: 65, communication_style: 'Regulatory-focused', emotional_trigger: 'Patient outcomes' }
  ],
  
  recommendations: [
    { id: 1, recommendation_type: 'follow_up', client_name: 'Acme Corporation', service_name: 'Send personalized proposal', confidence: 0.92, status: 'pending', created_at: new Date().toISOString() },
    { id: 2, recommendation_type: 'upsell', client_name: 'TechStart Inc', service_name: 'Premium support package', confidence: 0.88, status: 'pending', created_at: new Date(Date.now() - 3600000).toISOString() },
    { id: 3, recommendation_type: 'engagement', client_name: 'Global Solutions Ltd', service_name: 'Schedule quarterly review', confidence: 0.85, status: 'pending', created_at: new Date(Date.now() - 7200000).toISOString() },
    { id: 4, recommendation_type: 'retention', client_name: 'Enterprise Co', service_name: 'Offer renewal incentive', confidence: 0.91, status: 'pending', created_at: new Date(Date.now() - 10800000).toISOString() },
    { id: 5, recommendation_type: 'cross_sell', client_name: 'Innovation Labs', service_name: 'AI Analytics module', confidence: 0.87, status: 'pending', created_at: new Date(Date.now() - 14400000).toISOString() },
    { id: 6, recommendation_type: 'follow_up', client_name: 'Dynamic Corp', service_name: 'Post-demo consultation', confidence: 0.89, status: 'pending', created_at: new Date(Date.now() - 18000000).toISOString() }
  ],
  
  tasks: [
    { id: 1, title: 'Follow up with Acme Corp', description: 'Send personalized proposal after demo call', priority: 'high', status: 'pending', client_id: 1, assigned_to: 'Sales Team', due_date: new Date(Date.now() + 86400000).toISOString() },
    { id: 2, title: 'Schedule demo for TechStart', description: 'Product demonstration with technical team', priority: 'high', status: 'in_progress', client_id: 2, assigned_to: 'Product Team', due_date: new Date(Date.now() + 172800000).toISOString() },
    { id: 3, title: 'Contract review - Global Solutions', description: 'Legal review of updated terms', priority: 'medium', status: 'pending', client_id: 3, assigned_to: 'Legal Team', due_date: new Date(Date.now() + 259200000).toISOString() },
    { id: 4, title: 'Prepare Q1 business review', description: 'Compile metrics and insights for Enterprise Co', priority: 'medium', status: 'in_progress', client_id: 4, assigned_to: 'Account Manager', due_date: new Date(Date.now() + 345600000).toISOString() },
    { id: 5, title: 'Onboarding call - Innovation Labs', description: 'Walk through platform features', priority: 'high', status: 'pending', client_id: 5, assigned_to: 'Customer Success', due_date: new Date(Date.now() + 432000000).toISOString() },
    { id: 6, title: 'Send renewal proposal', description: 'Beta Systems contract renewal', priority: 'high', status: 'completed', client_id: 7, assigned_to: 'Sales Team', due_date: new Date(Date.now() - 86400000).toISOString() },
    { id: 7, title: 'Update case study', description: 'Dynamic Corp success story', priority: 'low', status: 'pending', client_id: 6, assigned_to: 'Marketing Team', due_date: new Date(Date.now() + 518400000).toISOString() },
    { id: 8, title: 'Technical support follow-up', description: 'Alpha Industries integration issues', priority: 'medium', status: 'in_progress', client_id: 8, assigned_to: 'Support Team', due_date: new Date(Date.now() + 604800000).toISOString() }
  ]
};

// Expose mock data to pages for dev-mode fallbacks
if (typeof window !== 'undefined' && isDevMode()) {
  window.__MOCK_DATA__ = MOCK_DATA;
}

// Global axios error interceptor
axios.interceptors.response.use(
  response => response,
  error => {
    if (error.response) {
      console.error(`API Error ${error.response.status}:`, error.response.data);
    } else if (error.request) {
      console.error('Network Error: No response received');
    } else {
      console.error('Request Error:', error.message);
    }
    return Promise.reject(error);
  }
);

// Error Boundary Component
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('React Error Boundary caught:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <Box sx={{ p: 3 }}>
          <Alert severity="error">
            <Typography variant="h6">Something went wrong</Typography>
            <Typography variant="body2">{this.state.error?.message}</Typography>
          </Alert>
        </Box>
      );
    }
    return this.props.children;
  }
}

const theme = createTheme({
  palette: {
    mode: 'light',
    primary: {
      main: '#1976d2',
    },
    secondary: {
      main: '#dc004e',
    },
    success: {
      main: '#4caf50',
    },
    warning: {
      main: '#ff9800',
    },
    error: {
      main: '#f44336',
    },
  },
});

const drawerWidth = 240;

// ============================================================================
// DASHBOARD COMPONENT
// ============================================================================

function DashboardView() {
  const navigate = useNavigate();
  const [stats, setStats] = useState({
    activeClients: 0,
    pendingTasks: 0,
    recommendations: 0,
    integrationHealth: {}
  });
  const [loading, setLoading] = useState(true);
  const [recentEvents, setRecentEvents] = useState([]);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });
  const [allEventsOpen, setAllEventsOpen] = useState(false);
  const [allEvents, setAllEvents] = useState([]);
  const [eventsLoading, setEventsLoading] = useState(false);
  const [eventFilter, setEventFilter] = useState('all');
  
  // Event Detail Modal
  const [eventDetailOpen, setEventDetailOpen] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState(null);
  
  // Integration Detail Modal
  const [integrationDetailOpen, setIntegrationDetailOpen] = useState(false);
  const [selectedIntegration, setSelectedIntegration] = useState(null);

  useEffect(() => {
    loadDashboardData();
    
    // Set up WebSocket for real-time updates
    const socket = io(process.env.REACT_APP_WS_URL || 'http://localhost:5000', {
      reconnection: true,
      reconnectionDelay: 1000,
      reconnectionAttempts: 5
    });
    
    socket.on('connect', () => {
      console.log('WebSocket connected');
    });

    socket.on('connect_error', (error) => {
      console.warn('WebSocket connection error:', error.message);
    });
    
    socket.on('workflow_event', (event) => {
      setRecentEvents(prev => [event, ...prev.slice(0, 9)]);
    });

    socket.on('integration_status', (status) => {
      setStats(prev => ({
        ...prev,
        integrationHealth: status
      }));
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  const loadDashboardData = async () => {
    try {
      // Try to load from API, fallback to mock data
      const [statsRes, eventsRes, healthRes, recommendationsRes] = await Promise.all([
        axios.get('/api/analytics/dashboard-stats').catch(err => {
          if (isDevMode()) {
            console.warn('🔧 Dev Mode: Using mock stats data');
            return { data: MOCK_DATA.stats };
          }
          throw err;
        }),
        axios.get('/api/analytics/recent-events?limit=10').catch(err => {
          if (isDevMode()) {
            console.warn('🔧 Dev Mode: Using mock events data');
            return { data: MOCK_DATA.events };
          }
          throw err;
        }),
        axios.get('/health/integrations').catch(err => {
          if (isDevMode()) {
            console.warn('🔧 Dev Mode: Using mock integration health data');
            return { data: MOCK_DATA.integrationHealth };
          }
          throw err;
        }),
        axios.get('/api/recommendations?status=pending').catch(err => {
          if (isDevMode()) {
            console.warn('🔧 Dev Mode: Using mock recommendations data');
            return { data: MOCK_DATA.recommendations.filter(r => r.status === 'pending') };
          }
          throw err;
        })
      ]);

      setStats({
        ...statsRes.data,
        recommendations: Array.isArray(recommendationsRes.data) ? recommendationsRes.data.length : 0,
        integrationHealth: healthRes.data
      });
      setRecentEvents(eventsRes.data);
    } catch (error) {
      console.error('Error loading dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleViewAllEvents = async () => {
    setAllEventsOpen(true);
    setEventsLoading(true);
    try {
      const response = await axios.get('/api/analytics/recent-events').catch(err => {
        if (isDevMode()) {
          console.warn('🔧 Dev Mode: Using mock all events data');
          return { data: MOCK_DATA.allEvents };
        }
        throw err;
      });
      // Create extended event data with multi-layer references
      const extendedEvents = response.data.map(event => ({
        ...event,
        // Add layer references
        layer1: {
          id: event.id,
          type: event.type || event.event_type,
          status: event.status || 'completed'
        },
        layer2: {
          client: event.client || event.event_source || 'Unknown',
          timestamp: event.timestamp ? new Date(event.timestamp).toLocaleString() : 'No date',
          description: event.description || formatEventType(event.type || event.event_type)
        },
        layer3: {
          metadata: event.metadata || {},
          relatedClients: event.related_clients || [],
          relatedTasks: event.related_tasks || [],
          actionable: event.actionable !== false
        }
      }));
      setAllEvents(extendedEvents);
      setSnackbar({ open: true, message: `Loaded ${extendedEvents.length} events`, severity: 'success' });
    } catch (error) {
      console.error('Error loading all events:', error);
      setSnackbar({ open: true, message: 'Error loading events', severity: 'error' });
    } finally {
      setEventsLoading(false);
    }
  };

  const handleEventAction = (e, event, action) => {
    if (e) {
      e.stopPropagation();
    }

    // Multi-layer data logging
    console.group(`🎯 Event Action: ${action.toUpperCase()}`);
    console.log('Layer 1 (Core):', {
      id: event.layer1.id,
      type: event.layer1.type,
      status: event.layer1.status
    });
    console.log('Layer 2 (Context):', {
      client: event.layer2.client,
      timestamp: event.layer2.timestamp,
      description: event.layer2.description
    });
    console.log('Layer 3 (Relations):', {
      metadata: event.layer3.metadata,
      relatedClients: event.layer3.relatedClients,
      relatedTasks: event.layer3.relatedTasks,
      actionable: event.layer3.actionable
    });
    console.groupEnd();

    // Action handlers with multi-layer data processing
    const actionHandlers = {
      view: () => {
        const details = [
          `Event: ${event.layer2.description}`,
          `Client: ${event.layer2.client}`,
          `Status: ${event.layer1.status}`,
          event.layer3.relatedClients?.length > 0 ? `Related: ${event.layer3.relatedClients.length} clients` : null,
          event.layer3.relatedTasks?.length > 0 ? `Tasks: ${event.layer3.relatedTasks.length}` : null
        ].filter(Boolean).join(' | ');
        
        setSnackbar({ 
          open: true, 
          message: `📋 ${details}`, 
          severity: 'info' 
        });
      },
      navigate: () => {
        const clientInfo = [
          event.layer2.client,
          event.layer3.relatedClients?.length > 0 ? `(+${event.layer3.relatedClients.length} related)` : null
        ].filter(Boolean).join(' ');
        
        setSnackbar({ 
          open: true, 
          message: `🔗 Navigating to: ${clientInfo}`, 
          severity: 'info' 
        });
        
        // Navigate to clients page with filter
        setTimeout(() => navigate('/clients'), 1000);
      },
      resolve: () => {
        // Update event status in state
        const updatedEvents = allEvents.map(e => 
          e.layer1.id === event.layer1.id 
            ? { 
                ...e, 
                layer1: { ...e.layer1, status: 'resolved' },
                layer3: { ...e.layer3, actionable: false }
              }
            : e
        );
        setAllEvents(updatedEvents);
        
        const resolveInfo = [
          event.layer2.description,
          event.layer3.relatedClients?.length > 0 ? `Notified ${event.layer3.relatedClients.length} clients` : null,
          event.layer3.relatedTasks?.length > 0 ? `Updated ${event.layer3.relatedTasks.length} tasks` : null
        ].filter(Boolean).join(' | ');
        
        setSnackbar({ 
          open: true, 
          message: `✅ Resolved: ${resolveInfo}`, 
          severity: 'success' 
        });
      },
      dismiss: () => {
        // Remove event from state
        const filteredEvents = allEvents.filter(e => e.layer1.id !== event.layer1.id);
        setAllEvents(filteredEvents);
        
        setSnackbar({ 
          open: true, 
          message: `❌ Dismissed event #${event.layer1.id} (${event.layer2.client})`, 
          severity: 'warning' 
        });
      }
    };

    // Execute action handler
    if (actionHandlers[action]) {
      actionHandlers[action]();
    } else {
      setSnackbar({ 
        open: true, 
        message: `Unknown action: ${action}`, 
        severity: 'error' 
      });
    }
  };

  // Open event detail modal with full data
  const handleEventClick = (e, event) => {
    if (e) {
      e.stopPropagation();
    }
    
    // Enrich event with mock transcript/recording if it's a call
    const enrichedEvent = { ...event };
    const type = event.layer1?.type?.toLowerCase() || '';
    
    if (type.includes('call') || type.includes('meeting')) {
      enrichedEvent.callDetails = {
        duration: '23:45',
        participants: [event.layer2?.client || 'Unknown', 'Sales Rep'],
        recording: 'https://example.com/recording.mp4',
        transcript: `
Call Transcript - ${event.layer2?.timestamp || 'No date'}

Participants: ${event.layer2?.client || 'Unknown'}, Sales Rep

[00:00] Sales Rep: Hi, thanks for taking the time to meet today!
[00:15] ${event.layer2?.client || 'Client'}: Happy to be here. We're really excited about the possibilities.
[00:45] Sales Rep: Great! Let me walk you through our solution...
[02:30] ${event.layer2?.client || 'Client'}: This looks promising. What about integration with our existing systems?
[03:15] Sales Rep: Excellent question. We have robust API integration capabilities...
[05:00] ${event.layer2?.client || 'Client'}: Can you provide some case studies?
[05:30] Sales Rep: Absolutely! We've worked with companies similar to yours...
[10:00] ${event.layer2?.client || 'Client'}: What's the typical implementation timeline?
[10:45] Sales Rep: Usually 4-6 weeks for full deployment...
[15:00] ${event.layer2?.client || 'Client'}: And ongoing support?
[15:30] Sales Rep: We offer 24/7 support with dedicated account management...
[20:00] ${event.layer2?.client || 'Client'}: This all sounds great. Let's schedule a follow-up.
[20:30] Sales Rep: Perfect! I'll send over the proposal and we can discuss next steps.
[23:00] ${event.layer2?.client || 'Client'}: Looking forward to it!
[23:30] Sales Rep: Thank you for your time. Have a great day!

Call Summary:
- Client expressed strong interest in the solution
- Discussed integration capabilities and timeline
- Requested case studies (ACTION ITEM)
- Scheduled follow-up meeting
- Next Step: Send proposal within 24 hours
        `.trim(),
        sentiment: 'positive',
        keyTopics: ['Integration', 'Implementation Timeline', 'Case Studies', 'Support'],
        actionItems: [
          'Send case studies',
          'Prepare formal proposal',
          'Schedule follow-up meeting'
        ]
      };
    }
    
    setSelectedEvent(enrichedEvent);
    setEventDetailOpen(true);
  };

  // Open integration detail modal
  const handleIntegrationClick = (e, integrationName) => {
    if (e) {
      e.stopPropagation();
    }
    
    const integrationData = stats.integrationHealth?.[integrationName];
    const enrichedIntegration = {
      name: integrationName,
      status: integrationData?.status || 'unknown',
      lastCheck: integrationData?.lastCheck || 'Never',
      config: {
        endpoint: `https://api.${integrationName.toLowerCase()}.com/v1`,
        authType: 'OAuth 2.0',
        syncInterval: '5 minutes',
        retryPolicy: 'Exponential backoff'
      },
      logs: [
        { timestamp: new Date().toISOString(), level: 'info', message: `${integrationName} sync completed successfully` },
        { timestamp: new Date(Date.now() - 300000).toISOString(), level: 'info', message: `Fetched 15 new records from ${integrationName}` },
        { timestamp: new Date(Date.now() - 600000).toISOString(), level: 'warn', message: 'Rate limit approaching for API' },
        { timestamp: new Date(Date.now() - 900000).toISOString(), level: 'info', message: `${integrationName} authentication refreshed` },
        { timestamp: new Date(Date.now() - 1200000).toISOString(), level: 'info', message: 'Webhook endpoint registered successfully' }
      ],
      metrics: {
        totalRequests: 1247,
        successRate: '98.5%',
        avgResponseTime: '245ms',
        lastError: 'None',
        dataPoints: 523
      }
    };
    
    setSelectedIntegration(enrichedIntegration);
    setIntegrationDetailOpen(true);
  };

  const getEventTypeCounts = () => {
    const counts = {
      all: allEvents.length,
      call: 0,
      recommendation: 0,
      task: 0,
      integration: 0,
      other: 0
    };

    allEvents.forEach(event => {
      const type = event.layer1.type?.toLowerCase() || '';
      if (type.includes('call') || type.includes('meeting')) {
        counts.call++;
      } else if (type.includes('recommendation') || type.includes('suggest')) {
        counts.recommendation++;
      } else if (type.includes('task') || type.includes('activity')) {
        counts.task++;
      } else if (type.includes('integration') || type.includes('sync') || type.includes('webhook')) {
        counts.integration++;
      } else {
        counts.other++;
      }
    });

    return counts;
  };

  const getFilteredEvents = () => {
    if (eventFilter === 'all') return allEvents;
    
    return allEvents.filter(event => {
      const type = event.layer1.type?.toLowerCase() || '';
      
      switch(eventFilter) {
        case 'call':
          return type.includes('call') || type.includes('meeting');
        case 'recommendation':
          return type.includes('recommendation') || type.includes('suggest');
        case 'task':
          return type.includes('task') || type.includes('activity');
        case 'integration':
          return type.includes('integration') || type.includes('sync') || type.includes('webhook');
        default:
          return true;
      }
    });
  };

  const getUniqueClients = () => {
    const clients = new Set();
    allEvents.forEach(event => {
      if (event.layer2.client && event.layer2.client !== 'Unknown') {
        clients.add(event.layer2.client);
      }
      event.layer3.relatedClients?.forEach(c => clients.add(c));
    });
    return Array.from(clients).sort();
  };

  const getUniqueStatuses = () => {
    const statuses = new Set();
    allEvents.forEach(event => {
      if (event.layer1.status) {
        statuses.add(event.layer1.status);
      }
    });
    return Array.from(statuses).sort();
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Dashboard
      </Typography>

      {/* Key Metrics */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={3}>
          <Card 
            sx={{ 
              cursor: 'pointer', 
              transition: 'all 0.3s',
              '&:hover': { 
                transform: 'translateY(-4px)', 
                boxShadow: 4 
              } 
            }}
            onClick={() => {
              navigate('/clients');
              setSnackbar({ open: true, message: 'Navigating to Clients view...', severity: 'info' });
            }}
          >
            <CardContent>
              <Typography color="textSecondary" gutterBottom>
                Active Clients
              </Typography>
              <Typography variant="h3">
                {stats.activeClients || 0}
              </Typography>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: 1 }}>
                <Chip label="All Systems" size="small" color="success" />
                <Button size="small" variant="text">View All →</Button>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Card 
            sx={{ 
              cursor: 'pointer', 
              transition: 'all 0.3s',
              '&:hover': { 
                transform: 'translateY(-4px)', 
                boxShadow: 4 
              } 
            }}
            onClick={() => {
              navigate('/tasks');
              setSnackbar({ open: true, message: 'Opening Tasks view...', severity: 'info' });
            }}
          >
            <CardContent>
              <Typography color="textSecondary" gutterBottom>
                Pending Tasks
              </Typography>
              <Typography variant="h3">
                {stats.pendingTasks || 0}
              </Typography>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: 1 }}>
                <Chip label="Needs Attention" size="small" color="warning" />
                <Button size="small" variant="text">Manage →</Button>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Card 
            sx={{ 
              cursor: 'pointer', 
              transition: 'all 0.3s',
              '&:hover': { 
                transform: 'translateY(-4px)', 
                boxShadow: 4 
              } 
            }}
            onClick={() => {
              navigate('/recommendations');
              setSnackbar({ open: true, message: 'Loading AI Recommendations...', severity: 'info' });
            }}
          >
            <CardContent>
              <Typography color="textSecondary" gutterBottom>
                AI Recommendations
              </Typography>
              <Typography variant="h3">
                {stats.recommendations || 0}
              </Typography>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: 1 }}>
                <Chip label="Ready to Send" size="small" color="primary" />
                <Button size="small" variant="text">Review →</Button>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Card 
            sx={{ 
              cursor: 'pointer', 
              transition: 'all 0.3s',
              '&:hover': { 
                transform: 'translateY(-4px)', 
                boxShadow: 4 
              } 
            }}
            onClick={() => {
              navigate('/settings');
              setSnackbar({ open: true, message: 'Opening System Settings...', severity: 'info' });
            }}
          >
            <CardContent>
              <Typography color="textSecondary" gutterBottom>
                System Health
              </Typography>
              <Typography variant="h3">
                {calculateHealthScore(stats.integrationHealth)}%
              </Typography>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: 1 }}>
                <Chip 
                  label="Operational" 
                  size="small" 
                  color={calculateHealthScore(stats.integrationHealth) > 80 ? "success" : "warning"} 
                />
                <Button size="small" variant="text">Settings →</Button>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Integration Status */}
      <Card sx={{ mb: 4 }}>
        <CardHeader 
          title="Integration Status" 
          action={
            <Button 
              variant="outlined" 
              size="small"
              onClick={() => {
                setSnackbar({ open: true, message: 'Refreshing integration status...', severity: 'info' });
                setTimeout(() => window.location.reload(), 500);
              }}
            >
              Refresh All
            </Button>
          }
        />
        <CardContent>
          <Grid container spacing={2}>
            {Object.entries(stats.integrationHealth).map(([name, status]) => (
              <Grid item xs={12} sm={6} md={4} key={name}>
                <Box 
                  display="flex" 
                  alignItems="center" 
                  gap={1}
                  onClick={(e) => handleIntegrationClick(e, name)}
                  sx={{
                    cursor: 'pointer',
                    p: 1.5,
                    borderRadius: 1,
                    transition: 'all 0.2s ease',
                    '&:hover': {
                      backgroundColor: 'action.hover',
                      transform: 'translateY(-2px)',
                      boxShadow: 1
                    }
                  }}
                >
                  {status.is_healthy ? (
                    <CheckCircleIcon color="success" />
                  ) : (
                    <ErrorIcon color="error" />
                  )}
                  <Box>
                    <Typography 
                      variant="body1" 
                      sx={{ 
                        textTransform: 'capitalize',
                        fontWeight: 500
                      }}
                    >
                      {name.replace('_', ' ')}
                    </Typography>
                    <Typography variant="caption" color="textSecondary">
                      Last checked: {status.last_check_at ? new Date(status.last_check_at).toLocaleTimeString() : 'Never'}
                    </Typography>
                  </Box>
                </Box>
              </Grid>
            ))}
          </Grid>
        </CardContent>
      </Card>

      {/* Recent Events */}
      <Card sx={{ mb: 3 }}>
        <CardHeader 
          title="Recent Events" 
          action={
            <Button 
              variant="text" 
              size="small"
              onClick={handleViewAllEvents}
              sx={{
                transition: 'all 0.3s ease',
                '&:hover': {
                  transform: 'scale(1.05)',
                  color: 'primary.dark'
                }
              }}
            >
              View All
            </Button>
          }
        />
        <CardContent>
          <List>
            {recentEvents.length === 0 ? (
              <Typography color="textSecondary" align="center">
                No recent events
              </Typography>
            ) : (
              recentEvents.map((event, index) => {
                // Convert to multi-layer format for consistency
                const layeredEvent = {
                  layer1: {
                    id: event.id,
                    type: event.type || event.event_type,
                    status: event.status || 'completed'
                  },
                  layer2: {
                    client: event.client || event.event_source || 'Unknown',
                    timestamp: event.timestamp ? new Date(event.timestamp).toLocaleString() : 'No date',
                    description: formatEventType(event.type || event.event_type)
                  },
                  layer3: {
                    metadata: event.metadata || {},
                    relatedClients: event.related_clients || [],
                    relatedTasks: event.related_tasks || [],
                    actionable: event.actionable !== false
                  }
                };
                
                return (
                  <ListItem 
                    key={event.id || index} 
                    divider={index < recentEvents.length - 1}
                    onClick={(e) => handleEventClick(e, layeredEvent)}
                    sx={{
                      cursor: 'pointer',
                      transition: 'all 0.2s ease',
                      '&:hover': {
                        backgroundColor: 'action.hover',
                        transform: 'translateX(4px)'
                      }
                    }}
                  >
                    <ListItemIcon>
                      {getEventIcon(event.type || event.event_type)}
                    </ListItemIcon>
                    <ListItemText
                      primary={formatEventType(event.type || event.event_type)}
                      secondary={`${event.client || event.event_source || 'Unknown'} • ${event.timestamp ? new Date(event.timestamp).toLocaleString() : 'No date'}`}
                      sx={{
                        '& .MuiListItemText-primary': {
                          fontWeight: 500
                        }
                      }}
                    />
                    <Chip 
                      label={event.status || 'completed'} 
                      size="small" 
                      color={event.status === 'completed' ? 'success' : event.status === 'failed' ? 'error' : 'default'}
                      onClick={(e) => {
                        e.stopPropagation();
                        setSnackbar({ 
                          open: true, 
                          message: `Status: ${event.status || 'completed'}`, 
                          severity: 'info' 
                        });
                      }}
                      sx={{
                        cursor: 'pointer',
                        transition: 'all 0.2s ease',
                        '&:hover': {
                          transform: 'scale(1.1)'
                        }
                      }}
                    />
                </ListItem>
                );
              })
            )}
          </List>
        </CardContent>
      </Card>

      {/* Quick Actions Panel */}
      <Card>
        <CardHeader title="Quick Actions" />
        <CardContent>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6} md={3}>
              <Button 
                fullWidth 
                variant="contained" 
                color="primary"
                onClick={() => {
                  navigate('/clients');
                  setSnackbar({ open: true, message: 'Adding new client...', severity: 'success' });
                }}
              >
                + Add Client
              </Button>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <Button 
                fullWidth 
                variant="contained" 
                color="success"
                onClick={() => {
                  navigate('/recommendations');
                  setSnackbar({ open: true, message: 'Generating AI recommendations...', severity: 'info' });
                }}
              >
                Generate Recommendations
              </Button>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <Button 
                fullWidth 
                variant="outlined"
                onClick={() => {
                  navigate('/tasks');
                  setSnackbar({ open: true, message: 'Creating new task...', severity: 'info' });
                }}
              >
                + Create Task
              </Button>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <Button 
                fullWidth 
                variant="outlined"
                color="warning"
                onClick={() => {
                  setSnackbar({ open: true, message: 'Running system diagnostics...', severity: 'warning' });
                  setTimeout(() => {
                    setSnackbar({ open: true, message: 'All systems operational!', severity: 'success' });
                  }, 2000);
                }}
              >
                Run Diagnostics
              </Button>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      {/* All Events Modal */}
      <Dialog 
        open={allEventsOpen} 
        onClose={() => setAllEventsOpen(false)}
        maxWidth="lg"
        fullWidth
      >
        <DialogTitle>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 2 }}>
            <Box>
              <Typography variant="h6">All Events - Multi-Layer Data View</Typography>
              <Typography variant="caption" color="textSecondary">
                {getFilteredEvents().length} of {allEvents.length} events | {getUniqueClients().length} clients | {getUniqueStatuses().length} statuses
              </Typography>
            </Box>
            <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
              <FormControl size="small" sx={{ minWidth: 200 }}>
                <InputLabel>Event Type Filter</InputLabel>
                <Select 
                  value={eventFilter} 
                  label="Event Type Filter"
                  onChange={(e) => {
                    setEventFilter(e.target.value);
                    const counts = getEventTypeCounts();
                    setSnackbar({ 
                      open: true, 
                      message: `Filtered to ${counts[e.target.value] || 0} events`, 
                      severity: 'info' 
                    });
                  }}
                >
                  {(() => {
                    const counts = getEventTypeCounts();
                    return (
                      <>
                        <MenuItem value="all">
                          <Box sx={{ display: 'flex', justifyContent: 'space-between', width: '100%', gap: 2 }}>
                            <span>All Events</span>
                            <Chip label={counts.all} size="small" color="default" />
                          </Box>
                        </MenuItem>
                        <MenuItem value="call">
                          <Box sx={{ display: 'flex', justifyContent: 'space-between', width: '100%', gap: 2 }}>
                            <span>Call Events</span>
                            <Chip label={counts.call} size="small" color="primary" />
                          </Box>
                        </MenuItem>
                        <MenuItem value="recommendation">
                          <Box sx={{ display: 'flex', justifyContent: 'space-between', width: '100%', gap: 2 }}>
                            <span>Recommendations</span>
                            <Chip label={counts.recommendation} size="small" color="success" />
                          </Box>
                        </MenuItem>
                        <MenuItem value="task">
                          <Box sx={{ display: 'flex', justifyContent: 'space-between', width: '100%', gap: 2 }}>
                            <span>Tasks</span>
                            <Chip label={counts.task} size="small" color="info" />
                          </Box>
                        </MenuItem>
                        <MenuItem value="integration">
                          <Box sx={{ display: 'flex', justifyContent: 'space-between', width: '100%', gap: 2 }}>
                            <span>Integrations</span>
                            <Chip label={counts.integration} size="small" color="warning" />
                          </Box>
                        </MenuItem>
                      </>
                    );
                  })()}
                </Select>
              </FormControl>
              <IconButton 
                onClick={() => setAllEventsOpen(false)}
                sx={{
                  transition: 'all 0.2s ease',
                  '&:hover': {
                    transform: 'rotate(90deg)',
                    bgcolor: 'error.light'
                  }
                }}
              >
                <CloseIcon />
              </IconButton>
            </Box>
          </Box>
        </DialogTitle>
        <DialogContent dividers>
          {eventsLoading ? (
            <Box display="flex" justifyContent="center" alignItems="center" minHeight="300px">
              <CircularProgress />
            </Box>
          ) : (
            <TableContainer component={Paper} variant="outlined">
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell><strong>Event Type</strong></TableCell>
                    <TableCell><strong>Client/Source</strong></TableCell>
                    <TableCell><strong>Timestamp</strong></TableCell>
                    <TableCell><strong>Status</strong></TableCell>
                    <TableCell><strong>Metadata</strong></TableCell>
                    <TableCell align="center"><strong>Actions</strong></TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {getFilteredEvents().length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} align="center">
                        <Typography color="textSecondary">No events found</Typography>
                      </TableCell>
                    </TableRow>
                  ) : (
                    getFilteredEvents().map((event, index) => (
                      <TableRow 
                        key={event.layer1.id || index} 
                        hover
                        onClick={(e) => handleEventClick(e, event)}
                        sx={{
                          cursor: 'pointer',
                          transition: 'all 0.2s ease',
                          '&:hover': {
                            bgcolor: 'action.hover',
                            transform: 'scale(1.01)'
                          }
                        }}
                      >
                        <TableCell>
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                            {getEventIcon(event.layer1.type)}
                            <Typography 
                              variant="body2" 
                              sx={{ 
                                fontWeight: 600,
                                cursor: 'pointer',
                                transition: 'all 0.2s ease',
                                '&:hover': { 
                                  color: 'primary.main',
                                  textDecoration: 'underline'
                                }
                              }}
                              onClick={(e) => handleEventAction(e, event, 'view')}
                            >
                              {event.layer2.description}
                            </Typography>
                          </Box>
                        </TableCell>
                        <TableCell>
                          <Typography 
                            variant="body2"
                            sx={{
                              cursor: 'pointer',
                              fontWeight: 500,
                              transition: 'all 0.2s ease',
                              '&:hover': { 
                                color: 'primary.main', 
                                textDecoration: 'underline',
                                transform: 'translateX(3px)'
                              }
                            }}
                            onClick={(e) => handleEventAction(e, event, 'navigate')}
                          >
                            {event.layer2.client}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Typography variant="caption" color="textSecondary">
                            {event.layer2.timestamp}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Chip 
                            label={event.layer1.status} 
                            size="small" 
                            color={
                              event.layer1.status === 'completed' ? 'success' : 
                              event.layer1.status === 'failed' ? 'error' : 
                              event.layer1.status === 'pending' ? 'warning' : 
                              'default'
                            }
                            clickable
                            onClick={(e) => handleEventAction(e, event, 'view')}
                            sx={{
                              transition: 'all 0.2s ease',
                              '&:hover': {
                                transform: 'scale(1.1)'
                              }
                            }}
                          />
                        </TableCell>
                        <TableCell>
                          <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap' }}>
                            {event.layer3.relatedClients?.length > 0 && (
                              <Chip 
                                label={`${event.layer3.relatedClients.length} clients`} 
                                size="small" 
                                variant="outlined"
                                color="primary"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setSnackbar({ 
                                    open: true, 
                                    message: `Related Clients: ${event.layer3.relatedClients.join(', ')}`, 
                                    severity: 'info' 
                                  });
                                }}
                                sx={{
                                  cursor: 'pointer',
                                  transition: 'all 0.2s ease',
                                  '&:hover': {
                                    transform: 'scale(1.1)'
                                  }
                                }}
                              />
                            )}
                            {event.layer3.relatedTasks?.length > 0 && (
                              <Chip 
                                label={`${event.layer3.relatedTasks.length} tasks`} 
                                size="small" 
                                variant="outlined"
                                color="info"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setSnackbar({ 
                                    open: true, 
                                    message: `Related Tasks: ${event.layer3.relatedTasks.join(', ')}`, 
                                    severity: 'info' 
                                  });
                                }}
                                sx={{
                                  cursor: 'pointer',
                                  transition: 'all 0.2s ease',
                                  '&:hover': {
                                    transform: 'scale(1.1)'
                                  }
                                }}
                              />
                            )}
                            {event.layer3.actionable && (
                              <Chip 
                                label="Actionable" 
                                size="small" 
                                variant="outlined"
                                color="warning"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setSnackbar({ 
                                    open: true, 
                                    message: 'This event requires action', 
                                    severity: 'warning' 
                                  });
                                }}
                                sx={{
                                  cursor: 'pointer',
                                  transition: 'all 0.2s ease',
                                  '&:hover': {
                                    transform: 'scale(1.1)'
                                  }
                                }}
                              />
                            )}
                          </Box>
                        </TableCell>
                        <TableCell align="center">
                          <Box sx={{ display: 'flex', gap: 0.5, justifyContent: 'center' }}>
                            <Button 
                              size="small" 
                              variant="contained" 
                              color="primary"
                              onClick={(e) => handleEventAction(e, event, 'view')}
                              sx={{ 
                                minWidth: 'auto', 
                                px: 1,
                                transition: 'all 0.2s ease',
                                '&:hover': {
                                  transform: 'scale(1.05)',
                                  boxShadow: 3
                                }
                              }}
                            >
                              View
                            </Button>
                            {event.layer3.actionable && (
                              <Button 
                                size="small" 
                                variant="outlined" 
                                color="success"
                                onClick={(e) => handleEventAction(e, event, 'resolve')}
                                sx={{ 
                                  minWidth: 'auto', 
                                  px: 1,
                                  transition: 'all 0.2s ease',
                                  '&:hover': {
                                    transform: 'scale(1.05)',
                                    bgcolor: 'success.light',
                                    color: 'white'
                                  }
                                }}
                              >
                                Resolve
                              </Button>
                            )}
                            <Button 
                              size="small" 
                              variant="outlined" 
                              color="error"
                              onClick={(e) => handleEventAction(e, event, 'dismiss')}
                              sx={{ 
                                minWidth: 'auto', 
                                px: 1,
                                transition: 'all 0.2s ease',
                                '&:hover': {
                                  transform: 'scale(1.05)',
                                  bgcolor: 'error.light',
                                  color: 'white'
                                }
                              }}
                            >
                              Dismiss
                            </Button>
                          </Box>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </TableContainer>
          )}
          
          {/* Multi-Layer Data Summary */}
          <Box sx={{ mt: 2 }}>
            <Grid container spacing={2}>
              <Grid item xs={12} md={3}>
                <Card 
                  variant="outlined"
                  onClick={() => {
                    setSnackbar({ 
                      open: true, 
                      message: `Showing ${getFilteredEvents().length} filtered events`, 
                      severity: 'info' 
                    });
                  }}
                  sx={{
                    cursor: 'pointer',
                    transition: 'all 0.2s ease',
                    '&:hover': {
                      boxShadow: 3,
                      transform: 'translateY(-2px)'
                    }
                  }}
                >
                  <CardContent sx={{ p: 1.5 }}>
                    <Typography variant="caption" color="textSecondary">Filtered Events</Typography>
                    <Typography variant="h6">{getFilteredEvents().length}</Typography>
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} md={3}>
                <Card 
                  variant="outlined"
                  onClick={() => {
                    setEventFilter('all');
                    setSnackbar({ 
                      open: true, 
                      message: `Viewing all ${allEvents.length} events`, 
                      severity: 'info' 
                    });
                  }}
                  sx={{
                    cursor: 'pointer',
                    transition: 'all 0.2s ease',
                    '&:hover': {
                      boxShadow: 3,
                      transform: 'translateY(-2px)'
                    }
                  }}
                >
                  <CardContent sx={{ p: 1.5 }}>
                    <Typography variant="caption" color="textSecondary">Total Events</Typography>
                    <Typography variant="h6">{allEvents.length}</Typography>
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} md={3}>
                <Card 
                  variant="outlined"
                  onClick={() => {
                    const clients = getUniqueClients();
                    setSnackbar({ 
                      open: true, 
                      message: `Unique Clients: ${clients.join(', ')}`, 
                      severity: 'info' 
                    });
                  }}
                  sx={{
                    cursor: 'pointer',
                    transition: 'all 0.2s ease',
                    '&:hover': {
                      boxShadow: 3,
                      transform: 'translateY(-2px)'
                    }
                  }}
                >
                  <CardContent sx={{ p: 1.5 }}>
                    <Typography variant="caption" color="textSecondary">Unique Clients</Typography>
                    <Typography variant="h6">{getUniqueClients().length}</Typography>
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} md={3}>
                <Card 
                  variant="outlined"
                  onClick={() => {
                    const statuses = getUniqueStatuses();
                    setSnackbar({ 
                      open: true, 
                      message: `Status Types: ${statuses.join(', ')}`, 
                      severity: 'info' 
                    });
                  }}
                  sx={{
                    cursor: 'pointer',
                    transition: 'all 0.2s ease',
                    '&:hover': {
                      boxShadow: 3,
                      transform: 'translateY(-2px)'
                    }
                  }}
                >
                  <CardContent sx={{ p: 1.5 }}>
                    <Typography variant="caption" color="textSecondary">Status Types</Typography>
                    <Typography variant="h6">{getUniqueStatuses().length}</Typography>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>
          </Box>

          <Box sx={{ mt: 2, p: 2, bgcolor: 'grey.100', borderRadius: 1 }}>
            <Typography variant="caption" color="textSecondary" sx={{ display: 'block', mb: 0.5 }}>
              <strong>Multi-Layer Data Architecture:</strong>
            </Typography>
            <Typography variant="caption" color="textSecondary" sx={{ display: 'block' }}>
              • <strong>Layer 1</strong> (Core): Event ID, Type ({(() => {
                const types = new Set(allEvents.map(e => e.layer1.type));
                return types.size;
              })()} unique), Status ({getUniqueStatuses().length} types)
            </Typography>
            <Typography variant="caption" color="textSecondary" sx={{ display: 'block' }}>
              • <strong>Layer 2</strong> (Context): Client/Source ({getUniqueClients().length} unique), Timestamps, Descriptions
            </Typography>
            <Typography variant="caption" color="textSecondary" sx={{ display: 'block' }}>
              • <strong>Layer 3</strong> (Relations): {(() => {
                const totalRelatedClients = allEvents.reduce((sum, e) => sum + (e.layer3.relatedClients?.length || 0), 0);
                const totalRelatedTasks = allEvents.reduce((sum, e) => sum + (e.layer3.relatedTasks?.length || 0), 0);
                const actionableCount = allEvents.filter(e => e.layer3.actionable).length;
                return `${totalRelatedClients} client references, ${totalRelatedTasks} task references, ${actionableCount} actionable events`;
              })()}
            </Typography>
          </Box>
        </DialogContent>
      </Dialog>
      
      {/* Event Detail Modal */}
      <Dialog 
        open={eventDetailOpen} 
        onClose={() => setEventDetailOpen(false)}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <Typography variant="h6">Event Details</Typography>
            <Button 
              onClick={() => setEventDetailOpen(false)}
              sx={{ minWidth: 'auto' }}
            >
              <Close />
            </Button>
          </Box>
        </DialogTitle>
        <DialogContent dividers>
          {selectedEvent && (
            <Box>
              {/* Event Info */}
              <Typography variant="h6" gutterBottom>
                {selectedEvent.layer2?.description || 'Event'}
              </Typography>
              
              <Grid container spacing={2} sx={{ mb: 3 }}>
                <Grid item xs={6}>
                  <Typography variant="caption" color="textSecondary">Type</Typography>
                  <Typography variant="body1">{selectedEvent.layer1?.type || 'Unknown'}</Typography>
                </Grid>
                <Grid item xs={6}>
                  <Typography variant="caption" color="textSecondary">Status</Typography>
                  <Chip 
                    label={selectedEvent.layer1?.status || 'completed'} 
                    size="small" 
                    color={selectedEvent.layer1?.status === 'completed' ? 'success' : 'default'}
                  />
                </Grid>
                <Grid item xs={6}>
                  <Typography variant="caption" color="textSecondary">Client</Typography>
                  <Typography variant="body1">{selectedEvent.layer2?.client || 'Unknown'}</Typography>
                </Grid>
                <Grid item xs={6}>
                  <Typography variant="caption" color="textSecondary">Timestamp</Typography>
                  <Typography variant="body1">{selectedEvent.layer2?.timestamp || 'No date'}</Typography>
                </Grid>
              </Grid>
              
              {/* Call Details (if call event) */}
              {selectedEvent.callDetails && (
                <>
                  <Typography variant="h6" gutterBottom sx={{ mt: 2 }}>
                    Call Details
                  </Typography>
                  <Grid container spacing={2} sx={{ mb: 3 }}>
                    <Grid item xs={4}>
                      <Typography variant="caption" color="textSecondary">Duration</Typography>
                      <Typography variant="body1">{selectedEvent.callDetails.duration}</Typography>
                    </Grid>
                    <Grid item xs={4}>
                      <Typography variant="caption" color="textSecondary">Sentiment</Typography>
                      <Chip 
                        label={selectedEvent.callDetails.sentiment} 
                        size="small" 
                        color="success"
                      />
                    </Grid>
                    <Grid item xs={4}>
                      <Typography variant="caption" color="textSecondary">Participants</Typography>
                      <Typography variant="body1">{selectedEvent.callDetails.participants.join(', ')}</Typography>
                    </Grid>
                  </Grid>
                  
                  {/* Key Topics */}
                  <Typography variant="subtitle2" gutterBottom>Key Topics</Typography>
                  <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', mb: 2 }}>
                    {selectedEvent.callDetails.keyTopics.map((topic, idx) => (
                      <Chip key={idx} label={topic} size="small" variant="outlined" />
                    ))}
                  </Box>
                  
                  {/* Action Items */}
                  <Typography variant="subtitle2" gutterBottom>Action Items</Typography>
                  <List dense>
                    {selectedEvent.callDetails.actionItems.map((item, idx) => (
                      <ListItem key={idx}>
                        <ListItemIcon>
                          <Task fontSize="small" />
                        </ListItemIcon>
                        <ListItemText primary={item} />
                      </ListItem>
                    ))}
                  </List>
                  
                  {/* Transcript */}
                  <Typography variant="h6" gutterBottom sx={{ mt: 2 }}>
                    Call Transcript
                  </Typography>
                  <Box 
                    sx={{ 
                      backgroundColor: 'background.default', 
                      p: 2, 
                      borderRadius: 1,
                      maxHeight: 400,
                      overflow: 'auto',
                      fontFamily: 'monospace',
                      fontSize: '0.85rem',
                      whiteSpace: 'pre-wrap'
                    }}
                  >
                    {selectedEvent.callDetails.transcript}
                  </Box>
                  
                  {/* Recording Link */}
                  <Box sx={{ mt: 2 }}>
                    <Button 
                      variant="contained" 
                      color="primary"
                      onClick={() => {
                        setSnackbar({ 
                          open: true, 
                          message: 'Opening call recording...', 
                          severity: 'info' 
                        });
                      }}
                    >
                      View Recording
                    </Button>
                  </Box>
                </>
              )}
              
              {/* Related Data */}
              {selectedEvent.layer3 && (
                <Box sx={{ mt: 3 }}>
                  <Typography variant="h6" gutterBottom>Related Data</Typography>
                  <Grid container spacing={2}>
                    {selectedEvent.layer3.relatedClients?.length > 0 && (
                      <Grid item xs={12}>
                        <Typography variant="caption" color="textSecondary">Related Clients</Typography>
                        <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', mt: 0.5 }}>
                          {selectedEvent.layer3.relatedClients.map((client, idx) => (
                            <Chip key={idx} label={client} size="small" color="primary" variant="outlined" />
                          ))}
                        </Box>
                      </Grid>
                    )}
                    {selectedEvent.layer3.relatedTasks?.length > 0 && (
                      <Grid item xs={12}>
                        <Typography variant="caption" color="textSecondary">Related Tasks</Typography>
                        <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', mt: 0.5 }}>
                          {selectedEvent.layer3.relatedTasks.map((task, idx) => (
                            <Chip key={idx} label={task} size="small" color="info" variant="outlined" />
                          ))}
                        </Box>
                      </Grid>
                    )}
                  </Grid>
                </Box>
              )}
            </Box>
          )}
        </DialogContent>
      </Dialog>
      
      {/* Integration Detail Modal */}
      <Dialog 
        open={integrationDetailOpen} 
        onClose={() => setIntegrationDetailOpen(false)}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <Typography variant="h6">Integration Details</Typography>
            <Button 
              onClick={() => setIntegrationDetailOpen(false)}
              sx={{ minWidth: 'auto' }}
            >
              <Close />
            </Button>
          </Box>
        </DialogTitle>
        <DialogContent dividers>
          {selectedIntegration && (
            <Box>
              {/* Integration Info */}
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
                <Typography variant="h5" sx={{ textTransform: 'capitalize' }}>
                  {selectedIntegration.name.replace('_', ' ')}
                </Typography>
                <Chip 
                  label={selectedIntegration.status} 
                  size="small" 
                  color={selectedIntegration.status === 'healthy' ? 'success' : 'error'}
                />
              </Box>
              
              {/* Configuration */}
              <Typography variant="h6" gutterBottom>Configuration</Typography>
              <Grid container spacing={2} sx={{ mb: 3 }}>
                <Grid item xs={6}>
                  <Typography variant="caption" color="textSecondary">Endpoint</Typography>
                  <Typography variant="body2">{selectedIntegration.config?.endpoint}</Typography>
                </Grid>
                <Grid item xs={6}>
                  <Typography variant="caption" color="textSecondary">Auth Type</Typography>
                  <Typography variant="body2">{selectedIntegration.config?.authType}</Typography>
                </Grid>
                <Grid item xs={6}>
                  <Typography variant="caption" color="textSecondary">Sync Interval</Typography>
                  <Typography variant="body2">{selectedIntegration.config?.syncInterval}</Typography>
                </Grid>
                <Grid item xs={6}>
                  <Typography variant="caption" color="textSecondary">Retry Policy</Typography>
                  <Typography variant="body2">{selectedIntegration.config?.retryPolicy}</Typography>
                </Grid>
                <Grid item xs={12}>
                  <Typography variant="caption" color="textSecondary">Last Check</Typography>
                  <Typography variant="body2">{selectedIntegration.lastCheck}</Typography>
                </Grid>
              </Grid>
              
              {/* Metrics */}
              <Typography variant="h6" gutterBottom>Metrics</Typography>
              <Grid container spacing={2} sx={{ mb: 3 }}>
                <Grid item xs={6} md={3}>
                  <Card variant="outlined">
                    <CardContent sx={{ p: 1.5 }}>
                      <Typography variant="caption" color="textSecondary">Total Requests</Typography>
                      <Typography variant="h6">{selectedIntegration.metrics?.totalRequests}</Typography>
                    </CardContent>
                  </Card>
                </Grid>
                <Grid item xs={6} md={3}>
                  <Card variant="outlined">
                    <CardContent sx={{ p: 1.5 }}>
                      <Typography variant="caption" color="textSecondary">Success Rate</Typography>
                      <Typography variant="h6">{selectedIntegration.metrics?.successRate}</Typography>
                    </CardContent>
                  </Card>
                </Grid>
                <Grid item xs={6} md={3}>
                  <Card variant="outlined">
                    <CardContent sx={{ p: 1.5 }}>
                      <Typography variant="caption" color="textSecondary">Avg Response</Typography>
                      <Typography variant="h6">{selectedIntegration.metrics?.avgResponseTime}</Typography>
                    </CardContent>
                  </Card>
                </Grid>
                <Grid item xs={6} md={3}>
                  <Card variant="outlined">
                    <CardContent sx={{ p: 1.5 }}>
                      <Typography variant="caption" color="textSecondary">Data Points</Typography>
                      <Typography variant="h6">{selectedIntegration.metrics?.dataPoints}</Typography>
                    </CardContent>
                  </Card>
                </Grid>
              </Grid>
              
              {/* Logs */}
              <Typography variant="h6" gutterBottom>Recent Logs</Typography>
              <Box 
                sx={{ 
                  backgroundColor: 'background.default', 
                  p: 2, 
                  borderRadius: 1,
                  maxHeight: 300,
                  overflow: 'auto'
                }}
              >
                <List dense>
                  {selectedIntegration.logs?.map((log, idx) => (
                    <ListItem key={idx} sx={{ py: 0.5 }}>
                      <ListItemText
                        primary={
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                            <Chip 
                              label={log.level} 
                              size="small" 
                              color={
                                log.level === 'error' ? 'error' : 
                                log.level === 'warn' ? 'warning' : 
                                'default'
                              }
                              sx={{ minWidth: 60 }}
                            />
                            <Typography variant="body2">{log.message}</Typography>
                          </Box>
                        }
                        secondary={new Date(log.timestamp).toLocaleString()}
                      />
                    </ListItem>
                  ))}
                </List>
              </Box>
              
              {/* Actions */}
              <Box sx={{ mt: 3, display: 'flex', gap: 2 }}>
                <Button 
                  variant="contained" 
                  color="primary"
                  onClick={() => {
                    setSnackbar({ 
                      open: true, 
                      message: `Testing ${selectedIntegration.name} connection...`, 
                      severity: 'info' 
                    });
                  }}
                >
                  Test Connection
                </Button>
                <Button 
                  variant="outlined"
                  onClick={() => {
                    setSnackbar({ 
                      open: true, 
                      message: `Refreshing ${selectedIntegration.name}...`, 
                      severity: 'info' 
                    });
                  }}
                >
                  Sync Now
                </Button>
                <Button 
                  variant="outlined"
                  color="warning"
                  onClick={() => {
                    setSnackbar({ 
                      open: true, 
                      message: `Opening ${selectedIntegration.name} settings...`, 
                      severity: 'info' 
                    });
                  }}
                >
                  Configure
                </Button>
              </Box>
            </Box>
          )}
        </DialogContent>
      </Dialog>
      
      <Snackbar 
        open={snackbar.open} 
        autoHideDuration={3000} 
        onClose={() => setSnackbar({ ...snackbar, open: false })}
      >
        <Alert severity={snackbar.severity} onClose={() => setSnackbar({ ...snackbar, open: false })}>
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
}

// ============================================================================
// CLIENTS VIEW
// ============================================================================

function ClientsView() {
  const navigate = useNavigate();
  const [clients, setClients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });
  const [openDialog, setOpenDialog] = useState(false);
  const [clientDetailOpen, setClientDetailOpen] = useState(false);
  const [selectedClient, setSelectedClient] = useState(null);
  const [analysisOpen, setAnalysisOpen] = useState(false);
  const [analysisResult, setAnalysisResult] = useState(null);
  const [newClient, setNewClient] = useState({
    name: '',
    industry: '',
    communication_style: '',
    emotional_trigger: ''
  });

  useEffect(() => {
    loadClients();
  }, []);

  const loadClients = async () => {
    try {
      const response = await axios.get('/api/clients').catch(err => {
        if (isDevMode()) {
          console.warn('🔧 Dev Mode: Using mock clients data');
          return { data: MOCK_DATA.clients };
        }
        throw err;
      });
      setClients(response.data);
    } catch (error) {
      console.error('Error loading clients:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleViewDetails = (e, client) => {
    if (e) {
      e.stopPropagation();
    }
    // Enrich client with additional data
    const enrichedClient = {
      ...client,
      interactions: [
        { date: '2024-01-15', type: 'Call', notes: 'Discussed Q1 strategy' },
        { date: '2024-01-10', type: 'Email', notes: 'Sent proposal document' },
        { date: '2024-01-05', type: 'Meeting', notes: 'Initial consultation' }
      ],
      recentActivities: [
        'Logged in to portal',
        'Downloaded report',
        'Attended webinar'
      ],
      associatedTasks: [
        { id: 1, title: 'Follow-up call', status: 'pending' },
        { id: 2, title: 'Send contract', status: 'completed' }
      ]
    };
    setSelectedClient(enrichedClient);
    setClientDetailOpen(true);
  };

  const handleContact = (client) => {
    setSnackbar({ 
      open: true, 
      message: `Initiating contact with ${client.name} via ${client.communication_style}`, 
      severity: 'success' 
    });
  };

  const handleAnalyze = (client) => {
    // Call backend analysis endpoint and show results
    (async () => {
      setSnackbar({ open: true, message: `Analyzing ${client.name}...`, severity: 'info' });
      try {
        const res = await axios.post(`/api/clients/${client.id}/analyze`);
        const data = res.data;
        // Show concise result in snackbar and open analysis dialog
        setSnackbar({ open: true, message: `Analysis: ${data.risk_level.toUpperCase()} risk — ${data.recommended_actions[0]}`, severity: data.risk_level === 'high' ? 'error' : data.risk_level === 'medium' ? 'warning' : 'success' });
        setAnalysisResult(data);
        setAnalysisOpen(true);
      } catch (err) {
        console.error('Analysis error:', err);
        if (isDevMode()) {
          setSnackbar({ open: true, message: '(Dev) Analysis simulated', severity: 'info' });
          setAnalysisResult({ client_name: client.name, risk_level: 'medium', recommended_actions: ['Run QBR', 'Share case studies'] });
          setAnalysisOpen(true);
        } else {
          setSnackbar({ open: true, message: 'Error running analysis', severity: 'error' });
        }
      }
    })();
  };

  const handleAddClient = () => {
    if (!newClient.name || !newClient.industry) {
      setSnackbar({ open: true, message: 'Please fill in required fields', severity: 'warning' });
      return;
    }
    const clientToAdd = {
      id: clients.length + 1,
      ...newClient,
      status: 'active',
      health_score: 85,
      created_at: new Date().toISOString()
    };
    setClients([...clients, clientToAdd]);
    setOpenDialog(false);
    setNewClient({ name: '', industry: '', communication_style: '', emotional_trigger: '' });
    setSnackbar({ open: true, message: `Client "${clientToAdd.name}" added successfully!`, severity: 'success' });
  };

  if (loading) {
    return <CircularProgress />;
  }

  return (
    <Box>
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
        <IconButton onClick={() => navigate('/')} sx={{ mr: 2 }}>
          <ArrowBackIcon />
        </IconButton>
        <Breadcrumbs>
          <Link to="/" style={{ textDecoration: 'none', color: 'inherit', display: 'flex', alignItems: 'center' }}>
            <HomeIcon sx={{ mr: 0.5 }} fontSize="small" />
            Dashboard
          </Link>
          <Typography color="text.primary">Clients</Typography>
        </Breadcrumbs>
      </Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
        <Typography variant="h4">
          Clients
        </Typography>
        <Button 
          variant="contained" 
          startIcon={<AddIcon />}
          onClick={() => setOpenDialog(true)}
        >
          Add New Client
        </Button>
      </Box>
      <Alert severity="info" sx={{ mb: 3 }}>
        Total Active Clients: {clients.filter(c => c.status === 'active').length}
      </Alert>
      <Grid container spacing={3}>
        {clients.map(client => (
          <Grid item xs={12} md={6} key={client.id}>
            <Card
              onClick={(e) => handleViewDetails(e, client)}
              sx={{
                cursor: 'pointer',
                transition: 'all 0.2s ease',
                '&:hover': {
                  boxShadow: 6,
                  transform: 'translateY(-4px)'
                }
              }}
            >
              <CardHeader
                title={client.name}
                subheader={client.industry}
                action={
                  <Chip 
                    label={client.status} 
                    color={client.status === 'active' ? 'success' : 'default'}
                    size="small"
                    onClick={(e) => {
                      e.stopPropagation();
                      setSnackbar({ 
                        open: true, 
                        message: `Status: ${client.status}`, 
                        severity: 'info' 
                      });
                    }}
                    sx={{
                      cursor: 'pointer',
                      '&:hover': {
                        transform: 'scale(1.1)'
                      }
                    }}
                  />
                }
              />
              <CardContent>
                <Typography variant="body2" color="textSecondary">
                  Health Score: {client.health_score}/100
                </Typography>
                <Typography variant="body2" color="textSecondary">
                  Communication Style: {client.communication_style || 'Not set'}
                </Typography>
                <Typography variant="body2" color="textSecondary">
                  Emotional Trigger: {client.emotional_trigger || 'Not set'}
                </Typography>
                <Box sx={{ mt: 2, display: 'flex', gap: 1 }}>
                  <Button 
                    size="small" 
                    variant="contained" 
                    onClick={(e) => handleViewDetails(e, client)}
                  >
                    View Details
                  </Button>
                  <Button 
                    size="small" 
                    variant="outlined" 
                    onClick={() => handleContact(client)}
                  >
                    Contact
                  </Button>
                  <Button 
                    size="small" 
                    variant="text" 
                    onClick={() => handleAnalyze(client)}
                  >
                    Analyze
                  </Button>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      <Dialog open={openDialog} onClose={() => setOpenDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Add New Client</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            margin="dense"
            label="Client Name"
            fullWidth
            required
            value={newClient.name}
            onChange={(e) => setNewClient({ ...newClient, name: e.target.value })}
            sx={{ mb: 2, mt: 1 }}
          />
          <TextField
            margin="dense"
            label="Industry"
            fullWidth
            required
            value={newClient.industry}
            onChange={(e) => setNewClient({ ...newClient, industry: e.target.value })}
            sx={{ mb: 2 }}
          />
          <TextField
            margin="dense"
            label="Communication Style"
            fullWidth
            value={newClient.communication_style}
            onChange={(e) => setNewClient({ ...newClient, communication_style: e.target.value })}
            placeholder="e.g., Direct and analytical"
            sx={{ mb: 2 }}
          />
          <TextField
            margin="dense"
            label="Emotional Trigger"
            fullWidth
            value={newClient.emotional_trigger}
            onChange={(e) => setNewClient({ ...newClient, emotional_trigger: e.target.value })}
            placeholder="e.g., Innovation and efficiency"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenDialog(false)}>Cancel</Button>
          <Button onClick={handleAddClient} variant="contained">Add Client</Button>
        </DialogActions>
      </Dialog>

      {/* Client Detail Modal */}
      <Dialog 
        open={clientDetailOpen} 
        onClose={() => setClientDetailOpen(false)}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <Typography variant="h6">Client Details</Typography>
            <Button 
              onClick={() => setClientDetailOpen(false)}
              sx={{ minWidth: 'auto' }}
            >
              <Close />
            </Button>
          </Box>
        </DialogTitle>
        <DialogContent dividers>
          {selectedClient && (
            <Box>
              {/* Client Info */}
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
                <Typography variant="h5">
                  {selectedClient.name}
                </Typography>
                <Chip 
                  label={selectedClient.status} 
                  color={selectedClient.status === 'active' ? 'success' : 'default'}
                />
              </Box>
              
              <Grid container spacing={2} sx={{ mb: 3 }}>
                <Grid item xs={6}>
                  <Typography variant="caption" color="textSecondary">Industry</Typography>
                  <Typography variant="body1">{selectedClient.industry}</Typography>
                </Grid>
                <Grid item xs={6}>
                  <Typography variant="caption" color="textSecondary">Health Score</Typography>
                  <Typography variant="body1">{selectedClient.health_score}/100</Typography>
                </Grid>
                <Grid item xs={6}>
                  <Typography variant="caption" color="textSecondary">Communication Style</Typography>
                  <Typography variant="body1">{selectedClient.communication_style || 'Not set'}</Typography>
                </Grid>
                <Grid item xs={6}>
                  <Typography variant="caption" color="textSecondary">Emotional Trigger</Typography>
                  <Typography variant="body1">{selectedClient.emotional_trigger || 'Not set'}</Typography>
                </Grid>
              </Grid>
              
              {/* Recent Interactions */}
              <Typography variant="h6" gutterBottom sx={{ mt: 2 }}>
                Recent Interactions
              </Typography>
              <List dense>
                {selectedClient.interactions?.map((interaction, idx) => (
                  <ListItem 
                    key={idx}
                    sx={{
                      cursor: 'pointer',
                      '&:hover': {
                        backgroundColor: 'action.hover'
                      }
                    }}
                    onClick={() => {
                      setSnackbar({ 
                        open: true, 
                        message: `${interaction.type} on ${interaction.date}: ${interaction.notes}`, 
                        severity: 'info' 
                      });
                    }}
                  >
                    <ListItemIcon>
                      {interaction.type === 'Call' ? <People /> : 
                       interaction.type === 'Email' ? <TrendingUp /> : 
                       <Task />}
                    </ListItemIcon>
                    <ListItemText
                      primary={`${interaction.type} - ${interaction.date}`}
                      secondary={interaction.notes}
                    />
                  </ListItem>
                ))}
              </List>
              
              {/* Recent Activities */}
              <Typography variant="h6" gutterBottom sx={{ mt: 2 }}>
                Recent Activities
              </Typography>
              <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', mb: 2 }}>
                {selectedClient.recentActivities?.map((activity, idx) => (
                  <Chip 
                    key={idx} 
                    label={activity} 
                    size="small" 
                    variant="outlined"
                    onClick={() => {
                      setSnackbar({ 
                        open: true, 
                        message: `Activity: ${activity}`, 
                        severity: 'info' 
                      });
                    }}
                    sx={{
                      cursor: 'pointer',
                      '&:hover': {
                        transform: 'scale(1.05)'
                      }
                    }}
                  />
                ))}
              </Box>
              
              {/* Associated Tasks */}
              <Typography variant="h6" gutterBottom sx={{ mt: 2 }}>
                Associated Tasks
              </Typography>
              <List dense>
                {selectedClient.associatedTasks?.map((task) => (
                  <ListItem 
                    key={task.id}
                    sx={{
                      cursor: 'pointer',
                      '&:hover': {
                        backgroundColor: 'action.hover'
                      }
                    }}
                    onClick={() => {
                      navigate('/tasks');
                    }}
                  >
                    <ListItemIcon>
                      <Task />
                    </ListItemIcon>
                    <ListItemText primary={task.title} />
                    <Chip 
                      label={task.status} 
                      size="small"
                      color={task.status === 'completed' ? 'success' : 'warning'}
                    />
                  </ListItem>
                ))}
              </List>
              
              {/* Actions */}
              <Box sx={{ mt: 3, display: 'flex', gap: 2 }}>
                <Button 
                  variant="contained" 
                  color="primary"
                  onClick={() => {
                    setSnackbar({ 
                      open: true, 
                      message: `Initiating contact with ${selectedClient.name}...`, 
                      severity: 'info' 
                    });
                  }}
                >
                  Contact Client
                </Button>
                <Button 
                  variant="outlined"
                  onClick={() => {
                    handleAnalyze(selectedClient);
                  }}
                >
                  Run Analysis
                </Button>
                <Button 
                  variant="outlined"
                  color="warning"
                  onClick={() => {
                    setSnackbar({ 
                      open: true, 
                      message: `Opening ${selectedClient.name} settings...`, 
                      severity: 'info' 
                    });
                  }}
                >
                  Edit Client
                </Button>
              </Box>
            </Box>
          )}
        </DialogContent>
      </Dialog>

      <Snackbar 
        open={snackbar.open} 
        autoHideDuration={4000} 
        onClose={() => setSnackbar({ ...snackbar, open: false })}
      >
        <Alert severity={snackbar.severity} onClose={() => setSnackbar({ ...snackbar, open: false })}>
          {snackbar.message}
        </Alert>
      </Snackbar>
      {/* Analysis Result Dialog */}
      <Dialog open={analysisOpen} onClose={() => setAnalysisOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Analysis Result</DialogTitle>
        <DialogContent>
          {analysisResult ? (
            <Box>
              <Typography variant="h6">{analysisResult.client_name}</Typography>
              <Typography variant="body2">Risk Level: <strong>{analysisResult.risk_level}</strong></Typography>
              <Typography variant="body2">Health Score: {analysisResult.health_score}/100</Typography>
              <Box sx={{ mt: 2 }}>
                <Typography variant="subtitle2">Recommended Actions</Typography>
                <ul>
                  {(analysisResult.recommended_actions || []).map((a, i) => <li key={i}>{a}</li>)}
                </ul>
              </Box>
            </Box>
          ) : (
            <Typography>Loading...</Typography>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setAnalysisOpen(false)}>Close</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}

// ============================================================================
// RECOMMENDATIONS VIEW
// ============================================================================

function RecommendationsView() {
  const navigate = useNavigate();
  const [recommendations, setRecommendations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });

  useEffect(() => {
    loadRecommendations();
  }, []);

  const loadRecommendations = async () => {
    try {
      const response = await axios.get('/api/recommendations?status=pending').catch(err => {
        if (isDevMode()) {
          console.warn('🔧 Dev Mode: Using mock recommendations data');
          return { data: MOCK_DATA.recommendations.filter(r => r.status === 'pending') };
        }
        throw err;
      });
      setRecommendations(response.data);
    } catch (error) {
      console.error('Error loading recommendations:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = (rec) => {
    setRecommendations(prev => prev.filter(r => r.id !== rec.id));
    setSnackbar({ 
      open: true, 
      message: `Approved ${rec.recommendation_type} for ${rec.client_name}: ${rec.service_name}`, 
      severity: 'success' 
    });
  };

  const handleReject = (rec) => {
    setRecommendations(prev => prev.filter(r => r.id !== rec.id));
    setSnackbar({ 
      open: true, 
      message: `Rejected recommendation for ${rec.client_name}`, 
      severity: 'warning' 
    });
  };

  const handleEditDraft = (rec) => {
    setSnackbar({ 
      open: true, 
      message: `Opening email draft editor for ${rec.client_name} (${Math.round(rec.confidence_score * 100)}% confidence)`, 
      severity: 'info' 
    });
  };

  if (loading) {
    return <CircularProgress />;
  }

  return (
    <Box>
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
        <IconButton onClick={() => navigate('/')} sx={{ mr: 2 }}>
          <ArrowBackIcon />
        </IconButton>
        <Breadcrumbs>
          <Link to="/" style={{ textDecoration: 'none', color: 'inherit', display: 'flex', alignItems: 'center' }}>
            <HomeIcon sx={{ mr: 0.5 }} fontSize="small" />
            Dashboard
          </Link>
          <Typography color="text.primary">AI Recommendations</Typography>
        </Breadcrumbs>
      </Box>
      <Typography variant="h4" gutterBottom>
        AI Recommendations
      </Typography>
      <Alert severity="info" sx={{ mb: 3 }}>
        {recommendations.length} pending recommendations ready for review
      </Alert>
      {recommendations.map(rec => (
        <Card key={rec.id} sx={{ mb: 2 }}>
          <CardHeader
            title={`${rec.client_name} - ${rec.service_name}`}
            subheader={`Confidence: ${Math.round(rec.confidence_score * 100)}%`}
            action={
              <Chip label={rec.recommendation_type} color="primary" size="small" />
            }
          />
          <CardContent>
            <Typography variant="body2" paragraph>
              <strong>Trigger:</strong> {rec.trigger_type}
            </Typography>
            <Typography variant="body2" color="textSecondary" paragraph>
              {rec.reasoning}
            </Typography>
            <Box sx={{ display: 'flex', gap: 1, mt: 2 }}>
              <Button 
                size="small" 
                variant="contained" 
                color="success"
                onClick={() => handleApprove(rec)}
              >
                Approve & Send
              </Button>
              <Button 
                size="small" 
                variant="outlined" 
                onClick={() => handleEditDraft(rec)}
              >
                Edit Draft
              </Button>
              <Button 
                size="small" 
                variant="text" 
                color="error"
                onClick={() => handleReject(rec)}
              >
                Reject
              </Button>
            </Box>
          </CardContent>
        </Card>
      ))}
      <Snackbar 
        open={snackbar.open} 
        autoHideDuration={4000} 
        onClose={() => setSnackbar({ ...snackbar, open: false })}
      >
        <Alert severity={snackbar.severity} onClose={() => setSnackbar({ ...snackbar, open: false })}>
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
}

// ============================================================================
// TASKS VIEW
// ============================================================================

function TasksView() {
  const navigate = useNavigate();
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });
  const [openDialog, setOpenDialog] = useState(false);
  const [newTask, setNewTask] = useState({
    title: '',
    description: '',
    priority: 'medium',
    status: 'pending',
    assigned_to: '',
    client_id: '',
    due_date: ''
  });

  useEffect(() => {
    loadTasks();
  }, []);

  const loadTasks = async () => {
    try {
      const response = await axios.get('/api/tasks').catch(err => {
        if (isDevMode()) {
          console.warn('🔧 Dev Mode: Using mock tasks data');
          return { data: MOCK_DATA.tasks };
        }
        throw err;
      });
      setTasks(response.data);
    } catch (error) {
      console.error('Error loading tasks:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleMarkComplete = (task) => {
    setTasks(prev => prev.map(t => 
      t.id === task.id ? { ...t, status: 'completed' } : t
    ));
    setSnackbar({ 
      open: true, 
      message: `Marked "${task.title}" as completed`, 
      severity: 'success' 
    });
  };

  const handleAddTask = async () => {
    console.log('📝 handleAddTask called');
    console.log('Task data:', newTask);

    // Validation
    if (!newTask.title || !newTask.title.trim()) {
      setSnackbar({ open: true, message: 'Task title is required', severity: 'warning' });
      return;
    }

    if (!newTask.description || !newTask.description.trim()) {
      setSnackbar({ open: true, message: 'Task description is required', severity: 'warning' });
      return;
    }

    const taskToAdd = {
      id: Date.now(), // Use timestamp for unique ID
      title: newTask.title.trim(),
      description: newTask.description.trim(),
      priority: newTask.priority || 'medium',
      status: 'pending',
      assigned_to: newTask.assigned_to.trim() || 'Unassigned',
      client_id: newTask.client_id || null,
      client_name: newTask.client_id ? `Client ${newTask.client_id}` : 'No Client',
      type: 'general',
      due_date: newTask.due_date || new Date(Date.now() + 604800000).toISOString(),
      created_at: new Date().toISOString()
    };

    console.log('Task to add:', taskToAdd);

    try {
      // Try to add via API
      if (!isDevMode()) {
        await axios.post('/api/tasks', taskToAdd);
        console.log('✅ Task added via API');
      } else {
        console.log('🔧 Dev Mode: Adding task to local state only');
      }
      
      // Always update local state
      setTasks(prev => [...prev, taskToAdd]);
      setSnackbar({ 
        open: true, 
        message: `✅ Task "${taskToAdd.title}" created successfully!`, 
        severity: 'success' 
      });
      
      // Close dialog and reset form
      setOpenDialog(false);
      setNewTask({
        title: '',
        description: '',
        priority: 'medium',
        status: 'pending',
        assigned_to: '',
        client_id: '',
        due_date: ''
      });

      console.log('✅ Task added successfully');
    } catch (error) {
      console.error('❌ Error adding task:', error);
      
      // On API error, still add locally
      setTasks(prev => [...prev, taskToAdd]);
      setSnackbar({ 
        open: true, 
        message: 'Task created locally (API unavailable)', 
        severity: 'info' 
      });
      
      // Close dialog and reset form
      setOpenDialog(false);
      setNewTask({
        title: '',
        description: '',
        priority: 'medium',
        status: 'pending',
        assigned_to: '',
        client_id: '',
        due_date: ''
      });
    }
  };

  const handleStartTask = (task) => {
    setTasks(prev => prev.map(t => 
      t.id === task.id ? { ...t, status: 'in_progress' } : t
    ));
    setSnackbar({ 
      open: true, 
      message: `Started working on "${task.title}"`, 
      severity: 'info' 
    });
  };

  const handleDeleteTask = (task) => {
    setTasks(prev => prev.filter(t => t.id !== task.id));
    setSnackbar({ 
      open: true, 
      message: `Deleted task: "${task.title}"`, 
      severity: 'warning' 
    });
  };

  // Always render UI, don't block on loading
  const filteredTasks = filter === 'all' 
    ? tasks 
    : tasks.filter(t => t.status === filter);

  const tasksByStatus = {
    pending: tasks.filter(t => t.status === 'pending').length,
    in_progress: tasks.filter(t => t.status === 'in_progress').length,
    completed: tasks.filter(t => t.status === 'completed').length
  };

  const getPriorityColor = (priority) => {
    switch(priority) {
      case 'high': return 'error';
      case 'medium': return 'warning';
      case 'low': return 'default';
      default: return 'default';
    }
  };

  const getStatusColor = (status) => {
    switch(status) {
      case 'completed': return 'success';
      case 'in_progress': return 'info';
      case 'pending': return 'default';
      default: return 'default';
    }
  };

  return (
    <Box sx={{ position: 'relative', pb: 8 }}>
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
        <IconButton onClick={() => navigate('/')} sx={{ mr: 2 }}>
          <ArrowBackIcon />
        </IconButton>
        <Breadcrumbs>
          <Link to="/" style={{ textDecoration: 'none', color: 'inherit', display: 'flex', alignItems: 'center' }}>
            <HomeIcon sx={{ mr: 0.5 }} fontSize="small" />
            Dashboard
          </Link>
          <Typography color="text.primary">Tasks</Typography>
        </Breadcrumbs>
      </Box>
      
      {/* PROMINENT Add Task Button - TOP CENTER */}
      <Box sx={{ 
        display: 'flex', 
        justifyContent: 'center', 
        mb: 3,
        mt: 2
      }}>
        <Button 
          variant="contained" 
          color="success"
          size="large"
          startIcon={<AddIcon />}
          onClick={() => {
            console.log('🟢 GREEN Add Task button clicked!');
            console.log('Current openDialog state:', openDialog);
            setOpenDialog(true);
            console.log('Dialog should now be open');
          }}
          sx={{ 
            minWidth: '300px',
            height: '56px',
            fontWeight: 900,
            fontSize: '18px',
            boxShadow: 8,
            backgroundColor: '#2e7d32',
            border: '3px solid #1b5e20',
            textTransform: 'uppercase',
            letterSpacing: '1px',
            '&:hover': {
              backgroundColor: '#1b5e20',
              boxShadow: 12,
              transform: 'scale(1.1)'
            }
          }}
        >
          ➕ ADD NEW TASK
        </Button>
      </Box>
      
      {/* Header */}
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', mb: 3 }}>
        <Typography variant="h4" sx={{ fontWeight: 600 }}>
          Tasks
        </Typography>
      </Box>
      
      {/* Floating Action Button for mobile */}
      <Button
        variant="contained"
        color="secondary"
        onClick={() => {
          console.log('🟣 FLOATING Add Task button clicked!');
          setOpenDialog(true);
        }}
        sx={{
          position: 'fixed',
          bottom: 24,
          right: 24,
          width: 64,
          height: 64,
          borderRadius: '50%',
          minWidth: 'unset',
          boxShadow: 6,
          zIndex: 1000,
          fontSize: '24px',
          '&:hover': {
            boxShadow: 10,
            transform: 'scale(1.1)'
          }
        }}
      >
        ➕
      </Button>
      
      <Grid container spacing={2} sx={{ mb: 3 }}>
        <Grid item xs={12} sm={4}>
          <Card>
            <CardContent>
              <Typography variant="h6" color="textSecondary">Pending</Typography>
              <Typography variant="h3">{tasksByStatus.pending}</Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={4}>
          <Card>
            <CardContent>
              <Typography variant="h6" color="textSecondary">In Progress</Typography>
              <Typography variant="h3">{tasksByStatus.in_progress}</Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={4}>
          <Card>
            <CardContent>
              <Typography variant="h6" color="textSecondary">Completed</Typography>
              <Typography variant="h3">{tasksByStatus.completed}</Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      <Box sx={{ mb: 2 }}>
        <Chip 
          label="All" 
          onClick={() => setFilter('all')} 
          color={filter === 'all' ? 'primary' : 'default'}
          sx={{ mr: 1 }}
        />
        <Chip 
          label="Pending" 
          onClick={() => setFilter('pending')} 
          color={filter === 'pending' ? 'primary' : 'default'}
          sx={{ mr: 1 }}
        />
        <Chip 
          label="In Progress" 
          onClick={() => setFilter('in_progress')} 
          color={filter === 'in_progress' ? 'primary' : 'default'}
          sx={{ mr: 1 }}
        />
        <Chip 
          label="Completed" 
          onClick={() => setFilter('completed')} 
          color={filter === 'completed' ? 'primary' : 'default'}
        />
      </Box>

      {/* Loading State */}
      {loading && (
        <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
          <CircularProgress />
        </Box>
      )}

      {/* Empty State */}
      {!loading && filteredTasks.length === 0 && (
        <Card sx={{ p: 4, textAlign: 'center' }}>
          <Typography variant="h6" color="textSecondary" gutterBottom>
            No tasks found
          </Typography>
          <Typography variant="body2" color="textSecondary" paragraph>
            {filter === 'all' 
              ? 'Click the green "ADD NEW TASK" button above to create your first task'
              : `No tasks with status "${filter}"`
            }
          </Typography>
          <Button 
            variant="contained" 
            color="success"
            startIcon={<AddIcon />}
            onClick={() => {
              console.log('🟢 Empty state button clicked');
              setOpenDialog(true);
            }}
            sx={{ mt: 2 }}
          >
            Add Your First Task
          </Button>
        </Card>
      )}

      {/* Tasks List */}
      {!loading && filteredTasks.map(task => (
        <Card key={task.id} sx={{ mb: 2 }}>
          <CardHeader
            title={task.title}
            subheader={`Client: ${task.client_name} | Due: ${new Date(task.due_date).toLocaleDateString()}`}
            action={
              <Box>
                <Chip 
                  label={task.priority} 
                  color={getPriorityColor(task.priority)} 
                  size="small"
                  sx={{ mr: 1 }}
                />
                <Chip 
                  label={task.status} 
                  color={getStatusColor(task.status)} 
                  size="small"
                />
              </Box>
            }
          />
          <CardContent>
            <Typography variant="body2" color="textSecondary" paragraph>
              Type: {task.type}
            </Typography>
            <Typography variant="body2" paragraph>
              {task.description}
            </Typography>
            <Box sx={{ display: 'flex', gap: 1, mt: 2 }}>
              {task.status === 'pending' && (
                <Button 
                  size="small" 
                  variant="contained" 
                  onClick={() => handleStartTask(task)}
                >
                  Start Task
                </Button>
              )}
              {task.status === 'in_progress' && (
                <Button 
                  size="small" 
                  variant="contained" 
                  color="success"
                  onClick={() => handleMarkComplete(task)}
                >
                  Mark Complete
                </Button>
              )}
              {task.status !== 'completed' && (
                <Button 
                  size="small" 
                  variant="outlined"
                  onClick={() => setSnackbar({ open: true, message: `Editing task: ${task.title}`, severity: 'info' })}
                >
                  Edit
                </Button>
              )}
              <Button 
                size="small" 
                variant="text" 
                color="error"
                onClick={() => handleDeleteTask(task)}
              >
                Delete
              </Button>
            </Box>
          </CardContent>
        </Card>
      ))}

      {/* Add Task Dialog */}
      <Dialog 
        open={openDialog} 
        onClose={() => {
          console.log('❌ Dialog closing');
          setOpenDialog(false);
        }} 
        maxWidth="sm" 
        fullWidth
        disableEscapeKeyDown={false}
        PaperProps={{
          sx: { 
            minHeight: '500px',
            border: '3px solid #2e7d32',
            boxShadow: 24,
            borderRadius: 2
          }
        }}
      >
        <DialogTitle sx={{ 
          backgroundColor: '#2e7d32', 
          color: 'white',
          fontWeight: 'bold',
          fontSize: '1.5rem'
        }}>
          ➕ Add New Task
        </DialogTitle>
        <DialogContent sx={{ pt: 3 }}>
          <Box 
            component="form" 
            onSubmit={(e) => {
              e.preventDefault();
              handleAddTask();
            }}
          >
            <TextField
              autoFocus
              margin="dense"
              label="Task Title *"
              fullWidth
              required
              placeholder="e.g., Follow up with Acme Corp"
              value={newTask.title}
              onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
              onKeyPress={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                }
              }}
              sx={{ mb: 2, mt: 1 }}
              helperText="Required field"
            />
            <TextField
              margin="dense"
              label="Description *"
              fullWidth
              required
              multiline
              rows={4}
              placeholder="e.g., Discuss Q1 pricing and requirements"
              value={newTask.description}
              onChange={(e) => setNewTask({ ...newTask, description: e.target.value })}
              sx={{ mb: 2 }}
              helperText="Required field - Provide detailed task information"
            />
          <FormControl fullWidth sx={{ mb: 2 }}>
            <InputLabel>Priority</InputLabel>
            <Select
              value={newTask.priority}
              label="Priority"
              onChange={(e) => setNewTask({ ...newTask, priority: e.target.value })}
            >
              <MenuItem value="low">Low</MenuItem>
              <MenuItem value="medium">Medium</MenuItem>
              <MenuItem value="high">High</MenuItem>
            </Select>
          </FormControl>
            <TextField
              margin="dense"
              label="Assigned To"
              fullWidth
              value={newTask.assigned_to}
              onChange={(e) => setNewTask({ ...newTask, assigned_to: e.target.value })}
              placeholder="e.g., Sales Team, John Doe"
              sx={{ mb: 2 }}
              helperText="Optional - Leave blank for unassigned"
            />
            <TextField
              margin="dense"
              label="Client ID"
              fullWidth
              type="number"
              value={newTask.client_id}
              onChange={(e) => setNewTask({ ...newTask, client_id: e.target.value })}
              placeholder="e.g., 1"
              sx={{ mb: 2 }}
              helperText="Optional - Link task to a specific client"
            />
            <TextField
              margin="dense"
              label="Due Date"
              fullWidth
              type="date"
              value={newTask.due_date ? new Date(newTask.due_date).toISOString().split('T')[0] : ''}
              onChange={(e) => setNewTask({ ...newTask, due_date: new Date(e.target.value).toISOString() })}
              InputLabelProps={{ shrink: true }}
              helperText="Optional - Defaults to 7 days from now"
            />
          </Box>
        </DialogContent>
        <DialogActions sx={{ p: 3, gap: 2 }}>
          <Button 
            onClick={() => {
              console.log('❌ Cancel clicked');
              setOpenDialog(false);
              setNewTask({
                title: '',
                description: '',
                priority: 'medium',
                status: 'pending',
                assigned_to: '',
                client_id: '',
                due_date: ''
              });
            }}
            size="large"
            variant="outlined"
          >
            Cancel
          </Button>
          <Button 
            onClick={handleAddTask} 
            variant="contained"
            color="success"
            size="large"
            startIcon={<AddIcon />}
            disabled={!newTask.title || !newTask.description}
            sx={{ minWidth: '150px' }}
          >
            Add Task
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar 
        open={snackbar.open} 
        autoHideDuration={5000} 
        onClose={() => setSnackbar({ ...snackbar, open: false })}
        anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
      >
        <Alert 
          severity={snackbar.severity} 
          onClose={() => setSnackbar({ ...snackbar, open: false })}
          variant="filled"
          sx={{ minWidth: '300px' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
}

// ============================================================================
// REPORTS VIEW
// ============================================================================

function ReportsView() {
  const navigate = useNavigate();
  const [reportType, setReportType] = useState('clients');
  const [dateRange, setDateRange] = useState('all');
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });
  const [reportData, setReportData] = useState({
    clients: [],
    recommendations: [],
    tasks: []
  });
  const [loading, setLoading] = useState(false);
  const [exporting, setExporting] = useState(false);

  useEffect(() => {
    loadReportData();
  }, [reportType]);

  const loadReportData = async () => {
    setLoading(true);
    try {
      const [clientsRes, recsRes, tasksRes] = await Promise.all([
        axios.get('/api/clients').catch(err => {
          if (isDevMode()) {
            console.warn('🔧 Dev Mode: Using mock clients data for reports');
            return { data: MOCK_DATA.clients };
          }
          throw err;
        }),
        axios.get('/api/recommendations').catch(err => {
          if (isDevMode()) {
            console.warn('🔧 Dev Mode: Using mock recommendations data for reports');
            return { data: MOCK_DATA.recommendations };
          }
          throw err;
        }),
        axios.get('/api/tasks').catch(err => {
          if (isDevMode()) {
            console.warn('🔧 Dev Mode: Using mock tasks data for reports');
            return { data: MOCK_DATA.tasks };
          }
          throw err;
        })
      ]);
      setReportData({
        clients: clientsRes.data,
        recommendations: recsRes.data,
        tasks: tasksRes.data
      });
    } catch (error) {
      console.error('Error loading report data:', error);
      setSnackbar({ open: true, message: 'Error loading report data', severity: 'error' });
    } finally {
      setLoading(false);
    }
  };

  const exportToCSV = (data, filename) => {
    if (!data || data.length === 0) {
      setSnackbar({ open: true, message: 'No data to export', severity: 'warning' });
      return;
    }

    setExporting(true);
    setTimeout(() => {
      let csv = '';
      
      if (reportType === 'clients') {
        csv = 'Client Name,Industry,Status,Health Score,Communication Style,Emotional Trigger\n';
        data.forEach(client => {
          csv += `"${client.name}","${client.industry}","${client.status}",${client.health_score},"${client.communication_style}","${client.emotional_trigger}"\n`;
        });
      } else if (reportType === 'recommendations') {
        csv = 'ID,Client,Service,Type,Confidence,Trigger,Reasoning,Status\n';
        data.forEach(rec => {
          csv += `${rec.id},"${rec.client_name}","${rec.service_name}","${rec.recommendation_type}",${rec.confidence_score},"${rec.trigger_type}","${rec.reasoning}","${rec.status}"\n`;
        });
      } else if (reportType === 'tasks') {
        csv = 'Task,Client,Type,Priority,Status,Due Date,Description\n';
        data.forEach(task => {
          csv += `"${task.title}","${task.client_name}","${task.type}","${task.priority}","${task.status}","${task.due_date}","${task.description}"\n`;
        });
      }

      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${filename}_${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
      
      setSnackbar({ open: true, message: `✓ Exported ${data.length} records to ${filename}.csv`, severity: 'success' });
      setExporting(false);
    }, 300);
  };

  const exportToJSON = (data, filename) => {
    if (!data || data.length === 0) {
      setSnackbar({ open: true, message: 'No data to export', severity: 'warning' });
      return;
    }

    setExporting(true);
    setTimeout(() => {
      const exportData = {
        reportType: getReportTitle(),
        generatedAt: new Date().toISOString(),
        dateRange: dateRange,
        totalRecords: data.length,
        data: data
      };
      
      const json = JSON.stringify(exportData, null, 2);
      const blob = new Blob([json], { type: 'application/json' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${filename}_${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
      
      setSnackbar({ open: true, message: `✓ Exported ${data.length} records to ${filename}.json`, severity: 'success' });
      setExporting(false);
    }, 300);
  };

  const printReport = () => {
    const currentData = getCurrentData();
    if (!currentData || currentData.length === 0) {
      setSnackbar({ open: true, message: 'No data to print', severity: 'warning' });
      return;
    }
    
    setSnackbar({ open: true, message: 'Opening print dialog...', severity: 'info' });
    setTimeout(() => {
      window.print();
    }, 500);
  };

  const handleReportTypeChange = (newType) => {
    setReportType(newType);
    setSnackbar({ open: true, message: `Switched to ${newType} report`, severity: 'info' });
  };

  const handleDateRangeChange = (newRange) => {
    setDateRange(newRange);
    const rangeLabels = {
      all: 'All Time',
      today: 'Today',
      week: 'This Week',
      month: 'This Month',
      quarter: 'This Quarter'
    };
    setSnackbar({ open: true, message: `Date range: ${rangeLabels[newRange]}`, severity: 'info' });
  };

  const handleRowAction = (e, action, row, rowType) => {
    if (e) {
      e.stopPropagation();
    }
    
    console.log('Action triggered:', action, 'for', rowType, row);
    
    const actions = {
      view: () => {
        if (rowType === 'client' && (row.id || row.client_id)) {
          navigate(`/clients/${row.id || row.client_id}`);
        } else {
          setSnackbar({ open: true, message: `Viewing details for: ${row.name || row.title || row.client_name}`, severity: 'info' });
        }
      },
      edit: () => {
        if (rowType === 'client' && (row.id || row.client_id)) {
          navigate(`/clients/${row.id || row.client_id}/edit`);
        } else {
          setSnackbar({ open: true, message: `Editing: ${row.name || row.title || row.client_name}`, severity: 'info' });
        }
      },
      delete: () => setSnackbar({ open: true, message: `Deleted: ${row.name || row.title || row.client_name}`, severity: 'warning' }),
      contact: () => {
        if (rowType === 'client' && (row.id || row.client_id)) {
          navigate(`/clients/${row.id || row.client_id}/contact`);
        } else {
          setSnackbar({ open: true, message: `Contacting: ${row.name || row.client_name}`, severity: 'success' });
        }
      },
      approve: () => setSnackbar({ open: true, message: `Approved recommendation #${row.id}`, severity: 'success' }),
      reject: () => setSnackbar({ open: true, message: `Rejected recommendation #${row.id}`, severity: 'error' }),
      start: () => setSnackbar({ open: true, message: `Started task: ${row.title}`, severity: 'info' }),
      complete: () => setSnackbar({ open: true, message: `Completed task: ${row.title}`, severity: 'success' }),
      details: () => setSnackbar({ open: true, message: `Task details: ${row.description || 'No description'}`, severity: 'info' })
    };
    
    if (actions[action]) {
      actions[action]();
    }
  };

  const getCurrentData = () => {
    return reportData[reportType] || [];
  };

  const getReportTitle = () => {
    switch(reportType) {
      case 'clients': return 'Client Data Report';
      case 'recommendations': return 'AI Recommendations Report';
      case 'tasks': return 'Tasks & Activities Report';
      default: return 'Data Report';
    }
  };

  const getReportStats = () => {
    const data = getCurrentData();
    if (reportType === 'clients') {
      const active = data.filter(c => c.status === 'active').length;
      const avgHealth = data.length > 0 ? (data.reduce((sum, c) => sum + c.health_score, 0) / data.length).toFixed(1) : 0;
      return { total: data.length, active, avgHealth };
    } else if (reportType === 'recommendations') {
      const pending = data.filter(r => r.status === 'pending').length;
      const avgConfidence = data.length > 0 ? (data.reduce((sum, r) => sum + r.confidence_score, 0) / data.length * 100).toFixed(1) : 0;
      return { total: data.length, pending, avgConfidence };
    } else if (reportType === 'tasks') {
      const pending = data.filter(t => t.status === 'pending').length;
      const completed = data.filter(t => t.status === 'completed').length;
      return { total: data.length, pending, completed };
    }
    return {};
  };

  if (loading) {
    return <CircularProgress />;
  }

  const currentData = getCurrentData();
  const stats = getReportStats();

  return (
    <Box>
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
        <IconButton onClick={() => navigate('/')} sx={{ mr: 2 }}>
          <ArrowBackIcon />
        </IconButton>
        <Breadcrumbs>
          <Link to="/" style={{ textDecoration: 'none', color: 'inherit', display: 'flex', alignItems: 'center' }}>
            <HomeIcon sx={{ mr: 0.5 }} fontSize="small" />
            Dashboard
          </Link>
          <Typography color="text.primary">Reports</Typography>
        </Breadcrumbs>
      </Box>

      <Typography variant="h4" gutterBottom>
        Comprehensive Reports
      </Typography>

      {/* Report Controls */}
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Grid container spacing={2} alignItems="center">
            <Grid item xs={12} md={4}>
              <FormControl fullWidth>
                <InputLabel>Report Type</InputLabel>
                <Select
                  value={reportType}
                  label="Report Type"
                  onChange={(e) => handleReportTypeChange(e.target.value)}
                  disabled={loading}
                >
                  <MenuItem value="clients">Client Data Report</MenuItem>
                  <MenuItem value="recommendations">AI Recommendations Report</MenuItem>
                  <MenuItem value="tasks">Tasks & Activities Report</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} md={4}>
              <FormControl fullWidth>
                <InputLabel>Date Range</InputLabel>
                <Select
                  value={dateRange}
                  label="Date Range"
                  onChange={(e) => handleDateRangeChange(e.target.value)}
                  disabled={loading}
                >
                  <MenuItem value="all">All Time</MenuItem>
                  <MenuItem value="today">Today</MenuItem>
                  <MenuItem value="week">This Week</MenuItem>
                  <MenuItem value="month">This Month</MenuItem>
                  <MenuItem value="quarter">This Quarter</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} md={4}>
              <Box sx={{ display: 'flex', gap: 1 }}>
                <Button 
                  variant="contained" 
                  startIcon={<DownloadIcon />}
                  onClick={() => exportToCSV(currentData, getReportTitle().replace(/ /g, '_'))}
                  disabled={exporting || loading || currentData.length === 0}
                  fullWidth
                  sx={{ 
                    transition: 'all 0.3s ease',
                    '&:hover': { 
                      transform: 'translateY(-2px)',
                      boxShadow: 3
                    }
                  }}
                >
                  {exporting ? 'Exporting...' : 'Export CSV'}
                </Button>
                <Button 
                  variant="outlined" 
                  startIcon={<DownloadIcon />}
                  onClick={() => exportToJSON(currentData, getReportTitle().replace(/ /g, '_'))}
                  disabled={exporting || loading || currentData.length === 0}
                  fullWidth
                  sx={{ 
                    transition: 'all 0.3s ease',
                    '&:hover': { 
                      transform: 'translateY(-2px)',
                      boxShadow: 2
                    }
                  }}
                >
                  {exporting ? 'Exporting...' : 'Export JSON'}
                </Button>
                <IconButton 
                  onClick={printReport} 
                  color="primary"
                  disabled={loading || currentData.length === 0}
                  sx={{ 
                    transition: 'all 0.3s ease',
                    '&:hover': { 
                      transform: 'scale(1.1)',
                      bgcolor: 'action.hover'
                    }
                  }}
                >
                  <PrintIcon />
                </IconButton>
              </Box>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      {/* Report Statistics */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid item xs={12} md={4}>
          <Card 
            sx={{ 
              cursor: 'pointer',
              transition: 'all 0.3s ease',
              '&:hover': { 
                transform: 'translateY(-4px)',
                boxShadow: 6,
                bgcolor: 'primary.light',
                color: 'white'
              }
            }}
            onClick={() => setSnackbar({ open: true, message: `Total: ${stats.total || 0} records`, severity: 'info' })}
          >
            <CardContent>
              <Typography color="inherit" gutterBottom>Total Records</Typography>
              <Typography variant="h3" color="inherit">{stats.total || 0}</Typography>
            </CardContent>
          </Card>
        </Grid>
        {reportType === 'clients' && (
          <>
            <Grid item xs={12} md={4}>
              <Card
                sx={{ 
                  cursor: 'pointer',
                  transition: 'all 0.3s ease',
                  '&:hover': { 
                    transform: 'translateY(-4px)',
                    boxShadow: 6,
                    bgcolor: 'success.light',
                    color: 'white'
                  }
                }}
                onClick={() => setSnackbar({ open: true, message: `${stats.active} active clients`, severity: 'success' })}
              >
                <CardContent>
                  <Typography color="inherit" gutterBottom>Active Clients</Typography>
                  <Typography variant="h3" color="inherit">{stats.active}</Typography>
                </CardContent>
              </Card>
            </Grid>
            <Grid item xs={12} md={4}>
              <Card
                sx={{ 
                  cursor: 'pointer',
                  transition: 'all 0.3s ease',
                  '&:hover': { 
                    transform: 'translateY(-4px)',
                    boxShadow: 6,
                    bgcolor: 'info.light',
                    color: 'white'
                  }
                }}
                onClick={() => setSnackbar({ open: true, message: `Average health score: ${stats.avgHealth}`, severity: 'info' })}
              >
                <CardContent>
                  <Typography color="inherit" gutterBottom>Avg Health Score</Typography>
                  <Typography variant="h3" color="inherit">{stats.avgHealth}</Typography>
                </CardContent>
              </Card>
            </Grid>
          </>
        )}
        {reportType === 'recommendations' && (
          <>
            <Grid item xs={12} md={4}>
              <Card
                sx={{ 
                  cursor: 'pointer',
                  transition: 'all 0.3s ease',
                  '&:hover': { 
                    transform: 'translateY(-4px)',
                    boxShadow: 6,
                    bgcolor: 'warning.light',
                    color: 'white'
                  }
                }}
                onClick={() => setSnackbar({ open: true, message: `${stats.pending} pending recommendations`, severity: 'warning' })}
              >
                <CardContent>
                  <Typography color="inherit" gutterBottom>Pending</Typography>
                  <Typography variant="h3" color="inherit">{stats.pending}</Typography>
                </CardContent>
              </Card>
            </Grid>
            <Grid item xs={12} md={4}>
              <Card
                sx={{ 
                  cursor: 'pointer',
                  transition: 'all 0.3s ease',
                  '&:hover': { 
                    transform: 'translateY(-4px)',
                    boxShadow: 6,
                    bgcolor: 'info.light',
                    color: 'white'
                  }
                }}
                onClick={() => setSnackbar({ open: true, message: `Average confidence: ${stats.avgConfidence}%`, severity: 'info' })}
              >
                <CardContent>
                  <Typography color="inherit" gutterBottom>Avg Confidence</Typography>
                  <Typography variant="h3" color="inherit">{stats.avgConfidence}%</Typography>
                </CardContent>
              </Card>
            </Grid>
          </>
        )}
        {reportType === 'tasks' && (
          <>
            <Grid item xs={12} md={4}>
              <Card
                sx={{ 
                  cursor: 'pointer',
                  transition: 'all 0.3s ease',
                  '&:hover': { 
                    transform: 'translateY(-4px)',
                    boxShadow: 6,
                    bgcolor: 'warning.light',
                    color: 'white'
                  }
                }}
                onClick={() => setSnackbar({ open: true, message: `${stats.pending} pending tasks`, severity: 'warning' })}
              >
                <CardContent>
                  <Typography color="inherit" gutterBottom>Pending</Typography>
                  <Typography variant="h3" color="inherit">{stats.pending}</Typography>
                </CardContent>
              </Card>
            </Grid>
            <Grid item xs={12} md={4}>
              <Card
                sx={{ 
                  cursor: 'pointer',
                  transition: 'all 0.3s ease',
                  '&:hover': { 
                    transform: 'translateY(-4px)',
                    boxShadow: 6,
                    bgcolor: 'success.light',
                    color: 'white'
                  }
                }}
                onClick={() => setSnackbar({ open: true, message: `${stats.completed} completed tasks`, severity: 'success' })}
              >
                <CardContent>
                  <Typography color="inherit" gutterBottom>Completed</Typography>
                  <Typography variant="h3" color="inherit">{stats.completed}</Typography>
                </CardContent>
              </Card>
            </Grid>
          </>
        )}
      </Grid>

      {/* Report Table */}
      <Card>
        <CardHeader title={getReportTitle()} />
        <CardContent>
          <TableContainer component={Paper} variant="outlined">
            <Table>
              <TableHead>
                <TableRow>
                  {reportType === 'clients' && (
                    <>
                      <TableCell><strong>Client Name</strong></TableCell>
                      <TableCell><strong>Industry</strong></TableCell>
                      <TableCell><strong>Status</strong></TableCell>
                      <TableCell><strong>Health Score</strong></TableCell>
                      <TableCell><strong>Communication Style</strong></TableCell>
                      <TableCell><strong>Emotional Trigger</strong></TableCell>
                      <TableCell align="center"><strong>Actions</strong></TableCell>
                    </>
                  )}
                  {reportType === 'recommendations' && (
                    <>
                      <TableCell><strong>ID</strong></TableCell>
                      <TableCell><strong>Client</strong></TableCell>
                      <TableCell><strong>Service</strong></TableCell>
                      <TableCell><strong>Type</strong></TableCell>
                      <TableCell><strong>Confidence</strong></TableCell>
                      <TableCell><strong>Trigger</strong></TableCell>
                      <TableCell><strong>Status</strong></TableCell>
                      <TableCell align="center"><strong>Actions</strong></TableCell>
                    </>
                  )}
                  {reportType === 'tasks' && (
                    <>
                      <TableCell><strong>Task</strong></TableCell>
                      <TableCell><strong>Client</strong></TableCell>
                      <TableCell><strong>Type</strong></TableCell>
                      <TableCell><strong>Priority</strong></TableCell>
                      <TableCell><strong>Status</strong></TableCell>
                      <TableCell><strong>Due Date</strong></TableCell>
                      <TableCell align="center"><strong>Actions</strong></TableCell>
                    </>
                  )}
                </TableRow>
              </TableHead>
              <TableBody>
                {currentData.map((row, index) => (
                  <TableRow key={index} hover>
                    {reportType === 'clients' && (
                      <>
                        <TableCell>
                          <Typography 
                            variant="body1" 
                            sx={{ fontWeight: 600, cursor: 'pointer', '&:hover': { color: 'primary.main' } }}
                            onClick={(e) => handleRowAction(e, 'view', row, 'client')}
                          >
                            {row.name}
                          </Typography>
                        </TableCell>
                        <TableCell>{row.industry}</TableCell>
                        <TableCell>
                          <Chip 
                            label={row.status} 
                            size="small" 
                            color={row.status === 'active' ? 'success' : 'default'}
                            clickable
                            onClick={(e) => handleRowAction(e, 'view', row, 'client')}
                          />
                        </TableCell>
                        <TableCell>
                          <Typography 
                            variant="body2" 
                            sx={{ 
                              fontWeight: 'bold',
                              color: row.health_score >= 75 ? 'success.main' : row.health_score >= 50 ? 'warning.main' : 'error.main'
                            }}
                          >
                            {row.health_score}/100
                          </Typography>
                        </TableCell>
                        <TableCell>{row.communication_style}</TableCell>
                        <TableCell>{row.emotional_trigger}</TableCell>
                        <TableCell align="center">
                          <Box sx={{ display: 'flex', gap: 0.5, justifyContent: 'center' }}>
                            <Button 
                              size="small" 
                              variant="contained" 
                              color="primary"
                              onClick={(e) => handleRowAction(e, 'view', row, 'client')}
                              sx={{ minWidth: 'auto', px: 1 }}
                            >
                              View
                            </Button>
                            <Button 
                              size="small" 
                              variant="outlined" 
                              color="info"
                              onClick={(e) => handleRowAction(e, 'contact', row, 'client')}
                              sx={{ minWidth: 'auto', px: 1 }}
                            >
                              Contact
                            </Button>
                            <Button 
                              size="small" 
                              variant="outlined" 
                              color="secondary"
                              onClick={(e) => handleRowAction(e, 'edit', row, 'client')}
                              sx={{ minWidth: 'auto', px: 1 }}
                            >
                              Edit
                            </Button>
                          </Box>
                        </TableCell>
                      </>
                    )}
                    {reportType === 'recommendations' && (
                      <>
                        <TableCell>
                          <Typography 
                            variant="body2" 
                            sx={{ fontWeight: 600, cursor: 'pointer', '&:hover': { color: 'primary.main' } }}
                            onClick={(e) => handleRowAction(e, 'view', row, 'recommendation')}
                          >
                            #{row.id}
                          </Typography>
                        </TableCell>
                        <TableCell>{row.client_name}</TableCell>
                        <TableCell>{row.service_name}</TableCell>
                        <TableCell>
                          <Chip 
                            label={row.recommendation_type} 
                            size="small" 
                            color="primary" 
                            clickable
                            onClick={(e) => handleRowAction(e, 'view', row, 'recommendation')}
                          />
                        </TableCell>
                        <TableCell>
                          <Typography 
                            variant="body2" 
                            sx={{ 
                              fontWeight: 'bold',
                              color: row.confidence_score >= 0.8 ? 'success.main' : row.confidence_score >= 0.6 ? 'warning.main' : 'error.main'
                            }}
                          >
                            {Math.round(row.confidence_score * 100)}%
                          </Typography>
                        </TableCell>
                        <TableCell>{row.trigger_type}</TableCell>
                        <TableCell>
                          <Chip 
                            label={row.status} 
                            size="small" 
                            color={row.status === 'approved' ? 'success' : row.status === 'pending' ? 'warning' : 'default'}
                            clickable
                            onClick={(e) => handleRowAction(e, 'view', row, 'recommendation')}
                          />
                        </TableCell>
                        <TableCell align="center">
                          <Box sx={{ display: 'flex', gap: 0.5, justifyContent: 'center' }}>
                            {row.status === 'pending' && (
                              <>
                                <Button 
                                  size="small" 
                                  variant="contained" 
                                  color="success"
                                  onClick={(e) => handleRowAction(e, 'approve', row, 'recommendation')}
                                  sx={{ minWidth: 'auto', px: 1 }}
                                >
                                  Approve
                                </Button>
                                <Button 
                                  size="small" 
                                  variant="outlined" 
                                  color="error"
                                  onClick={(e) => handleRowAction(e, 'reject', row, 'recommendation')}
                                  sx={{ minWidth: 'auto', px: 1 }}
                                >
                                  Reject
                                </Button>
                              </>
                            )}
                            <Button 
                              size="small" 
                              variant="outlined" 
                              color="info"
                              onClick={(e) => handleRowAction(e, 'edit', row, 'recommendation')}
                              sx={{ minWidth: 'auto', px: 1 }}
                            >
                              Edit
                            </Button>
                          </Box>
                        </TableCell>
                      </>
                    )}
                    {reportType === 'tasks' && (
                      <>
                        <TableCell>
                          <Typography 
                            variant="body1" 
                            sx={{ fontWeight: 600, cursor: 'pointer', '&:hover': { color: 'primary.main' } }}
                            onClick={(e) => handleRowAction(e, 'details', row, 'task')}
                          >
                            {row.title}
                          </Typography>
                        </TableCell>
                        <TableCell>{row.client_name}</TableCell>
                        <TableCell>{row.type}</TableCell>
                        <TableCell>
                          <Chip 
                            label={row.priority} 
                            size="small" 
                            color={row.priority === 'high' ? 'error' : row.priority === 'medium' ? 'warning' : 'default'}
                            clickable
                            onClick={(e) => handleRowAction(e, 'details', row, 'task')}
                          />
                        </TableCell>
                        <TableCell>
                          <Chip 
                            label={row.status} 
                            size="small" 
                            color={row.status === 'completed' ? 'success' : row.status === 'in_progress' ? 'info' : 'default'}
                            clickable
                            onClick={(e) => handleRowAction(e, 'details', row, 'task')}
                          />
                        </TableCell>
                        <TableCell>
                          <Typography 
                            variant="body2" 
                            sx={{ 
                              color: new Date(row.due_date) < new Date() && row.status !== 'completed' ? 'error.main' : 'text.primary'
                            }}
                          >
                            {new Date(row.due_date).toLocaleDateString()}
                          </Typography>
                        </TableCell>
                        <TableCell align="center">
                          <Box sx={{ display: 'flex', gap: 0.5, justifyContent: 'center', flexWrap: 'wrap' }}>
                            {row.status === 'pending' && (
                              <Button 
                                size="small" 
                                variant="contained" 
                                color="info"
                                onClick={(e) => handleRowAction(e, 'start', row, 'task')}
                                sx={{ minWidth: 'auto', px: 1 }}
                              >
                                Start
                              </Button>
                            )}
                            {row.status === 'in_progress' && (
                              <Button 
                                size="small" 
                                variant="contained" 
                                color="success"
                                onClick={(e) => handleRowAction(e, 'complete', row, 'task')}
                                sx={{ minWidth: 'auto', px: 1 }}
                              >
                                Complete
                              </Button>
                            )}
                            <Button 
                              size="small" 
                              variant="outlined" 
                              color="primary"
                              onClick={(e) => handleRowAction(e, 'details', row, 'task')}
                              sx={{ minWidth: 'auto', px: 1 }}
                            >
                              Details
                            </Button>
                            <Button 
                              size="small" 
                              variant="outlined" 
                              color="error"
                              onClick={(e) => handleRowAction(e, 'delete', row, 'task')}
                              sx={{ minWidth: 'auto', px: 1 }}
                            >
                              Delete
                            </Button>
                          </Box>
                        </TableCell>
                      </>
                    )}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
          
          <Box sx={{ mt: 3, p: 2, bgcolor: 'grey.100', borderRadius: 1 }}>
            <Typography variant="caption" color="textSecondary">
              Report generated on {new Date().toLocaleString()} | Total records: {currentData.length}
            </Typography>
          </Box>
        </CardContent>
      </Card>

      <Snackbar 
        open={snackbar.open} 
        autoHideDuration={4000} 
        onClose={() => setSnackbar({ ...snackbar, open: false })}
      >
        <Alert severity={snackbar.severity} onClose={() => setSnackbar({ ...snackbar, open: false })}>
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
}

// ============================================================================
// SETTINGS VIEW
// ============================================================================

function SettingsView() {
  const navigate = useNavigate();
  const [devMode, setDevModeState] = useState(isDevMode());
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });
  const [settings, setSettings] = useState({
    notifications: {
      email: true,
      slack: true,
      realtime: true
    },
    integrations: {
      slack_enabled: true,
      fireflies_enabled: true,
      google_analytics_enabled: false,
      accelo_enabled: true
    },
    ai_preferences: {
      recommendation_threshold: 0.7,
      auto_draft_emails: true,
      sentiment_analysis: true
    }
  });

  // Load saved integration credentials from localStorage (secure storage not implemented here)
  useEffect(() => {
    try {
      const stored = localStorage.getItem('comit_integration_credentials');
      if (stored) {
        const creds = JSON.parse(stored);
        setSettings(prev => ({ ...prev, integrations: { ...prev.integrations, credentials: creds } }));
      }
    } catch (err) {
      console.warn('Unable to load saved integration credentials', err);
    }
  }, []);

  const handleDevModeToggle = () => {
    const newMode = !devMode;
    setDevMode(newMode);
    setDevModeState(newMode);
    setSnackbar({ 
      open: true, 
      message: newMode 
        ? '🔧 Development Mode ENABLED - Using mock data for demo' 
        : '✅ Development Mode DISABLED - Using real API data', 
      severity: newMode ? 'warning' : 'success' 
    });
  };

  const handleCredentialChange = (service, field, value) => {
    setSettings(prev => {
      const next = { ...prev };
      next.integrations = { ...next.integrations };
      next.integrations.credentials = { ...next.integrations.credentials };
      if (!next.integrations.credentials[service]) next.integrations.credentials[service] = {};
      next.integrations.credentials[service][field] = value;
      return next;
    });
  };

  const handleSaveCredentials = async () => {
    const creds = settings.integrations.credentials || {};
    try {
      await axios.post('/api/integrations/credentials', { credentials: creds });
      // Persist locally as convenience (not secure)
      localStorage.setItem('comit_integration_credentials', JSON.stringify(creds));
      setSnackbar({ open: true, message: 'Integration credentials saved successfully', severity: 'success' });
    } catch (err) {
      if (isDevMode()) {
        localStorage.setItem('comit_integration_credentials', JSON.stringify(creds));
        setSnackbar({ open: true, message: '(Dev) Credentials stored locally', severity: 'info' });
      } else {
        console.error('Error saving credentials:', err);
        setSnackbar({ open: true, message: 'Error saving credentials (see console)', severity: 'error' });
      }
    }
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
        <IconButton onClick={() => navigate('/')} sx={{ mr: 2 }}>
          <ArrowBackIcon />
        </IconButton>
        <Breadcrumbs>
          <Link to="/" style={{ textDecoration: 'none', color: 'inherit', display: 'flex', alignItems: 'center' }}>
            <HomeIcon sx={{ mr: 0.5 }} fontSize="small" />
            Dashboard
          </Link>
          <Typography color="text.primary">Settings</Typography>
        </Breadcrumbs>
      </Box>
      <Typography variant="h4" gutterBottom>
        Settings
      </Typography>

      {/* Development Mode Toggle - Comit Developers Only */}
      <Card sx={{ mb: 3, border: '2px solid', borderColor: devMode ? 'warning.main' : 'divider' }}>
        <CardHeader 
          title="Development Mode" 
          subheader="Comit Developers Dev Team"
          avatar={
            <Box 
              sx={{ 
                width: 40, 
                height: 40, 
                borderRadius: '50%', 
                backgroundColor: devMode ? 'warning.main' : 'action.disabled',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'white',
                fontWeight: 'bold'
              }}
            >
              🔧
            </Box>
          }
        />
        <CardContent>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            <Alert severity={devMode ? "warning" : "info"} sx={{ mb: 1 }}>
              {devMode ? (
                <Typography variant="body2">
                  <strong>Development Mode is ACTIVE</strong><br/>
                  Using containerized mock data for demonstration. Real API calls are bypassed.
                </Typography>
              ) : (
                <Typography variant="body2">
                  <strong>Production Mode is ACTIVE</strong><br/>
                  Connecting to live backend API. Mock data is disabled.
                </Typography>
              )}
            </Alert>
            
            <Box display="flex" alignItems="center" justifyContent="space-between">
              <Box>
                <Typography variant="body1" fontWeight={500}>
                  Use Mock Data
                </Typography>
                <Typography variant="caption" color="textSecondary">
                  Enable demo mode with sample data
                </Typography>
              </Box>
              <Button 
                variant={devMode ? "contained" : "outlined"}
                color={devMode ? "warning" : "primary"}
                onClick={handleDevModeToggle}
                startIcon={devMode ? '🔓' : '🔒'}
              >
                {devMode ? 'Enabled' : 'Disabled'}
              </Button>
            </Box>

            {devMode && (
              <Box sx={{ mt: 1, p: 2, backgroundColor: 'warning.light', borderRadius: 1 }}>
                <Typography variant="caption" color="text.secondary" display="block" gutterBottom>
                  <strong>Mock Data Container Active:</strong>
                </Typography>
                <Typography variant="caption" color="text.secondary" component="div" sx={{ ml: 2 }}>
                  • 12 Active Clients<br/>
                  • 8 Tasks (2 completed, 3 in progress, 3 pending)<br/>
                  • 6 AI Recommendations<br/>
                  • 8 Recent Events with multi-layer data<br/>
                  • 4 Integration health statuses<br/>
                  • All data isolated from production
                </Typography>
              </Box>
            )}
          </Box>
        </CardContent>
      </Card>

      <Card sx={{ mb: 3 }}>
        <CardHeader title="Notification Preferences" />
        <CardContent>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            <Box display="flex" alignItems="center" justifyContent="space-between">
              <Typography>Email Notifications</Typography>
              <Chip 
                label={settings.notifications.email ? "Enabled" : "Disabled"} 
                color={settings.notifications.email ? "success" : "default"}
              />
            </Box>
            <Box display="flex" alignItems="center" justifyContent="space-between">
              <Typography>Slack Notifications</Typography>
              <Chip 
                label={settings.notifications.slack ? "Enabled" : "Disabled"} 
                color={settings.notifications.slack ? "success" : "default"}
              />
            </Box>
            <Box display="flex" alignItems="center" justifyContent="space-between">
              <Typography>Real-time Updates</Typography>
              <Chip 
                label={settings.notifications.realtime ? "Enabled" : "Disabled"} 
                color={settings.notifications.realtime ? "success" : "default"}
              />
            </Box>
          </Box>
        </CardContent>
      </Card>

      <Card sx={{ mb: 3 }}>
        <CardHeader title="Integration Status" />
        <CardContent>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            <Box display="flex" alignItems="center" justifyContent="space-between">
              <Typography>Slack</Typography>
              <Chip 
                label={settings.integrations.slack_enabled ? "Connected" : "Disconnected"} 
                color={settings.integrations.slack_enabled ? "success" : "error"}
              />
            </Box>
            <Box display="flex" alignItems="center" justifyContent="space-between">
              <Typography>Fireflies.ai</Typography>
              <Chip 
                label={settings.integrations.fireflies_enabled ? "Connected" : "Disconnected"} 
                color={settings.integrations.fireflies_enabled ? "success" : "error"}
              />
            </Box>
            <Box display="flex" alignItems="center" justifyContent="space-between">
              <Typography>Google Analytics</Typography>
              <Chip 
                label={settings.integrations.google_analytics_enabled ? "Connected" : "Disconnected"} 
                color={settings.integrations.google_analytics_enabled ? "success" : "error"}
              />
            </Box>
            <Box display="flex" alignItems="center" justifyContent="space-between">
              <Typography>Accelo</Typography>
              <Chip 
                label={settings.integrations.accelo_enabled ? "Connected" : "Disconnected"} 
                color={settings.integrations.accelo_enabled ? "success" : "error"}
              />
            </Box>
          </Box>
        </CardContent>
      </Card>

      {/* Integration Credentials - allow entering API keys / tokens */}
      <Card sx={{ mt: 3, mb: 3 }}>
        <CardHeader title="Integration Credentials" subheader="Enter API keys, tokens or client secrets for integrations" />
        <CardContent>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Typography variant="subtitle2">Slack</Typography>
              <TextField
                label="Bot Token / API Key"
                fullWidth
                value={(settings.integrations.credentials && settings.integrations.credentials.slack && settings.integrations.credentials.slack.token) || ''}
                onChange={(e) => handleCredentialChange('slack', 'token', e.target.value)}
                helperText="xoxb-..."
                sx={{ mb: 1 }}
              />
            </Grid>

            <Grid item xs={12} md={6}>
              <Typography variant="subtitle2">Fireflies.ai</Typography>
              <TextField
                label="API Key"
                fullWidth
                value={(settings.integrations.credentials && settings.integrations.credentials.fireflies && settings.integrations.credentials.fireflies.apiKey) || ''}
                onChange={(e) => handleCredentialChange('fireflies', 'apiKey', e.target.value)}
                helperText="Fireflies API key"
                sx={{ mb: 1 }}
              />
            </Grid>

            <Grid item xs={12} md={6}>
              <Typography variant="subtitle2">Google Analytics / OAuth</Typography>
              <TextField
                label="Client ID"
                fullWidth
                value={(settings.integrations.credentials && settings.integrations.credentials.google_analytics && settings.integrations.credentials.google_analytics.clientId) || ''}
                onChange={(e) => handleCredentialChange('google_analytics', 'clientId', e.target.value)}
                sx={{ mb: 1 }}
              />
              <TextField
                label="Client Secret"
                fullWidth
                value={(settings.integrations.credentials && settings.integrations.credentials.google_analytics && settings.integrations.credentials.google_analytics.clientSecret) || ''}
                onChange={(e) => handleCredentialChange('google_analytics', 'clientSecret', e.target.value)}
                sx={{ mb: 1 }}
              />
            </Grid>

            <Grid item xs={12} md={6}>
              <Typography variant="subtitle2">Accelo</Typography>
              <TextField
                label="Client ID"
                fullWidth
                value={(settings.integrations.credentials && settings.integrations.credentials.accelo && settings.integrations.credentials.accelo.clientId) || ''}
                onChange={(e) => handleCredentialChange('accelo', 'clientId', e.target.value)}
                sx={{ mb: 1 }}
              />
              <TextField
                label="Client Secret"
                fullWidth
                value={(settings.integrations.credentials && settings.integrations.credentials.accelo && settings.integrations.credentials.accelo.clientSecret) || ''}
                onChange={(e) => handleCredentialChange('accelo', 'clientSecret', e.target.value)}
                sx={{ mb: 1 }}
              />
            </Grid>

            <Grid item xs={12}>
              <Box sx={{ display: 'flex', gap: 1 }}>
                <Button variant="contained" onClick={handleSaveCredentials}>Save Credentials</Button>
                <Button variant="outlined" onClick={() => {
                  // clear local store for dev testing
                  localStorage.removeItem('comit_integration_credentials');
                  setSettings(prev => ({ ...prev, integrations: { ...prev.integrations, credentials: {} } }));
                  setSnackbar({ open: true, message: 'Credentials cleared locally', severity: 'info' });
                }}>Clear Local</Button>
              </Box>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      <Card>
        <CardHeader title="AI Preferences" />
        <CardContent>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            <Box display="flex" alignItems="center" justifyContent="space-between">
              <Typography>Recommendation Confidence Threshold</Typography>
              <Typography variant="body2" color="textSecondary">
                {(settings.ai_preferences.recommendation_threshold * 100).toFixed(0)}%
              </Typography>
            </Box>
            <Box display="flex" alignItems="center" justifyContent="space-between">
              <Typography>Auto-draft Email Recommendations</Typography>
              <Chip 
                label={settings.ai_preferences.auto_draft_emails ? "Enabled" : "Disabled"} 
                color={settings.ai_preferences.auto_draft_emails ? "success" : "default"}
              />
            </Box>
            <Box display="flex" alignItems="center" justifyContent="space-between">
              <Typography>Sentiment Analysis</Typography>
              <Chip 
                label={settings.ai_preferences.sentiment_analysis ? "Enabled" : "Disabled"} 
                color={settings.ai_preferences.sentiment_analysis ? "success" : "default"}
              />
            </Box>
          </Box>
        </CardContent>
      </Card>

      <Snackbar 
        open={snackbar.open} 
        autoHideDuration={5000} 
        onClose={() => setSnackbar({ ...snackbar, open: false })}
      >
        <Alert severity={snackbar.severity} onClose={() => setSnackbar({ ...snackbar, open: false })}>
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
}

// ============================================================================
// MAIN APP COMPONENT
// ============================================================================

function App() {
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  const drawer = (
    <Box>
      <Toolbar>
        <Typography variant="h6" noWrap>
          CIA System
        </Typography>
      </Toolbar>
      <List>
        <ListItemButton component={Link} to="/">
          <ListItemIcon>
            <DashboardIcon />
          </ListItemIcon>
          <ListItemText primary="Dashboard" />
        </ListItemButton>
        <ListItemButton component={Link} to="/clients">
          <ListItemIcon>
            <PeopleIcon />
          </ListItemIcon>
          <ListItemText primary="Clients" />
        </ListItemButton>
        <ListItemButton component={Link} to="/recommendations">
          <ListItemIcon>
            <TrendingUpIcon />
          </ListItemIcon>
          <ListItemText primary="Recommendations" />
        </ListItemButton>
        <ListItemButton component={Link} to="/tasks">
          <ListItemIcon>
            <TaskIcon />
          </ListItemIcon>
          <ListItemText primary="Tasks" />
        </ListItemButton>
        <ListItemButton component={Link} to="/reports">
          <ListItemIcon>
            <AssessmentIcon />
          </ListItemIcon>
          <ListItemText primary="Reports" />
        </ListItemButton>
        <ListItemButton component={Link} to="/settings">
          <ListItemIcon>
            <SettingsIcon />
          </ListItemIcon>
          <ListItemText primary="Settings" />
        </ListItemButton>
      </List>
    </Box>
  );

  return (
    <ThemeProvider theme={theme}>
      <Router>
        <Box sx={{ display: 'flex' }}>
          <CssBaseline />
          <AppBar
            position="fixed"
            sx={{
              width: { sm: `calc(100% - ${drawerWidth}px)` },
              ml: { sm: `${drawerWidth}px` },
            }}
          >
            <Toolbar>
              <Typography variant="h6" noWrap component="div">
                Client Insights Agent
              </Typography>
              <Box sx={{ flexGrow: 1 }} />
              <NotificationsIcon sx={{ mr: 2, cursor: 'pointer' }} />
            </Toolbar>
          </AppBar>
          <Box
            component="nav"
            sx={{ width: { sm: drawerWidth }, flexShrink: { sm: 0 } }}
          >
            <Drawer
              variant="permanent"
              sx={{
                display: { xs: 'none', sm: 'block' },
                '& .MuiDrawer-paper': { boxSizing: 'border-box', width: drawerWidth },
              }}
              open
            >
              {drawer}
            </Drawer>
          </Box>
          <Box
            component="main"
            sx={{
              flexGrow: 1,
              p: 3,
              width: { sm: `calc(100% - ${drawerWidth}px)` },
            }}
          >
            <Toolbar />
            <Container maxWidth="lg">
              <ErrorBoundary>
                <Routes>
                  <Route path="/" element={<DashboardView />} />
                  <Route path="/clients" element={<ClientsView />} />
                  <Route path="/clients/:id" element={<ClientProfile />} />
                  <Route path="/clients/:id/contact" element={<ContactClient />} />
                  <Route path="/clients/:id/edit" element={<EditClient />} />
                  <Route path="/recommendations" element={<RecommendationsView />} />
                  <Route path="/tasks" element={<TasksView />} />
                  <Route path="/reports" element={<ReportsView />} />
                  <Route path="/settings" element={<SettingsView />} />
                </Routes>
              </ErrorBoundary>
            </Container>
          </Box>
        </Box>
      </Router>
    </ThemeProvider>
  );
}

// Helper functions
function calculateHealthScore(integrations) {
  if (!integrations || typeof integrations !== 'object') return 100;
  const values = Object.values(integrations);
  if (values.length === 0) return 100;
  const healthy = values.filter(i => i && (i.is_healthy || i.status === 'connected' || i.status === 'ready')).length;
  const total = values.length;
  return total > 0 ? Math.round((healthy / total) * 100) : 100;
}

function formatEventType(type) {
  if (!type) return 'Unknown Event';
  return type
    .split('_')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
}

function getEventIcon(eventType) {
  switch (eventType) {
    case 'call_detected':
      return <NotificationsIcon color="primary" />;
    case 'transcript_processed':
      return <CheckCircleIcon color="success" />;
    case 'recommendation_generated':
      return <TrendingUpIcon color="success" />;
    default:
      return <DashboardIcon />;
  }
}

export default App;
