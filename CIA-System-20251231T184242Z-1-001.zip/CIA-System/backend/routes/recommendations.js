const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  // Sample recommendations data
  const recommendations = [
    {
      id: 1,
      client_name: 'Acme Corporation',
      service_name: 'Cloud Migration Strategy',
      recommendation_type: 'upsell',
      confidence_score: 0.89,
      trigger_type: 'meeting_sentiment',
      reasoning: 'Client expressed concerns about infrastructure scalability during last meeting. High budget availability and positive sentiment toward modernization initiatives.',
      created_at: '2025-01-20T10:30:00Z',
      status: 'pending'
    },
    {
      id: 2,
      client_name: 'Global Dynamics',
      service_name: 'Preventive Maintenance Program',
      recommendation_type: 'proactive_support',
      confidence_score: 0.76,
      trigger_type: 'usage_pattern',
      reasoning: 'Analysis shows increased support tickets related to equipment downtime. Recommending preventive maintenance to reduce future issues.',
      created_at: '2025-01-19T14:15:00Z',
      status: 'pending'
    },
    {
      id: 3,
      client_name: 'Innovatech Solutions',
      service_name: 'AI/ML Development Services',
      recommendation_type: 'upsell',
      confidence_score: 0.94,
      trigger_type: 'industry_trend',
      reasoning: 'Client is in high-growth AI sector and has shown interest in emerging technologies. Budget approval likely based on recent successful project completion.',
      created_at: '2025-01-18T09:45:00Z',
      status: 'pending'
    },
    {
      id: 4,
      client_name: 'Healthcare Plus',
      service_name: 'Compliance Audit Support',
      recommendation_type: 'risk_mitigation',
      confidence_score: 0.82,
      trigger_type: 'regulatory_change',
      reasoning: 'New HIPAA regulations require compliance updates. Client has expressed concerns about audit readiness in recent communications.',
      created_at: '2025-01-17T16:20:00Z',
      status: 'pending'
    },
    {
      id: 5,
      client_name: 'Acme Corporation',
      service_name: 'Security Assessment',
      recommendation_type: 'proactive_support',
      confidence_score: 0.71,
      trigger_type: 'security_event',
      reasoning: 'Industry has seen increase in cyber attacks. Proactive security assessment recommended to identify vulnerabilities.',
      created_at: '2025-01-16T11:00:00Z',
      status: 'pending'
    }
  ];

  // Filter by status if provided
  const status = req.query.status;
  const filtered = status ? recommendations.filter(r => r.status === status) : recommendations;
  
  res.json(filtered);
});

module.exports = router;