const express = require('express');
const router = express.Router();

router.post('/events', (req, res) => {
  res.json({ ok: true });
});

module.exports = router;