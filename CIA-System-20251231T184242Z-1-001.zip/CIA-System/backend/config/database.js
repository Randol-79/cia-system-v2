/**
 * Database Configuration
 * Sequelize ORM setup for PostgreSQL
 */

const { Sequelize } = require('sequelize');
const logger = require('../utils/logger');

// Initialize Sequelize with database URL
const sequelize = new Sequelize(process.env.DATABASE_URL || 'postgresql://cia_user:password@localhost:5432/cia_db', {
  dialect: 'postgres',
  logging: process.env.DEBUG_SQL === 'true' ? (msg) => logger.debug(msg) : false,
  pool: {
    max: 10,
    min: 2,
    acquire: 30000,
    idle: 10000
  },
  dialectOptions: {
    ssl: process.env.NODE_ENV === 'production' ? {
      require: true,
      rejectUnauthorized: false
    } : false
  }
});

/**
 * Test database connection
 */
async function testConnection() {
  try {
    await sequelize.authenticate();
    logger.info('Database connection established successfully');
    return true;
  } catch (error) {
    logger.error('Unable to connect to database:', error);
    throw error;
  }
}

/**
 * Close database connection
 */
async function closeConnection() {
  try {
    await sequelize.close();
    logger.info('Database connection closed');
  } catch (error) {
    logger.error('Error closing database connection:', error);
    throw error;
  }
}

module.exports = {
  sequelize,
  testConnection,
  closeConnection
};
